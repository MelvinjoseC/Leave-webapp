// function showLeavePage() {
//     document.querySelector(".leave_tracker").style.display = "block";
//     document.querySelector(".task_tracker")?.style.display = "none";
//     document.querySelector(".attendance_tracker")?.style.display = "none";
// }

// function showTaskPage() {
//     document.querySelector(".task_tracker").style.display = "block";
//     document.querySelector(".leave_tracker")?.style.display = "none";
//     document.querySelector(".attendance_tracker")?.style.display = "none";
// }

document.addEventListener("DOMContentLoaded", function () {
    // ✅ Ensure Leave Page is Displayed
    document.querySelector(".leave_tracker").style.display = "none";
});


document.addEventListener("DOMContentLoaded", function () {
    // ✅ Check if there's a saved page in localStorage
    const activePage = localStorage.getItem("activePage");

    // if (activePage === "leave") {
    //     showLeavePage();  // Show Leave Tracker Page
    // } else {
    //     showTaskPage();   // Show Task Tracker Page (Default)
    // }

    // ✅ When clicking "Leave Tracker", store page state and show it
    document.getElementById("leave-button").addEventListener("click", function () {
        localStorage.setItem("activePage", "leave");
        showLeavePage();
    });

    // ✅ When clicking "Task Tracker", store page state and show it
    document.getElementById("task-button").addEventListener("click", function () {
        localStorage.setItem("activePage", "task");
        showTaskPage();
    });
    // ✅ When clicking "attendance Tracker", store page state and show it
    const attendanceButton = document.getElementById("attendance-button");
        if (attendanceButton) {
            attendanceButton.addEventListener("click", function() {
                localStorage.setItem("activePage", "attendance");
                showTaskPage();
            });
        }


});

// LEAVE CHART 
document.addEventListener("DOMContentLoaded", function () {
    fetch("/generate-pie-chart/")
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                console.error("Error fetching pie chart data:", data.error);
                return;
            }

            const ctx = document.getElementById("leaveChart").getContext("2d");

            new Chart(ctx, {
                type: "doughnut",
                data: {
                    labels: ["Balance Leave Available", "Full Day Leave Taken", "Half Day Leave Taken", "Work from Home Taken"],
                    datasets: [{
                        data: [data.balance_leave, data.full_day_leave, data.half_day_leave, data.work_from_home],
                        backgroundColor: ["#9B59B6", "#BB8FCE", "#D2B4DE", "#E8DAEF"]

                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,  // ✅ Allows manual resizing
                    aspectRatio: 3,  // ✅ Adjust the ratio (Lower value makes it larger, higher makes it smaller)
                    plugins: {
                        legend: {
                            display: false,
                            position: "right",
                            labels: {
                                font: {
                                    size: 14 // ✅ Adjusts legend text size
                                }
                            }
                        }
                    },
                    layout: {
                        padding: 20 // ✅ Adds padding around the chart
                    }
                }
            });
            

            // ✅ Update the balance leave number in UI
            const balanceEl = document.getElementById("balance-leaves");
            const fullDayEl = document.getElementById("Fullday-leaves");
            const halfDayEl = document.getElementById("Halfday-leaves");
            const wfhEl = document.getElementById("wfh");

            if (balanceEl || fullDayEl || halfDayEl || wfhEl) {
                if (balanceEl) balanceEl.textContent = data.balance_leave ?? "0";
                if (fullDayEl) fullDayEl.textContent = data.full_day_leave ?? "0";
                if (halfDayEl) halfDayEl.textContent = data.half_day_leave ?? "0";
                if (wfhEl) wfhEl.textContent = data.work_from_home ?? "0";
            } else {
                console.warn("⚠️ Leave balance elements not found in DOM — skipping UI update.");
            }


            
        })
        .catch(error => console.error("Error loading pie chart:", error));
});


document.addEventListener("DOMContentLoaded", function () {
    const applyBtn = document.querySelector(".apply-btn");
    const cancelBtn = document.querySelector(".btn-secondary"); // Cancel button
    const leaveStatistics = document.querySelector(".leave-statistics");
    const upcomingHolidays = document.querySelector(".upcoming-holidays");
    const applyLeave = document.querySelector(".apply-leave");

    // Input fields to be cleared on Cancel
    const fromDate = document.getElementById("from_date");
    const toDate = document.getElementById("to_date");
    const selectedFrom = document.getElementById("selected-from");
    const selectedTo = document.getElementById("selected-to");
    const leaveType = document.getElementById("leave-type");
    const notify = document.getElementById("notify");
    const reason = document.getElementById("reason");

    applyBtn.addEventListener("click", function () {
        // Hide leave statistics and upcoming holidays
        leaveStatistics.style.display = "none";
        upcomingHolidays.style.display = "none";

        // Show apply leave section
        applyLeave.style.display = "block";
    });

    cancelBtn.addEventListener("click", function () {
        // Show leave statistics and upcoming holidays
        leaveStatistics.style.display = "block";
        upcomingHolidays.style.display = "block";

        // Hide apply leave section
        applyLeave.style.display = "none";

        // Clear form fields
        fromDate.value = "";  // Clear FROM date
        toDate.value = "";  // Clear TO date
        selectedFrom.textContent = ""; // Clear displayed FROM date
        selectedTo.textContent = ""; // Clear displayed TO date
        leaveType.selectedIndex = 0;  // Reset leave type dropdown
        notify.selectedIndex = 0;  // Reset notify dropdown
        reason.value = "";  // Clear reason textarea
    });
});

document.addEventListener("DOMContentLoaded", function () {
    const monthYear = document.getElementById("monthYear");
    const calendarDates = document.getElementById("calendarDates");
    const prevMonthBtn = document.getElementById("prevMonth");
    const nextMonthBtn = document.getElementById("nextMonth");

    let currentDate = new Date();

    function renderCalendar() {
        const today = new Date();
        const firstDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);
        const lastDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0);
        const firstDayOfWeek = firstDayOfMonth.getDay();
        const lastDayOfWeek = lastDayOfMonth.getDay();
        const prevMonthLastDay = new Date(currentDate.getFullYear(), currentDate.getMonth(), 0).getDate();
        
        monthYear.textContent = firstDayOfMonth.toLocaleDateString("en-US", { month: "long", year: "numeric" });

        calendarDates.innerHTML = "";

        // Previous month days
        for (let i = firstDayOfWeek; i > 0; i--) {
            let dateEl = document.createElement("div");
            dateEl.classList.add("date", "other-month");
            dateEl.textContent = prevMonthLastDay - i + 1;
            calendarDates.appendChild(dateEl);
        }

        // Current month days
        for (let i = 1; i <= lastDayOfMonth.getDate(); i++) {
            let dateEl = document.createElement("div");
            dateEl.classList.add("date", "current-month");
            dateEl.textContent = i;

            // Set active class if it matches today's date
            if (
                today.getDate() === i &&
                today.getMonth() === currentDate.getMonth() &&
                today.getFullYear() === currentDate.getFullYear()
            ) {
                dateEl.classList.add("selected");
            }

            dateEl.addEventListener("click", function () {
                document.querySelectorAll(".date").forEach(el => el.classList.remove("selected"));
                dateEl.classList.add("selected");
            });

            calendarDates.appendChild(dateEl);
        }

        // Next month days
        for (let i = 1; i < 7 - lastDayOfWeek; i++) {
            let dateEl = document.createElement("div");
            dateEl.classList.add("date", "other-month");
            dateEl.textContent = i;
            calendarDates.appendChild(dateEl);
        }
    }

    prevMonthBtn.addEventListener("click", function () {
        currentDate.setMonth(currentDate.getMonth() - 1);
        renderCalendar();
    });

    nextMonthBtn.addEventListener("click", function () {
        currentDate.setMonth(currentDate.getMonth() + 1);
        renderCalendar();
    });

    renderCalendar();
});

document.addEventListener("DOMContentLoaded", function () {
    function formatDate(dateString) {
        const options = { weekday: "long", month: "long", day: "numeric", year: "numeric" };
        return new Date(dateString).toLocaleDateString("en-US", options);
    }

    function updateSelectedDate(inputId, spanId) {
        const input = document.getElementById(inputId);
        const span = document.getElementById(spanId);

        input.addEventListener("change", function () {
            if (this.value) {
                span.textContent = "" + formatDate(this.value);
            } else {
                span.textContent = "";
            }
        });
    }

    updateSelectedDate("from_date", "selected-from");
    updateSelectedDate("to_date", "selected-to");
});

document.addEventListener("DOMContentLoaded", function () {
    fetch('/get-admins/')
        .then(response => response.json())
        .then(data => {
            let select = document.getElementById("notify");
            data.admins.forEach(admin => {
                let option = document.createElement("option");
                option.value = admin.id;
                option.textContent = admin.name;
                select.appendChild(option);
            });
        })
        .catch(error => console.error("Error fetching admins:", error));
});


// SAVING LEAVE APPLICATION
// ✅ SAVE LEAVE APPLICATION
document.addEventListener("DOMContentLoaded", function () {
    let requestLeaveButton = document.querySelector(".submit-leave-btn");

    if (requestLeaveButton) {
        requestLeaveButton.addEventListener("click", function (event) {
            event.preventDefault();

            // ✅ Get form values
            let startDate = document.getElementById("from_date")?.value.trim() || "";
            let endDate = document.getElementById("to_date")?.value.trim() || "";
            let leaveType = document.getElementById("leave-type")?.value.trim() || "";
            let reason = document.getElementById("reason")?.value.trim() || ""; // Optional
            let approverSelect = document.getElementById("notify");
            let approver = approverSelect?.options[approverSelect.selectedIndex]?.text?.trim() || "";

            // ✅ Validation (reason is optional)
            if (!startDate || !endDate || !leaveType || !approver) {
                alert("Please fill in all required fields.");
                return;
            }

            // ✅ Build form data
            let formData = new FormData();
            formData.append("from_date", startDate);
            formData.append("to_date", endDate);
            formData.append("leave-type", leaveType);
            formData.append("reason", reason); // Can be empty
            formData.append("approver", approver);

            // ✅ UI feedback
            requestLeaveButton.disabled = true;
            requestLeaveButton.textContent = "Submitting...";

            // ✅ Send request
            fetch("/apply-leave/", {
                method: "POST",
                body: formData,
                headers: { "X-CSRFToken": getCsrfToken() }
            })
            .then(response => response.json())
            .then(data => {
                if (data.error) {
                    alert(data.error);
                } else {
                    alert(data.message);

                    // ✅ Reset form after submission
                    let leaveForm = document.getElementById("leave-form");
                    if (leaveForm) leaveForm.reset();
                }
            })
            .catch(error => {
                console.error("Error:", error);
                alert("Something went wrong. Please try again.");
            })
            .finally(() => {
                requestLeaveButton.disabled = false;
                requestLeaveButton.textContent = "Request Leave";
            });
        });
    }
});


// ✅ Function to get CSRF token from cookies
function getCsrfToken() {
    let cookieValue = null;
    let cookies = document.cookie ? document.cookie.split("; ") : [];

    for (let cookie of cookies) {
        let [key, value] = cookie.split("=");
        if (key === "csrftoken") {
            return decodeURIComponent(value);
        }
    }
    return cookieValue;
}


// HOLIDAYS
document.addEventListener("DOMContentLoaded", function () {
    fetch("/get_holidays/")
        .then(response => response.json())
        .then(data => {
            let holidayContainer = document.getElementById("holiday-container");
            holidayContainer.innerHTML = ""; // Clear existing rows

            if (data.holidays.length === 0) {
                holidayContainer.innerHTML = "<div class='holiday-row'><span class='holiday-name'>No upcoming holidays</span></div>";
                return;
            }

            data.holidays.forEach(holiday => {
                let statusClass = holiday.status === "past" ? "past-holiday" : "upcoming-holiday";

                let holidayRow = `<div class="holiday-row ${statusClass}">
                    <span class="holiday-name">${holiday.name}</span>
                    <span class="holiday-date">${formatDate(holiday.date)}</span>
                </div>`;
                holidayContainer.innerHTML += holidayRow;
            });
        })
        .catch(error => console.error("Error fetching holidays:", error));
});

// ✅ Helper function to format date properly (YYYY-MM-DD → Day DD/MM/YYYY)
function formatDate(dateStr) {
    let dateObj = new Date(dateStr);
    let options = { weekday: 'long', day: '2-digit', month: '2-digit', year: 'numeric' };
    return dateObj.toLocaleDateString("en-GB", options);  // Example: Monday 17/06/2025
}


//REQUESTS

document.addEventListener("DOMContentLoaded", function () {
    fetch("/api/leave-applications/")
        .then(response => response.json())
        .then(data => {
            const leaveContainer = document.getElementById("leave-container");
            
            data.leave_applications.forEach(leave => {
                const leaveRow = document.createElement("div");
                leaveRow.classList.add("leave-row");

                const startDate = new Date(leave.start_date);
                const today = new Date();

                const isPastDate = startDate < today;

                const editButtonHTML = isPastDate 
                    ? `<button class="action-btn edit-btn disabled" disabled>
                            <img src="/static/images/blue_edit_button_disabled.png">
                       </button>` 
                    : `<button class="action-btn edit-btn" data-id="${leave.id}" data-start="${leave.start_date}" data-end="${leave.end_date}" data-reason="${leave.reason}" data-type="${leave.leave_type}" data-status="${leave.status}">
                            <img src="/static/images/blue_edit_button.png">
                       </button>`;

                leaveRow.innerHTML = `  
                    <div class="leave-cell">
                        <div class="leave-date">${formatDate(leave.start_date)} - ${formatDate(leave.end_date)}</div>
                        <div class="leave-duration">${calculateWorkingDays(leave.start_date, leave.end_date)} days</div>
                    </div>
                    <div class="leave-cell">
                        <div class="leave-form ${formatLeaveType(leave.leave_type)}">${leave.leave_type.toUpperCase()}</div>
                    </div>
                    <div class="leave-cell">
                        <div class="leave-label">Leave Type</div>
                        <div class="leave-value">${leave.leave_payment_type || "Unpaid Leave"}</div>
                    </div>
                    <div class="leave-cell">
                        <div class="leave-label">Requested On</div>
                        <div class="leave-value">${formatDate(leave.created_at)}</div>
                    </div>
                    <div class="leave-cell">
                        <div class="leave-label">Status</div>
                        <div class="leave-approval ${formatStatus(leave.status)}">
                            ${
                                leave.status === "Approved" && leave.md_status === "Pending"
                                    ? "Awaiting MD Approval"
                                    : leave.status === "Final Approved"
                                    ? "Approved"
                                    : leave.status
                            }
                        </div>
                    </div>
                    <div class="leave-cell">
                        <div class="leave-label">Approved By</div>
                        <div class="leave-value">${leave.approver || "-"}</div>
                    </div>
                    <div class="leave-cell actions">
                        <button class="action-btn comment-btn" data-reason="${leave.reason}">
                            <img src="/static/images/comment_button.png">
                        </button>
                        ${editButtonHTML}
                        <button class="action-btn delete-btn" data-id="${leave.id}"><img src="/static/images/delete_button.png"></button>
                    </div>
                `;
                leaveContainer.appendChild(leaveRow);
            });

            // Event Listeners for Edit buttons
            document.querySelectorAll(".edit-btn:not(.disabled)").forEach(button => {
                button.addEventListener("click", function () {
                    const leaveId = this.getAttribute("data-id");
                    const startDate = this.getAttribute("data-start");
                    const endDate = this.getAttribute("data-end");
                    const reason = this.getAttribute("data-reason");
                    const leaveType = this.getAttribute("data-type");

                    openEditModal(leaveId, startDate, endDate, reason, leaveType);
                });
            });

            // Event Listener for Comment Button to Show Leave Reason Modal
            document.querySelectorAll(".comment-btn").forEach(button => {
                button.addEventListener("click", function () {
                    const reason = this.getAttribute("data-reason");
                    showLeaveReasonModal(reason);
                });
            });

            // Event Listener for Delete buttons
            document.querySelectorAll(".delete-btn").forEach(button => {
                button.addEventListener("click", function () {
                    const leaveId = this.getAttribute("data-id");
                    deleteLeave(leaveId);
                });
            });
        })
        .catch(error => console.error("Error fetching leave applications:", error));
});

// Function to show the leave reason in a modal
function showLeaveReasonModal(reason) {
    const modal = document.getElementById("leave-reason-modal");
    const reasonText = document.getElementById("leave-reason-text");
    reasonText.textContent = reason;  // Set the reason text
    modal.style.display = "block";  // Show the modal

    // Close modal when clicking the close button
    const closeBtn = document.querySelector(".close-btn");
    closeBtn.addEventListener("click", function() {
        modal.style.display = "none"; // Hide the modal
    });

    // Close modal when clicking outside of the modal content
    window.onclick = function(event) {
        if (event.target === modal) {
            modal.style.display = "none"; // Hide the modal
        }
    };
}

// Function to open the Edit Modal
function openEditModal(leaveId, startDate, endDate, reason, leaveType) {
    document.getElementById("edit-leave-id").value = leaveId;
    document.getElementById("edit-start-date").value = startDate;
    document.getElementById("edit-end-date").value = endDate;
    document.getElementById("edit-reason").value = reason;
    document.getElementById("edit-leave-type").value = leaveType;

    document.getElementById("edit-modal").style.display = "block"; // Show modal
}

// Function to update leave application
async function updateLeavedata() {
    const leaveId = document.getElementById("edit-leave-id").value;
    const startDate = document.getElementById("edit-start-date").value;
    const endDate = document.getElementById("edit-end-date").value;
    const reason = document.getElementById("edit-reason").value;
    const leaveType = document.getElementById("edit-leave-type").value;

    // Get CSRF token from cookies
    function getCSRFToken() {
        return document.cookie.split('; ').find(row => row.startsWith('csrftoken'))?.split('=')[1];
    }

    // Check if the start date is in the past
    const startDateObj = new Date(startDate);
    const today = new Date();

    if (startDateObj < today) {
        alert("You cannot update leave applications to a past date.");
        return; // Do not proceed if the start date is in the past
    }

    try {
        const response = await fetch(`/leave/edit/${leaveId}/`, {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded",
                "X-CSRFToken": getCSRFToken(),  // Add CSRF token
            },
            body: new URLSearchParams({
                start_date: startDate,
                end_date: endDate,
                reason: reason,
                leave_type: leaveType
            }),
        });

        const data = await response.json();
        if (response.ok) {
            alert("Leave updated successfully!");
            document.getElementById("edit-modal").style.display = "none"; // Hide modal
            location.reload(); // Refresh page to reflect changes
        } else {
            alert("Error: " + data.error);
        }
    } catch (error) {
        alert("Network error! Please try again.");
    }
}



// Function to delete leave application
async function deleteLeave(leaveId) {
    if (!confirm("Are you sure you want to delete this leave?")) {
        return;
    }

    // Function to get CSRF token from cookies
    function getCSRFToken() {
        return document.cookie.split('; ').find(row => row.startsWith('csrftoken'))?.split('=')[1];
    }

    try {
        const response = await fetch(`/leave/delete/${leaveId}/`, {
            method: "POST", // Using POST instead of DELETE
            headers: {
                "Content-Type": "application/json",
                "X-CSRFToken": getCSRFToken(),  // Add CSRF Token
            },
        });

        const data = await response.json();

        if (response.ok) {
            alert("✅ Leave application deleted successfully!");
            location.reload();
        } else {
            alert("❌ " + data.error); // Show error in popup
        }
    } catch (error) {
        alert("⚠️ Network error! Please try again.");
    }
}

// Function to show the leave reason in a modal
function showLeaveReasonModal(reason) {
    const modal = document.getElementById("leave-reason-modal");
    const reasonText = document.getElementById("leave-reason-text");
    reasonText.textContent = reason;  // Set the reason text
    modal.style.display = "block";  // Show the modal

    // Close modal when clicking the close button
    const closeBtn = document.querySelector(".close-btn");
    closeBtn.addEventListener("click", function() {
        modal.style.display = "none"; // Hide the modal
    });

    // Close modal when clicking outside of the modal content
    window.onclick = function(event) {
        if (event.target === modal) {
            modal.style.display = "none"; // Hide the modal
        }
    };
}





// Function to close the modal
function closeModals() {
    document.getElementById("edit-modal").style.display = "none";
}



let HOLIDAYS = [];

// ✅ Fetch holidays from Django backend
async function loadHolidays() {
    try {
        const response = await fetch("/api/get-holidays/");
        const data = await response.json();
        if (data.holidays) {
            HOLIDAYS = data.holidays;
            console.log("Loaded holidays:", HOLIDAYS);
        } else {
            console.warn("No holidays found in response.");
        }
    } catch (error) {
        console.error("Error fetching holidays:", error);
    }
}

// ✅ Calculate working days (excluding weekends + holidays)
function calculateWorkingDays(start, end) {
    const startDate = new Date(start);
    const endDate = new Date(end);

    if (isNaN(startDate) || isNaN(endDate) || endDate < startDate) return 0;

    let count = 0;
    let current = new Date(startDate);

    while (current <= endDate) {
        const day = current.getDay(); // 0 = Sunday, 6 = Saturday
        const formatted = current.toISOString().split("T")[0];

        if (day !== 0 && day !== 6 && !HOLIDAYS.includes(formatted)) {
            count++;
        }

        current.setDate(current.getDate() + 1);
    }

    return count;
}

// Helper function to apply CSS classes for status
function formatStatus(status) {
    return status.toLowerCase() === "pending" ? "pending" : status.toLowerCase();
}

// Helper function to format leave type for CSS classes
function formatLeaveType(type) {
    return type.toLowerCase().replace(/\s+/g, "-");
}



//APPROVAL 
document.addEventListener("DOMContentLoaded", function () {
    const leaveContainer = document.getElementById("leave-container");
    const approvalButton = document.getElementById("approvals-btn");

    // ✅ Check admin/MD status
    fetch('/api/check-admin-status/', {
        method: 'GET',
        credentials: 'include',
    })
        .then(response => response.json())
        .then(data => {
            if (data.is_admin || data.is_md) {
                approvalButton.style.display = "block";
            } else {
                approvalButton.style.display = "none";
            }
        })
        .catch(error => console.error("❌ Error fetching admin/MD status:", error));

    // ✅ Load admins list
    fetch("/get-admins/")
        .then(response => response.json())
        .then(data => {
            const currentUsername = (window.APP_USER && window.APP_USER.name) || "";
            if (!data.admins || !Array.isArray(data.admins)) return;
            const isAdmin = data.admins.some(admin => admin.name === currentUsername);
            if (isAdmin) approvalButton.style.display = "block";
        })
        .catch(error => console.error("Error fetching admins:", error));

    // ✅ Handle button click
    if (approvalButton) {
        approvalButton.addEventListener("click", toggleButton);
    }


    // ✅ Functions
    function loadApprovals() {
        fetch("/api/check-admin-status/", { method: "GET", credentials: "include" })
            .then(response => response.json())
            .then(roleData => {
                let url = "/api/leave-approvals/";

                // If MD, show only those pending for MD approval
                if (roleData.is_md && !roleData.is_admin) {
                    url = "/api/md-leave-approvals/";  // ✅ new endpoint for MDs
                }

                return fetch(url);
            })
            .then(response => response.json())
            .then(data => {
                const approvalContainer = document.getElementById("approval-container");
                approvalContainer.innerHTML = "";

                if (!data || data.length === 0) {
                    approvalContainer.innerHTML = `<div class="no-data">No pending approvals.</div>`;
                    return;
                }

                data.forEach(leave => {
                    const leaveRow = document.createElement("div");
                    leaveRow.classList.add("leave-rows");

                    // Status display logic
                    let statusText = leave.status;
                    if (leave.status === "Approved" && leave.md_status === "Pending") {
                        statusText = "Awaiting MD Approval";
                    } else if (leave.status === "Final Approved") {
                        statusText = "Approved by MD";
                    } else if (leave.status === "Rejected") {
                        statusText = "Rejected";
                    }

                    leaveRow.innerHTML = `
                        <div class="leave-cell">
                            <b>${leave.username}</b> (${formatDate(leave.start_date)} - ${formatDate(leave.end_date)})
                        </div>
                        <div class="leave-cell"><b>Reason:</b> ${leave.reason}</div>
                        <div class="leave-cell"><b>Type:</b> ${leave.leave_type}</div>
                        <div class="leave-cell"><b>Status:</b> ${statusText}</div>
                        <div class="leave-cell">
                            <button class="approve-btn" data-id="${leave.id}" data-status="Approved">Approve</button>
                            <button class="reject-btn" data-id="${leave.id}" data-status="Rejected">Reject</button>
                        </div>
                    `;

                    approvalContainer.appendChild(leaveRow);
                });

                document.querySelectorAll(".approve-btn, .reject-btn").forEach(btn => {
                    btn.addEventListener("click", updateLeaveStatus);
                });
            })
            .catch(error => console.error("❌ Error fetching approvals:", error));
    }


    function updateLeaveStatus(event) {
        const leaveId = event.target.getAttribute("data-id");
        const newStatus = event.target.getAttribute("data-status");
        if (!leaveId || !newStatus) return;

        fetch('/api/update-leave-status/', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'X-CSRFToken': getCsrfToken() },
            body: JSON.stringify({ id: leaveId, status: newStatus }),
        })
            .then(response => response.json())
            .then(data => {
                if (data.message) {
                    alert(data.message);
                    loadApprovals();
                } else if (data.error) {
                    alert(`Error: ${data.error}`);
                }
            })
            .catch(error => console.error("Error updating status:", error));
           
    }

    // ✅ Toggle between leave history and approvals
    function toggleButton() {
        const leaveContainer = document.getElementById("leave-container");
        const approvalContainer = document.getElementById("approval-container");
        if (leaveContainer.style.display === "block" || leaveContainer.style.display === "") {
            approvalButton.innerText = "VIEW HISTORY";
            leaveContainer.style.display = "none";
            approvalContainer.style.display = "block";
            loadApprovals();
        } else {
            approvalButton.innerText = "APPROVALS";
            leaveContainer.style.display = "block";
            approvalContainer.style.display = "none";
        }
    }
});


// ✅ COMPENSATION LEAVE BUTTON AND DISPLAY
document.addEventListener("DOMContentLoaded", function () {
    fetch("/api/compensated-worktime/")
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            if (data.error) {
                console.error("❌ Error fetching compensated worktime:", data.error);
                return;
            }

            const tableBody = document.querySelector("#compensatedWorktimeTable tbody");
            tableBody.innerHTML = "";

            // ✅ Only include non-normal days
            const records = (data.compensated_worktime || []).filter(record => {
                return (
                    record.status.toUpperCase() !== "NORMAL WORKDAY" ||
                    record.is_weekend ||
                    record.is_holiday
                );
            });


            if (records.length === 0) {
                tableBody.innerHTML = `<tr><td colspan="4">No compensated worktime available.</td></tr>`;
                return;
            }

            records.forEach(record => {
                let row = document.createElement("tr");

                // ✅ Determine row status color
                let statusClass = "";
                if (record.status === "Full-day Earned" || record.status === "Half-day Earned") {
                    statusClass = "earned";
                } else if (record.status === "Not Compensated") {
                    statusClass = "not-compensated";
                }

                // ✅ Action button
                let actionButton = "";

                if (record.is_compensated === 1.5 || record.is_compensated === 2.0) {
                    actionButton = `<span class="waiting-text">WAITING FOR APPROVAL</span>`;
                } else if (record.redeemed === 1) {
                    actionButton = `<span class="approved-text">APPROVED</span>`;
                } else if ((record.is_compensated === 1.0 || record.is_compensated === 0.5) && record.redeemed === 0) {
                    actionButton = `<button class="comp-leave-btn" data-date="${record.date}">ADD TO COMP LEAVE</button>`;
                } 
                else {
                    actionButton = `<button class="comp-leave-btn" disabled>NOT ELIGIBLE</button>`;
                }

                // ✅ Build row (only 4 columns)
                row.innerHTML = `
                    <td>${record.date || "-"}</td>
                    <td>${record.total_time?.toFixed(2) || "0.00"} / ${record.expected_hours?.toFixed(2) || "0.00"} hrs</td>
                    <td class="${statusClass}">${record.status}</td>
                    <td>${actionButton}</td>
                `;


                tableBody.appendChild(row);
            });           
            // ✅ Handle "Add to Comp Leave" button click
            document.querySelectorAll(".comp-leave-btn").forEach(button => {
                button.addEventListener("click", function () {
                    const selectedDate = this.getAttribute("data-date");
                    const clickedButton = this;

                    // Show immediate feedback
                    clickedButton.textContent = "Submitting...";
                    clickedButton.disabled = true;

                    // 🧠 Universal date parser (fixed)
                    function parseDateString(dateStr) {
                        if (!dateStr) return null;
                        dateStr = dateStr.trim();

                        // ✅ Always handle DD-MM-YYYY manually
                        if (/^\d{1,2}-\d{1,2}-\d{4}$/.test(dateStr)) {
                            const [day, month, year] = dateStr.split("-");
                            return new Date(`${year}-${month.padStart(2, "0")}-${day.padStart(2, "0")}T00:00:00`);
                        }

                        // ✅ Handle YYYY-MM-DD (already ISO)
                        if (/^\d{4}-\d{1,2}-\d{1,2}$/.test(dateStr)) {
                            const [year, month, day] = dateStr.split("-");
                            return new Date(`${year}-${month.padStart(2, "0")}-${day.padStart(2, "0")}T00:00:00`);
                        }

                        // ✅ Handle formats like "01 Nov 2025" or "Nov 01, 2025"
                        const monthMap = {
                            Jan: "01", Feb: "02", Mar: "03", Apr: "04", May: "05", Jun: "06",
                            Jul: "07", Aug: "08", Sep: "09", Oct: "10", Nov: "11", Dec: "12"
                        };

                        // e.g., "01 Nov 2025"
                        const parts = dateStr.split(" ");
                        if (parts.length === 3 && monthMap[parts[1]]) {
                            const [day, mon, year] = parts;
                            return new Date(`${year}-${monthMap[mon]}-${day.padStart(2, "0")}T00:00:00`);
                        }

                        // e.g., "Nov 01, 2025"
                        const commaParts = dateStr.replace(",", "").split(" ");
                        if (commaParts.length === 3 && monthMap[commaParts[0]]) {
                            const [mon, day, year] = commaParts;
                            return new Date(`${year}-${monthMap[mon]}-${day.padStart(2, "0")}T00:00:00`);
                        }

                        return null;
                    }

                    // ✅ Parse the date safely
                    // ✅ Directly reformat from DD-MM-YYYY to YYYY-MM-DD
                    let formattedDate = selectedDate;
                    if (/^\d{1,2}-\d{1,2}-\d{4}$/.test(selectedDate)) {
                        const [day, month, year] = selectedDate.split("-");
                        formattedDate = `${year}-${month.padStart(2, "0")}-${day.padStart(2, "0")}`;
                    }


                    // ✅ Send request to backend
                    fetch("/api/request-comp-leave/", {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json",
                            "X-CSRFToken": getCsrfToken(),
                        },
                        body: JSON.stringify({ date: formattedDate }),
                    })
                        .then(response => response.json())
                        .then(data => {
                            if (data.error) {
                                alert("❌ Error: " + data.error);
                                clickedButton.textContent = "ADD TO COMP LEAVE";
                                clickedButton.disabled = false;
                            } else {
                                alert(data.message || "✅ Comp Leave request submitted!");
                                clickedButton.outerHTML = `<span class="waiting-text">WAITING FOR APPROVAL</span>`;
                            }
                        })
                        .catch(error => {
                            console.error("❌ Error requesting comp leave:", error);
                            clickedButton.textContent = "ADD TO COMP LEAVE";
                            clickedButton.disabled = false;
                        });
                });
            });

        })
        .catch(error => console.error("❌ Error fetching compensated worktime:", error));
});


// ✅ Convert seconds → readable HH:MM:SS
function convertToTimeFormat(seconds) {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;

    if (hrs > 0) {
        return `${String(hrs).padStart(2, '0')}:${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
    } else {
        return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
    }
}





// ✅ Request Compensatory Leave
// function requestCompLeave(date) {
//     fetch("/api/request-comp-leave/", {
//         method: "POST",
//         headers: {
//             "Content-Type": "application/json",
//             "X-CSRFToken": getCsrfToken(),
//         },
//         body: JSON.stringify({ date: date }),
//     })
//         .then(response => response.json())
//         .then(data => {
//             if (data.error) {
//                 alert("❌ Error: " + data.error);
//             } else {
//                 alert("✅ Comp Leave request submitted!");
//                 // Change button text immediately
//                 this.textContent = "Waiting for Approval";
//                 this.disabled = true;
//                 this.classList.add("waiting");

//                 location.reload();
//             }
//         })
//         .catch(error => console.error("❌ Error requesting comp leave:", error));
// }

// ✅ Fetch and Display Pending Comp Leave Requests (MD View)
document.addEventListener("DOMContentLoaded", function () {
    const pendingTable = document.querySelector("#pending-comp-leave-table");

    // ⚠️ Exit early if table not found in DOM (prevents console spam)
    if (!pendingTable) {
        console.warn("⚠️ Skipping Comp Leave Approval JS — #pending-comp-leave-table not found in DOM.");
        return;
    }

    const tableBody = pendingTable.querySelector("tbody");
    if (!tableBody) {
        console.error("❌ Table body not found! Ensure <tbody> exists inside #pending-comp-leave-table.");
        return;
    }

    // ✅ Fetch pending comp leave requests (MD/Admin only)
    fetch("/api/comp-leave-approvals/")
        .then(response => {
            if (response.status === 403) {
                console.info("ℹ️ Current user is not MD/Admin — skipping Comp Leave Approvals.");
                return null; // Skip silently for normal users
            }
            if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);
            return response.json();
        })
        .then(data => {
            if (!data) return; // Non-MDs

            if (data.error) {
                console.error("❌ Error fetching pending requests:", data.error);
                tableBody.innerHTML = `<tr><td colspan="4">Error loading requests.</td></tr>`;
                return;
            }

            // ✅ Clear any existing rows
            tableBody.innerHTML = "";

            const pendingList = data.pending_requests || [];

            // ✅ Handle empty case
            if (pendingList.length === 0) {
                tableBody.innerHTML = `<tr><td colspan="4">No pending requests.</td></tr>`;
                return;
            }

            // ✅ Populate pending requests
            pendingList.forEach(request => {
                const row = document.createElement("tr");

                // Determine type based on is_compensated value
                const type =
                    request.is_compensated === 1.5
                        ? "Half Day"
                        : request.is_compensated === 2.0
                        ? "Full Day"
                        : "-";

                // Build HTML row
                row.innerHTML = `
                    <td>${formatDate(request.date)}</td>
                    <td>${request.username}</td>
                    <td>${type}</td>
                    <td>
                        <button class="approval-btn"
                            data-date="${request.date}"
                            data-username="${request.username}"
                            data-action="approve">Approve</button>
                        <button class="rejected-btn"
                            data-date="${request.date}"
                            data-username="${request.username}"
                            data-action="reject">Reject</button>
                    </td>
                `;

                tableBody.appendChild(row);
            });
        })
        .catch(error => console.error("❌ Error fetching comp leave approvals:", error));

    // ✅ Use event delegation to handle approve/reject button clicks
    pendingTable.addEventListener("click", function (event) {
        const button = event.target.closest("button");
        if (!button) return;

        const action = button.dataset.action;
        const date = button.dataset.date;
        const username = button.dataset.username;

        if (!action || !date || !username) return;

        updateCompLeave(date, username, action);
    });
});

// ✅ Helper function to send MD approval/rejection
function updateCompLeave(date, username, action) {
    fetch("/api/update-comp-leave/", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "X-CSRFToken": getCsrfToken(),
        },
        body: JSON.stringify({
            date: date,
            username: username,
            action: action,
        }),
    })
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                alert("❌ Error: " + data.error);
            } else {
                alert(`✅ Successfully ${action}d request!`);
                location.reload();
            }
        })
        .catch(error => console.error("❌ Error updating comp leave:", error));
}

// ✅ Helper to format date nicely
function formatDate(dateStr) {
    try {
        const d = new Date(dateStr);
        return d.toLocaleDateString("en-GB", {
            weekday: "short",
            year: "numeric",
            month: "short",
            day: "numeric"
        });
    } catch {
        return dateStr || "-";
    }
}


// ✅ Helper function: CSRF token
function getCsrfToken() {
    let cookieValue = null;
    const cookies = document.cookie ? document.cookie.split("; ") : [];
    for (let cookie of cookies) {
        const [key, value] = cookie.split("=");
        if (key === "csrftoken") {
            cookieValue = decodeURIComponent(value);
            break;
        }
    }
    return cookieValue;
}



// COMPLEAVE BUTTON
document.addEventListener("DOMContentLoaded", function () {
    // Fetch user status (Admin or MD) from the backend
    fetch('/api/check-admin-status/', {
        method: 'GET',
        credentials: 'include', // Ensures authentication session is sent
    })
    .then(response => response.json())
    .then(data => {
        console.log("🔍 API Response:", data); // Debugging: Check API response

        const approvalButton = document.getElementById("approvals-btn");
        const compLeaveBtn = document.getElementById("compleave-btn");
        const leaveHistorySection = document.querySelector(".leave-history-content");
        const compWorktimeSection = document.querySelector(".compensated-worktime-section");

        // Initially show approval button for Admin/MD and Compensate Leave Balance for all
        approvalButton.style.display = (data.is_admin || data.is_md) ? "block" : "none";
        compWorktimeSection.style.display = "none";  // Initially hide the worktime section

        // Ensure the Compensate Leave button is always visible
        compLeaveBtn.style.display = "block";

        compLeaveBtn.addEventListener("click", function () {
            if (leaveHistorySection.style.display !== "none") {
                // Hide leave history section and show worktime section
                leaveHistorySection.style.display = "none";
                compWorktimeSection.style.display = "block";
                compLeaveBtn.textContent = "GO BACK"; // Change button text

                // Hide approvals button
                approvalButton.style.display = "none";
            } else {
                // Show leave history section and hide worktime section
                leaveHistorySection.style.display = "block";
                compWorktimeSection.style.display = "none";
                compLeaveBtn.textContent = "COMP LEAVE BALANCE"; // Reset button text

                // Show approvals button if user is Admin or MD
                if (data.is_admin || data.is_md) {
                    approvalButton.style.display = "block";
                } else {
                    approvalButton.style.display = "none";
                }
            }
        });
    })
    .catch(error => console.error("❌ Error fetching admin/MD status:", error));
});
