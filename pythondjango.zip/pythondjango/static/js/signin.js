const csrfTokenMeta = document.querySelector("meta[name=\"csrf-token\"]");
const csrfToken = csrfTokenMeta ? csrfTokenMeta.getAttribute("content") : "";

async function login() {
    const username = document.getElementById("username")?.value;
    const password = document.getElementById("password")?.value;

    if (!username || !password) {
        alert("Please enter both username and password.");
        return;
    }

    try {
        const response = await fetch("", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "X-CSRFToken": csrfToken,
            },
            body: JSON.stringify({ username, password }),
        });

        const data = await response.json();

        if (data.success) {
            window.location.href = data.redirect_url;
        } else {
            alert(data.message);
        }
    } catch (error) {
        console.error("Error during login:", error);
        alert("An error occurred. Please try again.");
    }
}

function openSignUpPopup() {
    const modal = document.getElementById("signUpModal");
    if (modal) {
        modal.style.display = "flex";
    }
}

function closeSignUpPopup() {
    const modal = document.getElementById("signUpModal");
    if (modal) {
        modal.style.display = "none";
    }
}

async function signUp() {
    const username = document.getElementById("signUpUsername")?.value;
    const password = document.getElementById("signUpPassword")?.value;

    if (!username || !password) {
        alert("Please enter both username and password.");
        return;
    }

    try {
        const response = await fetch("/sign_up/", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "X-CSRFToken": csrfToken,
            },
            body: JSON.stringify({ username, password }),
        });

        if (response.ok) {
            const redirectHtml = await response.text();
            document.open();
            document.write(redirectHtml);
            document.close();
        } else {
            const data = await response.json();
            alert(data.message || "An error occurred. Please try again.");
        }
    } catch (error) {
        console.error("Error during sign-up:", error);
        alert("An error occurred. Please try again.");
    }
}

window.login = login;
window.openSignUpPopup = openSignUpPopup;
window.closeSignUpPopup = closeSignUpPopup;
window.signUp = signUp;


function openForgotModal() {
  document.getElementById('forgotPasswordModal').style.display = 'block';
}

function closeForgotModal() {
  document.getElementById('forgotPasswordModal').style.display = 'none';
}

document.getElementById('forgotPasswordForm').addEventListener('submit', async function(e) {
  e.preventDefault();

  const formData = new FormData(this);

  // ✅ Django will render this into /reset-password/
  const response = await fetch("/reset-password/", {
    method: 'POST',
    body: formData
  });

  const data = await response.json();

  if (data.success) {
    alert('Password updated successfully!');
    closeForgotModal();
  } else {
    alert(data.error || 'Username or Email not found!');
  }

});