const calendar = document.getElementById("calendar");
const monthYear = document.getElementById("month-year");
const select = document.getElementById("employee-select");
const totalDisplay = document.getElementById("total-worktime-display");
const detailsDisplay = document.getElementById("attendance-details");
let current = new Date();

/* Build the monthly summary card HTML if the backend includes `monthly_summary` */
function buildMonthlySummaryCard(ms) {
  if (!ms) return "";

  const hoursPerDay = 9;
  const totalTaskHours = Number(ms.total_task_hours || 0);
  const expectedHours = Number(ms.expected_hours || 0);
  const totalLeaveHours = Number(ms.total_leave_hours || 0);
  const net = Number(
    ms.net_difference != null
      ? ms.net_difference
      : totalTaskHours - (expectedHours - totalLeaveHours)
  );

  const maybeDays = expectedHours % hoursPerDay === 0 ? expectedHours / hoursPerDay : null;
  const expectedLine = maybeDays !== null
    ? `${maybeDays} x ${hoursPerDay} = ${expectedHours} HR`
    : `${expectedHours.toFixed(2)} HR`;

  const leaveDays = totalLeaveHours % hoursPerDay === 0 ? totalLeaveHours / hoursPerDay : null;
  const leaveLine = leaveDays !== null
    ? `${leaveDays} x ${hoursPerDay} = ${totalLeaveHours} HR`
    : `${totalLeaveHours.toFixed(2)} HR`;

  return `
    <div class="monthly-summary-card">
      <p><strong>TOTAL MONTHLY TASK TIME:</strong><br>${totalTaskHours.toFixed(2)} HR</p>
      <br>
      <p><strong>TOTAL MONTHLY TIME:</strong><br>${expectedLine}</p>
      <br>
      <p><strong>TOTAL MONTHLY LEAVE TAKEN:</strong><br>${leaveLine}</p>
      <br>
      <div class="monthly-summary-net ${net >= 0 ? 'positive' : 'negative'}">
        ${net >= 0 ? '+' : ''}${net.toFixed(2)} HR
      </div>
    </div>
  `;
}

// Function to handle date click in the calendar
// When date clicked
function handleDateClick(dateStr, username) {
  if (!username) {
    alert("Please select an employee first.");
    return;
  }

  fetch(`/tracker/get-task-details/?username=${encodeURIComponent(username)}&date=${encodeURIComponent(dateStr)}`)
    .then(res => res.json())
    .then(data => {
      if (data.error) {
        alert(data.error);
        detailsDisplay.innerHTML = "";
        return;
      }

      const tasks = data.tasks || [];
      let html = `<h3>TASKS WORKED (${dateStr})</h3><hr>`;

      if (!tasks.length) {
        html += `<p>No tasks found for this date.</p>`;
      } else {
        tasks.forEach(task => {
          html += `
            <div class="task-card" data-category="${task.category.toLowerCase()}">
              <p class="task-project">${task.project}</p>
              <p class="task-title"><strong>${task.title}</strong></p>
              <p class="task-scope">${task.scope}</p>
              <div class="task-hours">${task.hours_spent} hr</div>
            </div>
          `;
        });
      }

      detailsDisplay.innerHTML = html;
    })
    .catch(err => {
      console.error("Error fetching task details:", err);
      alert("Failed to fetch task details.");
    });
}




// Function to update the calendar view
function updateCalendar(datesWithWorktime = {}, username) {
  calendar.innerHTML = "";

  const year = current.getFullYear();
  const month = current.getMonth();
  const firstDay = new Date(year, month, 1);
  const lastDay = new Date(year, month + 1, 0);
  const startDay = firstDay.getDay();
  const totalCells = 42;
  const totalDays = lastDay.getDate();
  const remainingCells = totalCells - (startDay + totalDays);

  monthYear.textContent = current.toLocaleString('default', { month: 'long', year: 'numeric' });

  // Empty cells before first day
  for (let i = 0; i < startDay; i++) {
    const empty = document.createElement("div");
    empty.className = "day empty-cell";
    calendar.appendChild(empty);
  }

  // Actual days
  for (let day = 1; day <= totalDays; day++) {
    const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    const div = document.createElement("div");
    div.className = "day";
    div.innerHTML = `<div class="date">${day}</div>`;

    if (Object.prototype.hasOwnProperty.call(datesWithWorktime, dateStr)) {
      const hours = Number(datesWithWorktime[dateStr] || 0);
      div.innerHTML += `<div class="worktime">${hours.toFixed(2)} hrs</div>`;
    }

    div.addEventListener("click", () => {
      if (username) {
        handleDateClick(dateStr, username);
      } else {
        alert("Please select an employee first.");
      }
    });

    calendar.appendChild(div);
  }

  // Empty cells after month
  for (let i = 0; i < remainingCells; i++) {
    const empty = document.createElement("div");
    empty.className = "day empty-cell";
    calendar.appendChild(empty);
  }
}

// Fetch and display worktime for selected user
function fetchWorktimeForSelectedUser(username) {
  const month = current.getMonth() + 1;
  const year = current.getFullYear();

  fetch(`/tracker/get-user-tasktime/?username=${encodeURIComponent(username)}&month=${month}&year=${year}`)
    .then(res => res.json())
    .then(data => {
      const datesWithWorktime = {};
      let total = 0;

      if (data.tasktime && Array.isArray(data.tasktime)) {
        data.tasktime.forEach(entry => {
          const d = new Date(entry.date);
          if (d.getMonth() + 1 === month && d.getFullYear() === year) {
            const daily = parseFloat(entry.daily_worktime_hours) || 0;
            datesWithWorktime[entry.date] = daily;
            total += daily;
          }
        });
      }

      totalDisplay.textContent = `Total Worktime: ${total.toFixed(2)} hrs`;
      updateCalendar(datesWithWorktime, username);
    })
    .catch(err => console.error("Error fetching worktime:", err));
}


// Month navigation
document.getElementById("prev-month").onclick = () => {
  current.setMonth(current.getMonth() - 1);
  updateCalendar();                               // redraw grid
  const username = select.value;
  if (username) {
    fetchMonthlySummary(username);                 // ← refresh summary for new month
    fetchWorktimeForSelectedUser(username);        // ← refresh daily hours for new month
  }
};

document.getElementById("next-month").onclick = () => {
  current.setMonth(current.getMonth() + 1);
  updateCalendar();
  const username = select.value;
  if (username) {
    fetchMonthlySummary(username);
    fetchWorktimeForSelectedUser(username);
  }
};

// Fetch employee list and populate dropdown
fetch("/tracker/get-users/")
  .then(res => res.json())
  .then(data => {
    (data.employees || []).forEach(emp => {
      const option = document.createElement("option");
      option.value = emp.name; // username
      option.textContent = emp.name;
      select.appendChild(option);
    });
  });

// Handle employee selection
select.addEventListener("change", () => {
  const username = select.value;

  if (!username) {
    detailsDisplay.innerHTML = "";
    totalDisplay.textContent = "";
    updateCalendar({}, null);
    return;
  }

  // Always update calendar first
  fetchMonthlySummary(username);
  fetchWorktimeForSelectedUser(username);

  // Then update monthly summary
  const month = current.getMonth() + 1;
  const year = current.getFullYear();

  fetch(`/tracker/get-task-details/?username=${encodeURIComponent(username)}&month=${month}&year=${year}`)
    .then(res => res.json())
    .then(data => {
      if (data.error) {
        detailsDisplay.innerHTML = `<p>${data.error}</p>`;
        return;
      }

      const s = data.monthly_summary;
      if (!s) {
        detailsDisplay.innerHTML = `<p>No summary data available for this month.</p>`;
        return;
      }

      detailsDisplay.innerHTML = `
        <div class="monthly-summary-card">
          <p><strong>Month:</strong> ${s.month}</p>
          <p><strong>Total Task Hours:</strong> ${s.total_task_hours} HR</p>
          <p><strong>Expected Hours:</strong> ${s.expected_hours} HR</p>
          <p><strong>Leave Hours:</strong> ${s.total_leave_hours} HR</p>
          <p><strong>Net Difference:</strong> ${s.net_difference} HR</p>
        </div>`;
    })
    .catch(err => {
      console.error("Error fetching monthly summary:", err);
      detailsDisplay.innerHTML = "<p>Failed to load summary.</p>";
    });
});


// Initialize
updateCalendar({}, null);

// Toggle between forms
document.addEventListener("DOMContentLoaded", function () {
  const formContainer = document.getElementById("project-form-container");
  const analysisContainer = document.getElementById("monthly-analysis");
  const toggleButton = document.getElementById("toggle-btn");
  const backButton = document.getElementById("back-btn");

  toggleButton.addEventListener("click", function () {
    formContainer.style.display = "none";
    analysisContainer.style.display = "block";
    toggleButton.style.display = "none";
  });

  backButton.addEventListener("click", function () {
    formContainer.style.display = "block";
    analysisContainer.style.display = "none";
    toggleButton.style.display = "inline-block";
  });
});
function fetchMonthlySummary(username) {
  const month = current.getMonth() + 1;   // ← from the calendar's visible month
  const year  = current.getFullYear();

  detailsDisplay.innerHTML = "<p>Loading summary…</p>";

  // cache-bust to avoid any browser caching issues
  fetch(`/tracker/get-task-details/?username=${encodeURIComponent(username)}&month=${month}&year=${year}&_=${Date.now()}`, {
    cache: "no-store"
  })
    .then(res => res.json())
    .then(data => {
      if (data.error || !data.monthly_summary) {
        detailsDisplay.innerHTML = `<p>${data.error || "No summary for this month."}</p>`;
        return;
      }
      const s = data.monthly_summary;
      detailsDisplay.innerHTML = `
        <div class="monthly-summary-card">
          <p><strong>Month:</strong> ${s.month}</p>
          <p><strong>Total Task Hours:</strong> ${s.total_task_hours} HR</p>
          <p><strong>Expected Hours:</strong> ${s.expected_hours} HR</p>
          <p><strong>Leave Hours:</strong> ${s.total_leave_hours} HR</p>
          <div class="monthly-summary-net ${s.net_difference >= 0 ? 'positive' : 'negative'}">
            ${s.net_difference >= 0 ? '+' : ''}${s.net_difference} HR
          </div>
        </div>`;
    })
    .catch(err => {
      console.error("Summary fetch failed:", err);
      detailsDisplay.innerHTML = "<p>Failed to load summary.</p>";
    });
}
