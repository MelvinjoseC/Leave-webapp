document.addEventListener("DOMContentLoaded", function () {
  const formContainer = document.getElementById("project-form-container");
  const weeklyprojectanalysisContainer = document.getElementById("weeklyproject-analysis");
  const toggleButton = document.getElementById("toggle-btnweekly");
  const backButton = document.getElementById("go-back-btnz");

  const departmentDropdown = document.getElementById("departmentDropdown");
  const projectDropdown = document.getElementById("projectDropdown");
  const categoryDropdown = document.getElementById("categoryDropdown");
  const weekDropdown = document.getElementById("weekDropdown");
  const projectDataContainer = document.getElementById("projectDataContainer");
  const summaryContainer = document.getElementById("weekly-summary");

  // -------------------------------
  // Toggle Weekly Analysis Section
  // -------------------------------
  toggleButton.addEventListener("click", function () {
    formContainer.style.display = "none";
    weeklyprojectanalysisContainer.style.display = "block";
    toggleButton.style.display = "none";
    fetchDepartments();
  });

  backButton.addEventListener("click", function () {
    formContainer.style.display = "block";
    weeklyprojectanalysisContainer.style.display = "none";
    toggleButton.style.display = "inline-block";
  });

  // -------------------------------
  // Fetch Departments
  // -------------------------------
  function fetchDepartments() {
    fetch("/get_project_data/?department=&project_name=&category=&week_offset=0")
      .then((response) => response.json())
      .then((data) => {
        const departments = new Set(data.departments);
        departmentDropdown.innerHTML = '<option value="">Select Department</option>';
        departments.forEach((department) => {
          const option = document.createElement("option");
          option.value = department;
          option.textContent = department;
          departmentDropdown.appendChild(option);
        });
      })
      .catch((error) => console.error("Error fetching departments:", error));
  }

  // -------------------------------
  // Update Projects
  // -------------------------------
  departmentDropdown.addEventListener("change", function () {
    const department = departmentDropdown.value;
    if (department) updateProjects(department);
  });

  function updateProjects(department) {
    projectDropdown.innerHTML = '<option value="">Select Project</option>';

    fetch(`/get_project_data/?department=${department}&week_offset=0`)
      .then((response) => response.json())
      .then((data) => {
        const projects = new Set(data.projects);
        projects.forEach((project) => {
          const option = document.createElement("option");
          option.value = project;
          option.textContent = project;
          projectDropdown.appendChild(option);
        });
      })
      .catch((error) => console.error("Error fetching projects:", error));
  }

  // -------------------------------
  // Update Categories
  // -------------------------------
  projectDropdown.addEventListener("change", function () {
    const projectName = projectDropdown.value;
    if (projectName) updateCategories(projectName);
  });

  function updateCategories(projectName) {
    categoryDropdown.innerHTML = '<option value="">Select Category</option>';

    fetch(`/get_project_data/?project_name=${projectName}&week_offset=0`)
      .then((response) => response.json())
      .then((data) => {
        const categories = new Set(data.categories);
        categories.forEach((category) => {
          const option = document.createElement("option");
          option.value = category;
          option.textContent = category;
          categoryDropdown.appendChild(option);
        });
      })
      .catch((error) => console.error("Error fetching categories:", error));
  }

  // -------------------------------
  // Update Weeks
  // -------------------------------
  function updateWeeks() {
    weekDropdown.innerHTML = "";
    fetch(`/get_project_data/?department=&project_name=&category=&week_offset=0`)
      .then((response) => response.json())
      .then((data) => {
        const weeks = data.weeks;
        weeks.forEach((week) => {
          const option = document.createElement("option");
          option.value = week.value;
          option.textContent = week.label;
          weekDropdown.appendChild(option);
        });
      })
      .catch((error) => console.error("Error fetching weeks:", error));
  }

  // -------------------------------
  // Fetch and Display Project Data + Weekly Totals
  // -------------------------------
function fetchProjectData() {
  const department = departmentDropdown.value;
  const projectName = projectDropdown.value;
  const category = categoryDropdown.value;
  const selectedWeek = weekDropdown.value;

  const projectContainer = document.getElementById("projectDataContainer");
  const summaryContainer = document.getElementById("weekly-summary");

  projectContainer.innerHTML = "";
  summaryContainer.innerHTML = "";

  const weeklySummary = {};
  let totalHours = 0;

  // 1️⃣ Get all week offsets (including current week)
  const weekOptions = Array.from(weekDropdown.options)
    .filter(opt => opt.value !== "")
    .map(opt => opt.value);

  // 2️⃣ Fetch data for all weeks
  const fetches = weekOptions.map(weekOffset =>
    fetch(`/get_project_data/?department=${department}&project_name=${projectName}&category=${category}&week_offset=${weekOffset}`)
      .then(res => res.json())
      .catch(() => ({ project_data: [] }))
  );

  Promise.all(fetches)
    .then(allWeeksData => {
      // 3️⃣ Calculate week totals
      allWeeksData.forEach((weekData, index) => {
        const weekOffset = weekOptions[index];
        let weekLabel = "";

        // Map offset -> week label correctly
        if (weekOffset === "0") {
          weekLabel = "CW"; // Current week
        } else {
          const numWeeks = weekOptions.length;
          // Example: if numWeeks=7 and offset=-1 (6th index), label should be W6
          const weekNum = numWeeks - (Math.abs(weekOffset) - 1);
          weekLabel = `W${weekNum}`;
        }

        let weekTotal = 0;

        weekData.project_data.forEach(item => {
          const time = parseFloat(item.time) || 0;
          weekTotal += time;

          // Show only selected week's project data
          if (String(weekOffset) === String(selectedWeek)) {
            const div = document.createElement("div");
            div.classList.add("project-item");
            div.innerHTML = `
              <p><strong>PROJECT:</strong> ${item.projects}</p>
              <p><strong>CATEGORY:</strong> ${item.category}</p>
              <p><strong>DATE:</strong> ${item.date1}</p>
              <p><strong>TIME:</strong> ${item.time} HR</p>
            `;
            projectContainer.appendChild(div);
          }
        });

        // Always add even if week has no hours
        weeklySummary[weekLabel] = weekTotal;
        totalHours += weekTotal;
      });

      // 4️⃣ Render summary cards in correct order (CW → W6 → W1)
      const weekOrder = ["CW", "W6", "W5", "W4", "W3", "W2", "W1"];
      weekOrder.forEach(week => {
        const hours = weeklySummary[week] || 0;
        const card = document.createElement("div");
        card.classList.add("summary-card");
        if (week === "CW") card.classList.add("active-week");
        card.innerHTML = `<strong>${hours.toFixed(2)} HR</strong><p>${week}</p>`;
        summaryContainer.appendChild(card);
      });

      // 5️⃣ Add total time card
      const totalCard = document.createElement("div");
      totalCard.classList.add("summary-card", "total-card");
      totalCard.innerHTML = `<strong>${totalHours.toFixed(2)} HR</strong><p>TOTAL TIME</p>`;
      summaryContainer.appendChild(totalCard);
    })
    .catch(err => console.error("Error fetching weekly data:", err));
}


  // -------------------------------
  // Event Listeners
  // -------------------------------
  departmentDropdown.addEventListener("change", () => {
    updateProjects(departmentDropdown.value);
    fetchProjectData();
  });
  projectDropdown.addEventListener("change", () => {
    updateCategories(projectDropdown.value);
    fetchProjectData();
  });
  categoryDropdown.addEventListener("change", fetchProjectData);
  weekDropdown.addEventListener("change", fetchProjectData);

  // -------------------------------
  // Initial Setup
  // -------------------------------
  updateWeeks();
  fetchDepartments();
});
