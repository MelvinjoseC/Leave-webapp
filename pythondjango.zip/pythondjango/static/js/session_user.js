(function () {
    const dataElement = document.getElementById("app-user-data");
    if (!dataElement) {
        return;
    }

    try {
        const rawJson = dataElement.textContent.trim();
        if (!rawJson || rawJson === '{}') {
            window.APP_USER = window.APP_USER || null;
            return;
        }

        let parsed;
        try {
            parsed = JSON.parse(rawJson);
        } catch (primaryError) {
            const sanitized = rawJson
                .replace(/^"+|"+$/g, '')
                .replace(/\\"/g, '"');
            parsed = JSON.parse(sanitized);
        }

        window.APP_USER = window.APP_USER || parsed;
    } catch (error) {
        console.error("Failed to parse session user data:", error);
        window.APP_USER = window.APP_USER || null;
    }
})();
