let table;
let globalFetchData = {};
let selectedRowsData = [];
let commentContext = { rowIndex: null, day: null };
let lastSelectedRowData = null; // used in row click handler
let copyBuffer = [];
let userEffectiveness = 100; // default

fetch('/api/get_user_effectiveness/')
    .then(res => res.json())
    .then(data => {
        if (data.effectiveness) {
            userEffectiveness = parseFloat(data.effectiveness);
        }
    })
    .catch(() => {
        console.warn("⚠️ Failed to fetch effectiveness, using default 100%");
    });

function makeUUID() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
    const r = Math.random()*16|0, v = c === 'x' ? r : (r&0x3|0x8);
    return v.toString(16);
  });
}

/* =========================
   Stable row identity key
   ========================= */
function makeRowKey(row) {
    return [
        row?.projects || '',
        row?.scope || '',
        row?.title || '',
        row?.category || ''
    ].join('||');
}

$(document).ready(function () {
    fetch('/api/get_hoursheet_data/')
        .then(res => res.json())
        .then(response => {
            globalFetchData = response;
            const processedData = aggregateCurrentWeek(response.data);
            initializeTable(processedData);
        });

    function aggregateCurrentWeek(data) {
        const today = new Date();
        const startOfWeek = new Date(today.setDate(today.getDate() - today.getDay() + 1)); // Monday
        const endOfWeek = new Date(startOfWeek.getTime() + 6 * 86400000); // Sunday

        console.log("Start of week:", startOfWeek.toISOString().split("T")[0]);
        console.log("End of week:", endOfWeek.toISOString().split("T")[0]);

        const rowsToInclude = [];

        data.forEach(entry => {
            const total_hours = ['mon','tue','wed','thur','fri','sat','sun']
                .reduce((sum, d) => sum + (parseFloat(entry[d]) || 0), 0);

            // ✅ Always keep every entry for table display
            entry.total_hours = total_hours.toFixed(2);
            entry.row_id = entry.id || entry.uuid || makeUUID();
            rowsToInclude.push(entry);
        });

        // Add one empty row at the bottom
        rowsToInclude.push({
            projects: '', scope: '', title: '', category: '',
            mon: 0, tue: 0, wed: 0, thur: 0, fri: 0, sat: 0, sun: 0,
            total_hours: 0, comments: {},
            row_id: makeUUID() // ✅ stable identity for blank row

        });

        console.log("Filtered weekly rows:", rowsToInclude);
        return rowsToInclude;
    }

    function generateSelect(className, options, selected) {
        let opts = options.map(opt => {
            const sel = opt === selected ? 'selected' : '';
            return `<option value="${opt}" ${sel}>${opt}</option>`;
        }).join('');
        return `<select class="inline-filter ${className}"><option value="">SELECT</option>${opts}</select>`;
    }

    function getFilteredOptions(key, filters) {
        return [...new Set(globalFetchData.dropdowns
            .filter(entry => {
                return Object.keys(filters).every(k => filters[k] === '' || entry[k] === filters[k]);
            })
            .map(entry => entry[key])
            .filter(Boolean))];
    }

    function initializeTable(data) {
        // Destroy table if it's already initialized
        if ($.fn.DataTable.isDataTable('#hoursheet-table')) {
            table.clear().destroy(); // Safely clear and destroy
            selectedRowsData = [];
            $('#select-all-rows').prop('checked', false);
        }

        table = $('#hoursheet-table').DataTable({
            data,
            rowId: 'row_id',  // ✅ true stable identity
            autoWidth: false,
            paging: false,
            ordering: false,
            info: false,
            searching: false,
            select: true,
            columns: [
                {
                    data: null,
                    orderable: false,
                    className: 'row-select-checkbox',
                    render: () => `<input type="checkbox" class="row-select-checkbox">`
                },
                {
                    data: 'projects',
                    render: (d, t, r) => {
                        const projects = getFilteredOptions('projects', {});
                        return generateSelect('project-filter', projects, d);
                    }
                },
                {
                    data: 'scope',
                    render: (d, t, r) => {
                        const scopes = getFilteredOptions('scope', { projects: r.projects });
                        return generateSelect('scope-filter', scopes, d);
                    }
                },
                {
                    data: 'title',
                    render: (d, t, r) => {
                        const titles = getFilteredOptions('title', { projects: r.projects, scope: r.scope });
                        return generateSelect('task-filter', titles, d);
                    }
                },
                {
                    data: 'category',
                    render: (d, t, r) => {
                        const cats = getFilteredOptions('category', { projects: r.projects, scope: r.scope, title: r.title });
                        return generateSelect('category-filter', cats, d);
                    }
                },
                ...['mon', 'tue', 'wed', 'thur', 'fri', 'sat', 'sun'].map(day => ({
                    data: day,
                    className: 'editable',
                    render: function (data, type, row, meta) {
                        return `<div class='time-cell' data-day="${day}">
                                <span>${data}</span>
                            </div>
                            <button class='comment-button' data-day="${day}" data-row="${meta.row}">💬</button>`;
                    }
                })),
                {
                    data: 'total_hours',
                    render: function (data, type, row) {
                        const total = ['mon', 'tue', 'wed', 'thur', 'fri', 'sat', 'sun']
                            .reduce((sum, day) => sum + (parseFloat(row[day]) || 0), 0);
                        return total.toFixed(2);
                    }
                },
                {
                    data: 'total_hours_effective',
                    render: function (data, type, row) {
                        const total = ['mon', 'tue', 'wed', 'thur', 'fri', 'sat', 'sun']
                            .reduce((sum, day) => sum + (parseFloat(row[day]) || 0), 0);

                        const effective = (total * userEffectiveness) / 100;
                        const rounded = Math.round(effective * 2) / 2;

                        return rounded.toFixed(1);
                    }
                }


            ]
        });

        // Handle "Select All" checkbox
        $('#select-all-rows').off('change').on('change', function () {
            const isChecked = $(this).is(':checked');

            $('#hoursheet-table tbody input.row-select-checkbox').prop('checked', isChecked).trigger('change');

            if (isChecked) {
                // Add all visible rows to buffer (unique by key)
                $('#hoursheet-table tbody tr').each(function () {
                    const rowData = table.row(this).data();
                    if (rowData && !copyBuffer.some(r => makeRowKey(r) === makeRowKey(rowData))) {
                        copyBuffer.push({
                            projects: rowData.projects,
                            scope: rowData.scope,
                            title: rowData.title,
                            category: rowData.category,
                            row_key: makeRowKey(rowData)
                        });
                    }
                });
            } else {
                // Clear buffer if deselecting all
                copyBuffer = [];
            }
        });

        // Handle checkbox selection in the table rows
        $('#hoursheet-table tbody').on('click', 'tr', function () {
            const row = table.row(this);
            if (row.any()) {
                lastSelectedRowData = row.data();  // Store the selected row
            }
        });

        // Enhance selects with select2 on hover
        $('#hoursheet-table tbody').on('mouseenter', 'select.inline-filter', function () {
        const $sel = $(this);
        if (!$sel.hasClass('select2-hidden-accessible')) {
            $sel.select2({
            width: 'resolve',
            dropdownAutoWidth: true
            });
        }
        });




        /* ==========================================================
           SINGLE dropdown-change handler with MERGE (no duplicates)
           ========================================================== */
        $('#hoursheet-table tbody').on('change', '.inline-filter', function () {
            const $select = $(this);
            const rowIdx = table.row($select.closest('tr')).index();
            const rowData = table.row(rowIdx).data();
            const colIdx = $select.closest('td').index();
            const colName = table.column(colIdx).dataSrc();

            // Apply change
            rowData[colName] = $select.val();

            // Reset dependent dropdowns
            if (colName === 'projects') {
                rowData.scope = '';
                rowData.title = '';
                rowData.category = '';
            } else if (colName === 'scope') {
                rowData.title = '';
                rowData.category = '';
            } else if (colName === 'title') {
                rowData.category = '';
            }

            // ✅ Always update the SAME row — do not create/remove
            rowData.row_key = makeRowKey(rowData);  // only for backend dedupe if needed
            table.row(rowIdx).data(rowData).draw(false);
        });

    }

    // Track selected rows uniquely by row_key
    $('#hoursheet-table').on('change', 'input.row-select-checkbox', function () {
        const rowData = table.row($(this).closest('tr')).data();
        if (!rowData) return;

        if ($(this).is(':checked')) {
            if (!selectedRowsData.some(r => r.row_id === rowData.row_id)) {
                selectedRowsData.push(rowData);
            }
        } else {
            selectedRowsData = selectedRowsData.filter(r => r.row_id !== rowData.row_id);
        }
    });
    // When a row checkbox is ticked, store/remove it in copyBuffer (unique by key)
    $('#hoursheet-table').on('change', 'input.row-select-checkbox', function () {
        const rowData = table.row($(this).closest('tr')).data();
        if ($(this).is(':checked')) {
            if (!copyBuffer.some(r => r.row_id === rowData.row_id)) {
                copyBuffer.push({
                    projects: rowData.projects,
                    scope: rowData.scope,
                    title: rowData.title,
                    category: rowData.category,
                    row_id: rowData.row_id
                });
                }
        } else {
            copyBuffer = copyBuffer.filter(r => r.row_id !== rowData.row_id);
        }
    });

    // Copy button always pastes from buffer
    $('#copyRowBtn').off('click').on('click', function () {
        if (copyBuffer.length === 0) {
            alert("Please select one or more rows to copy first.");
            return;
        }

        copyBuffer.forEach(src => {
            const candidate = {
                projects: src.projects,
                scope: src.scope,
                title: src.title,
                category: src.category,
                mon: 0, tue: 0, wed: 0, thur: 0, fri: 0, sat: 0, sun: 0,
                total_hours: 0,
                comments: {}
            };
            candidate.row_id = makeUUID(); // new row → new id
            table.row.add(candidate);
        });

        table.draw(false);

        const { startDate, endDate } = getDisplayedWeek();
        alert(`Pasted ${copyBuffer.length} row(s) into week ${startDate} to ${endDate}.`);
    });

    function getDisplayedWeek() {
        return {
            startDate: ($('#week-start-date').text() || '').trim(),
            endDate: ($('#week-end-date').text() || '').trim(),
        };
    }

    // Column search per inline filter
    $('#hoursheet-table').on('change', '.inline-filter', function () {
        const $select = $(this);
        const selectedValue = $select.val();
        const columnIdx = $select.closest('td').index();
        table.column(columnIdx).search(selectedValue).draw();
    });

    // In-cell time editing
    $('#hoursheet-table tbody').on('click', 'td.editable', function (e) {
        if ($(e.target).hasClass('comment-button')) return;

        const $cell = $(this);
        const rowIdx = table.row($cell.closest('tr')).index();
        const data = table.row(rowIdx).data();
        const day = $cell.find('.time-cell').data('day');

        if (!day) return;

        const input = $('<input type="number" min="0" step="0.25">').val(data[day]);

        $cell.html(`<div class='time-cell' data-day="${day}"></div>`);
        $cell.find('.time-cell').append(input);

        input.focus().on('blur', function () {
            const val = parseFloat(input.val()) || 0;
            data[day] = val;

            data.total_hours = ['mon', 'tue', 'wed', 'thur', 'fri', 'sat', 'sun']
                .reduce((sum, d) => sum + (parseFloat(data[d]) || 0), 0)
                .toFixed(2);

            table.row(rowIdx).data(data).draw(false);
        });
    });

    // Add row
    $('#addRowButton').on('click', function () {
        const newRow = {
            projects: '',
            scope: '',
            title: '',
            category: '',
            mon: 0, tue: 0, wed: 0, thur: 0, fri: 0, sat: 0, sun: 0,
            total_hours: 0,
            comments: {}
        };
        newRow.row_key = makeRowKey(newRow); // ✅ attach key
        table.row.add(newRow).draw(false);
    });

    // Delete rows
    $('#deleteRowBtn').on('click', async function () {
        if (selectedRowsData.length === 0) {
            alert("Please select one or more rows to delete.");
            return;
        }

        if (!confirm("Are you sure you want to delete the selected rows?")) return;

        for (const rowData of selectedRowsData) {
            const weekStart = document.getElementById('week-start-date').textContent.trim();

            const res = await fetch('/api/delete_timesheet_row/', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    row_id: rowData.row_id,
                    projects: rowData.projects,
                    scope: rowData.scope,
                    title: rowData.title,
                    category: rowData.category,
                    week_start: weekStart   // 👈 add this
                })
            });


            const json = await res.json();
            if (json.status === 'success') {
                table.rows((idx, data) => (
                    data.projects === rowData.projects &&
                    data.scope === rowData.scope &&
                    data.title === rowData.title &&
                    data.category === rowData.category
                )).remove().draw(false);
            } else {
                alert("Error deleting row: " + json.message);
            }
        }

        selectedRowsData = [];
    });

    // Comments popup
    $(document).on('click', '.comment-button', function (e) {
        e.stopPropagation();
        commentContext.day = $(this).data('day');
        commentContext.rowIndex = $(this).data('row');
        const rowData = table.row(commentContext.rowIndex).data();
        $('#commentText').val(rowData.comments?.[commentContext.day] || "");
        $('#commentPopup').show();
    });

    $('#saveCommentBtn').on('click', function () {
        const val = $('#commentText').val();
        const rowData = table.row(commentContext.rowIndex).data();
        if (!rowData.comments) rowData.comments = {};
        rowData.comments[commentContext.day] = val;
        table.row(commentContext.rowIndex).data(rowData).draw(false);
        $('#commentPopup').hide();
    });

    $('#closeCommentBtn').on('click', function () {
        $('#commentPopup').hide();
    });

    // Submit timesheet
    $('#submitTimesheetButton').on('click', async function () {
        const allData = table.rows().data().toArray();
        // NEW → take from UI (the week user is on)
        const startOfWeekStr = document.getElementById('week-start-date').textContent.trim();
        const startOfWeek = new Date(startOfWeekStr);


        const payloadMap = {};
        let isValid = true;
        let errorMessage = "";
        let anyColumnModified = false;

        allData.forEach((row, rowIndex) => {
            const isCompletelyBlank = !row.projects && !row.scope && !row.title && !row.category &&
                ['mon','tue','wed','thur','fri','sat','sun'].every(day => !parseFloat(row[day] || 0));

            if (isCompletelyBlank) return;

            let rowHasTime = false;

            ['mon','tue','wed','thur','fri','sat','sun'].forEach((day, idx) => {
                const val = parseFloat(row[day]) || 0;
                const comment = row.comments?.[day] || '';

                if (val > 24) {
                    isValid = false;
                    errorMessage = `Row ${rowIndex + 1}: Time for ${day.toUpperCase()} cannot exceed 24 hours.`;
                    return;
                }

                if (val > 0) {
                    rowHasTime = true;

                    const date = new Date(startOfWeek);
                    date.setDate(startOfWeek.getDate() + idx);

                    const dateStr = date.toISOString().split("T")[0];

                    const key = `${row.projects}||${row.scope}||${row.title}||${row.category}||${dateStr}`;

                    payloadMap[key] = {
                        id: row.id || null,
                        projects: row.projects,
                        scope: row.scope,
                        title: row.title,
                        category: row.category,
                        time: val.toFixed(2),
                        comments: comment,
                        date1: dateStr,
                        task_benchmark: row.task_benchmark || null,
                        d_no: row.d_no || "",
                        rev: row.rev || "",
                        mail_no: row.mail_no || "",
                        ref_no: row.ref_no || "",
                        list: row.list || ""
                    };


                }
            });

            if (!rowHasTime) {
                isValid = false;
                errorMessage = `Row ${rowIndex + 1}: All 7 days are empty. At least one time must be entered.`;
                return;
            }

            if (!row.projects || !row.scope || !row.title || (!row.category && row.category_required !== false)) {
                isValid = false;
                errorMessage = `Row ${rowIndex + 1}: Project, Scope, Task, and Category are mandatory.`;
                return;
            }

            anyColumnModified = true;
        });

        if (!anyColumnModified) {
            alert("Nothing to submit.");
            return;
        }

        if (!isValid) {
            alert(errorMessage);
            return;
        }

        const payload = Object.values(payloadMap);

        try {
            for (const entry of payload) {
                const today = new Date();
                    const entryDate = new Date(entry.date1);

                    if (entryDate > today) {
                        alert(`⚠️ You cannot enter time for a future date (${entry.date1}).`);
                        continue; // skip this entry
                    }

                if (entry.row_id && !entry.row_id.startsWith("xxxx")) {
                    // ✅ Update existing row
                    await fetch('/api/submit_timesheet/', {
                        method: 'PUT',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(entry)
                    });
                } else {
                    // ✅ Insert new row
                    await fetch('/api/submit_timesheet/', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(entry)
                    });
                }
            }

            alert("Saved successfully.");
        } catch (err) {
            console.error("❌ Save failed:", err);
            alert("Error saving timesheet.");
        }
    });

    const today = new Date();
    $('#hoursheet-table tbody td.editable').each(function() {
        const dayName = $(this).find('.time-cell').data('day');
        if (!dayName) return;

        const dayIndex = ['mon','tue','wed','thur','fri','sat','sun'].indexOf(dayName);
        const startOfWeek = new Date(document.getElementById('week-start-date').textContent);
        const cellDate = new Date(startOfWeek);
        cellDate.setDate(startOfWeek.getDate() + dayIndex);

        if (cellDate > today) {
            $(this).addClass('disabled');
            $(this).css('opacity', '0.5');
            $(this).off('click'); // disable editing
        }
    });

    // Fetch week data (rebuild keys)
    function fetchWeekData(startDate, endDate) {
        fetch(`/api/get_hoursheet_data/?start_date=${startDate}&end_date=${endDate}`)
            .then(res => res.json())
            .then(response => {
                globalFetchData = response;
                let filtered = response.data;

                const weekRows = filtered.filter(entry => {
                    const hasTime = ['mon', 'tue', 'wed', 'thur', 'fri', 'sat', 'sun']
                        .some(day => parseFloat(entry[day]) > 0);
                    return true; // Keep all rows including blanks
                });

                weekRows.forEach(entry => {
                    const total = ['mon', 'tue', 'wed', 'thur', 'fri', 'sat', 'sun']
                        .reduce((s, d) => s + (parseFloat(entry[d]) || 0), 0);
                    entry.total_hours = total.toFixed(2);
                    entry.row_id = entry.id || entry.uuid || makeUUID(); // ✅ stable id on fetch

                });

                if (weekRows.length === 0) {
                    weekRows.push({
                        projects: '', scope: '', title: '', category: '',
                        mon: 0, tue: 0, wed: 0, thur: 0, fri: 0, sat: 0, sun: 0,
                        total_hours: 0, comments: {},
                        row_id: makeUUID()
                    });
                }

                if (table) {
                    table.clear().rows.add(weekRows).draw(false);
                } else {
                    initializeTable(weekRows);
                }
            });
    }

    // Week nav helpers
    let currentWeekStart = new Date();  // Initialize with current week's start date
    let currentWeekEnd = new Date();    // Initialize with current week's end date

    function getWeekDates(date) {
        const currentDate = new Date(date);
        const dayOfWeek = currentDate.getDay() || 7;
        const startOfWeek = new Date(currentDate);
        startOfWeek.setDate(currentDate.getDate() - dayOfWeek + 1);
        const endOfWeek = new Date(startOfWeek);
        endOfWeek.setDate(startOfWeek.getDate() + 6);

        const startDate = startOfWeek.toISOString().split('T')[0];
        const endDate = endOfWeek.toISOString().split('T')[0];

        return { startDate, endDate };
    }

    function getYearlyWeek(date) {
        const startOfYear = new Date(date.getFullYear(), 0, 1);
        const diff = date - startOfYear;
        const oneDay = 1000 * 60 * 60 * 24;
        const dayOfYear = Math.floor(diff / oneDay);
        const weekNumber = Math.ceil((dayOfYear + 1) / 7);
        return weekNumber;
    }

    function updateDateTime() {
        const { startDate, endDate } = getWeekDates(currentWeekStart);
        const yearlyWeek = getYearlyWeek(currentWeekStart);

        document.getElementById('current-date2').textContent = new Date().toLocaleDateString();
        document.getElementById('current-time2').textContent = new Date().toLocaleTimeString();

        document.getElementById('week-start-date').textContent = startDate;
        document.getElementById('week-end-date').textContent = endDate;
        document.getElementById('yearly-week').textContent = yearlyWeek;

        fetchWeekData(startDate, endDate);
    }

    document.getElementById('prevWeekButton').addEventListener('click', function () {
        currentWeekStart.setDate(currentWeekStart.getDate() - 7);
        updateDateTime();
    });

    document.getElementById('nextWeekButton').addEventListener('click', function () {
        const today = new Date();
        const nextWeekStart = new Date(currentWeekStart);
        nextWeekStart.setDate(currentWeekStart.getDate() + 7);

        // 🚫 Prevent moving past this week
        if (nextWeekStart > today) {
            alert("⚠️ You cannot enter or view timesheets for future weeks.");
            return;
        }

        currentWeekStart = nextWeekStart;
        updateDateTime();
    });


    setInterval(() => {
        document.getElementById('current-date2').textContent = new Date().toLocaleDateString();
        document.getElementById('current-time2').textContent = new Date().toLocaleTimeString();
    }, 1000);

    // Initial update when the page loads
    updateDateTime();

    // --- SECOND ready block (kept; functions preserved) ---
    let currentWeekStartDate = new Date();
    let currentWeekEndDate = new Date();

    $('.filter-select').select2({ placeholder: "Select", allowClear: true });

    function getWeekDates2(date) { // renamed to avoid clobbering
        const currentDate = new Date(date);
        const dayOfWeek = currentDate.getDay() || 7;
        const startOfWeek = new Date(currentDate);
        startOfWeek.setDate(currentDate.getDate() - dayOfWeek + 1);
        const endOfWeek = new Date(startOfWeek);
        endOfWeek.setDate(startOfWeek.getDate() + 6);
        return {
            startDate: startOfWeek.toISOString().split('T')[0],
            endDate: endOfWeek.toISOString().split('T')[0]
        };
    }

    function populateDropdown($dropdown, values) {
        $dropdown.empty().append(`<option value="">Select</option>`);
        if (values.length === 0) {
            $dropdown.append(`<option disabled>No results found</option>`);
            return;
        }
        values.forEach(val => {
            $dropdown.append(`<option value="${val}">${val}</option>`);
        });
        $dropdown.trigger('change.select2');
    }

    function fetchFilterData(startDate, endDate, selected = {}) {
        $.ajax({
            url: '/api/get_filter_data/',
            data: {
                start_date: startDate,
                end_date: endDate,
                project: selected.project || '',
                scope: selected.scope || '',
                task: selected.task || ''
            },
            method: 'GET',
            success: function (data) {
                // Only reset dependent filters to prevent full resets
                if (!selected.project) {
                    populateDropdown($('#project-filters'), data.projects || []);
                    populateDropdown($('#scope-filters'), []);
                    populateDropdown($('#title-filters'), []);
                    populateDropdown($('#category-filters'), []);
                } else if (!selected.scope) {
                    populateDropdown($('#scope-filters'), data.scopes || []);
                    populateDropdown($('#title-filters'), []);
                    populateDropdown($('#category-filters'), []);
                } else if (!selected.task) {
                    populateDropdown($('#title-filters'), data.tasks || []);
                    populateDropdown($('#category-filters'), []);
                } else {
                    populateDropdown($('#category-filters'), data.categories || []);
                }

                filterRowsBasedOnHeaderFilters(); // Update rows after filters update
            },
            error: function (error) {
                console.error("Error fetching filter data:", error);
            }
        });
    }

    const indexes = {
        project: 1,
        scope: 2,
        task: 3,
        category: 4
    };

    function getRowsForSelectedWeek() {
        const rowsForWeek = [];
        $('#hoursheet-table tbody tr').each(function () {
            const $row = $(this);
            const taskDate = new Date($row.data('date'));
            const startDate = new Date(currentWeekStartDate);
            const endDate = new Date(currentWeekEndDate);

            if (taskDate >= startDate && taskDate <= endDate) {
                rowsForWeek.push($row);
            }
        });
        return rowsForWeek;
    }

    function filterRowsBasedOnHeaderFilters() {
        const selectedProject = $('#project-filters').val();
        const selectedScope = $('#scope-filters').val();
        const selectedTask = $('#title-filters').val();
        const selectedCategory = $('#category-filters').val();

        $('#hoursheet-table tbody tr').each(function () {
            const $row = $(this);
            const cells = $row.find('td');

            const project = cells.eq(indexes.project).find('select option:selected').text().trim();
            const scope = cells.eq(indexes.scope).find('select option:selected').text().trim();
            const task = cells.eq(indexes.task).find('select option:selected').text().trim();
            const category = cells.eq(indexes.category).find('select option:selected').text().trim();

            const matches =
                (!selectedProject || project === selectedProject) &&
                (!selectedScope || scope === selectedScope) &&
                (!selectedTask || task === selectedTask) &&
                (!selectedCategory || category === selectedCategory);

            $row.toggle(matches);
        });
    }

    // Cascading filter behavior (kept)
    $('#project-filters').on('change', function () {
        $('#scope-filters').val('').trigger('change');
        $('#title-filters').val('').trigger('change');
        $('#category-filters').val('').trigger('change');

        const selectedProject = $(this).val();
        const { startDate, endDate } = getWeekDates2(currentWeekStartDate);
        fetchFilterData(startDate, endDate, { project: selectedProject });
    });

    $('#scope-filters').on('change', function () {
        $('#title-filters').val('').trigger('change');
        $('#category-filters').val('').trigger('change');

        const selectedProject = $('#project-filters').val();
        const selectedScope = $(this).val();
        const { startDate, endDate } = getWeekDates2(currentWeekStartDate);
        fetchFilterData(startDate, endDate, { project: selectedProject, scope: selectedScope });
    });

    $('#title-filters').on('change', function () {
        $('#category-filters').val('').trigger('change');

        const selectedProject = $('#project-filters').val();
        const selectedScope = $('#scope-filters').val();
        const selectedTask = $(this).val();
        const { startDate, endDate } = getWeekDates2(currentWeekStartDate);
        fetchFilterData(startDate, endDate, { project: selectedProject, scope: selectedScope, task: selectedTask });
    });

    $('#category-filters').on('change', function () {
        filterRowsBasedOnHeaderFilters();
    });

    function initializeFilteredTable() {
        $('#hoursheet-table tbody tr').each(function () {
            $(this).show();
        });
        filterRowsBasedOnHeaderFilters();
    }

    function updateDateTime2() { // renamed to avoid clobbering
        const { startDate, endDate } = getWeekDates2(currentWeekStartDate);
        currentWeekEndDate = new Date(endDate);

        document.getElementById('week-start-date').textContent = startDate;
        document.getElementById('week-end-date').textContent = endDate;

        fetchFilterData(startDate, endDate); // full reset on week change
        fetchWeekData(startDate, endDate);   // loads table data
    }

    $('#prevWeekButton').on('click', function () {
        currentWeekStartDate.setDate(currentWeekStartDate.getDate() - 7);
        updateDateTime2();
    });

    $('#nextWeekButton').on('click', function () {
        const today = new Date();
        const nextWeekStart = new Date(currentWeekStartDate);
        nextWeekStart.setDate(currentWeekStartDate.getDate() + 7);

        if (nextWeekStart > today) {
            alert("⚠️ Cannot navigate to a future week.");
            return;
        }

        currentWeekStartDate = nextWeekStart;
        updateDateTime2();
    });


    // Initial Load for the second block
    const { startDate: s2, endDate: e2 } = getWeekDates2(currentWeekStartDate);
    currentWeekEndDate = new Date(e2);
    fetchFilterData(s2, e2);
});
