const form = document.getElementById('projectForm');
form.addEventListener('submit', async function (e) {
    e.preventDefault();
    
    const formData = new FormData(form);
    const data = Object.fromEntries(formData.entries());

    // Send data to the backend
    const response = await fetch('/add-project-ranking/', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(data)
    });

    const result = await response.json();

    // Handle responses
    if (result.status === 'created') {
        alert('Project ranking added!');
    } else if (result.status === 'updated') {
        alert('Project ranking updated!');
    } else {
        alert('An error occurred. Please try again.');
    }

    form.reset();
});

// Load the table
async function loadTable() {
    const res = await fetch('/get-project-rankings/');
    const data = await res.json();
    const tbody = document.querySelector('#rankingTable tbody');
    tbody.innerHTML = '';

    data.forEach(row => {
        // Skip rows with no date
        if (!row.date) return;

        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${row.project_name}</td>
            <td>${row.project_assigned}</td>
            <td>${row.date}</td>
            <td>${getStars(row.speed_of_execution)}</td>
            <td>${getStars(row.complaints_of_check_list)}</td>
            <td>${getStars(row.task_ownership)}</td>
            <td>${getStars(row.understanding_task)}</td>
            <td>${getStars(row.quality_of_work)}</td>
        `;
        tbody.appendChild(tr);
    });
}

// Edit function
async function editRow(project_name, project_assigned) {
    const response = await fetch(`/get-project-member-details/?project_name=${project_name}&project_assigned=${project_assigned}`);
    const data = await response.json();
    
    // Populate the form with the fetched data
    document.getElementById('project_name').value = data.project_name;
    document.getElementById('project_assigned').value = data.project_assigned;
    document.getElementById('speed_of_execution').value = data.speed_of_execution;
    document.getElementById('complaints_of_check_list').value = data.complaints_of_check_list;
    document.getElementById('task_ownership').value = data.task_ownership;
    document.getElementById('understanding_task').value = data.understanding_task;
    document.getElementById('quality_of_work').value = data.quality_of_work;

    alert(`You are now editing the ranking for ${project_name} - ${project_assigned}`);
    loadTable();
}

function getStars(rating) {
    const filledStar = '<span style="color: orange;">★</span>';
    const emptyStar = '<span style="color: #ccc;">☆</span>';
    return filledStar.repeat(rating) + emptyStar.repeat(5 - rating);
}

document.addEventListener('DOMContentLoaded', function () {
    fetch('/get-project-details/')
        .then(res => res.json())
        .then(data => {
            const projectDropdown = document.getElementById('project_name_dropdown');
            const assignedDropdown = document.getElementById('project_assigned_dropdown');

            const projectMap = {};

            // Group assigned users by project name
            data.forEach(item => {
                const project = item.project_name;
                const assignees = item.project_assigned ? item.project_assigned.split(',').map(a => a.trim()) : [];

                if (!projectMap[project]) {
                    projectMap[project] = new Set();
                }
                assignees.forEach(a => projectMap[project].add(a));
            });

            // Populate project name dropdown
            Object.keys(projectMap).forEach(project => {
                const option = document.createElement('option');
                option.value = project;
                option.textContent = project;
                projectDropdown.appendChild(option);
            });

            // Handle assigned dropdown on project selection
            projectDropdown.addEventListener('change', function () {
                const selectedProject = this.value;
                const assignees = Array.from(projectMap[selectedProject] || []);
                assignedDropdown.innerHTML = '<option value="">-- Select Assignee --</option>';

                assignees.forEach(assignee => {
                    const option = document.createElement('option');
                    option.value = assignee;
                    option.textContent = assignee;
                    assignedDropdown.appendChild(option);
                });
            });
        })
        .catch(error => {
            console.error("Error fetching project details:", error);
        });
});

document.addEventListener('DOMContentLoaded', () => {
    const starContainers = document.querySelectorAll('.star-rating');

    starContainers.forEach(container => {
        const name = container.getAttribute('data-name');
        for (let i = 1; i <= 5; i++) {
            const star = document.createElement('span');
            star.classList.add('star');
            star.innerHTML = '★';
            star.dataset.value = i;

            star.addEventListener('click', () => {
                container.dataset.selected = i;
                updateStars(container, i);
            });

            container.appendChild(star);
        }

        // Hidden input to carry star value for form submission
        const hiddenInput = document.createElement('input');
        hiddenInput.type = 'hidden';
        hiddenInput.name = name;
        container.appendChild(hiddenInput);
    });

    function updateStars(container, value) {
        const stars = container.querySelectorAll('.star');
        stars.forEach(star => {
            star.style.color = star.dataset.value <= value ? 'gold' : '#ccc';
        });
        container.querySelector('input[type="hidden"]').value = value;
    }
});

document.addEventListener('DOMContentLoaded', function () {
    const searchContainer = document.querySelector('.search-history');
    const rankDiv = document.getElementById('rank');

    // Hide the search container and show rank list immediately
    if (searchContainer) searchContainer.style.display = 'none';
    if (rankDiv) rankDiv.style.display = 'block';

    // Automatically load the ranking table
    loadTable();
});


document.addEventListener('DOMContentLoaded', function () {
    const cancelButton = document.querySelector('.cancel-button');
    const form = document.getElementById('projectForm');

    if (cancelButton && form) {
        cancelButton.addEventListener('click', function () {
            form.reset(); // Clears all input and select fields

            // Optional: Reset star ratings if you have them
            const stars = document.querySelectorAll('.star-rating .star');
            stars.forEach(star => star.style.color = '#ccc');

            // Optional: Reset dropdowns to first option
            const dropdowns = form.querySelectorAll('select');
            dropdowns.forEach(select => {
                if (select.options.length > 0) {
                    select.selectedIndex = 0;
                }
            });

        });
    }
});
