document.addEventListener("DOMContentLoaded", () => {
    fetch("/check_task_status/", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify({}),
    })
        .then((response) => response.json())
        .then((data) => {
            const container = document.getElementById("taskStatus");
            if (!container) {
                return;
            }

            const seenStatuses = new Set(
                JSON.parse(localStorage.getItem("seenStatuses")) || []
            );

            let content = "";

            if (data.projects && data.projects.length > 0) {
                content = data.projects
                    .map((proj) => {
                        const statusText = `${proj.project} is ${proj.status}`;
                        const isSeen = seenStatuses.has(statusText);
                        const style = isSeen
                            ? "color: green;"
                            : "color: blue; font-weight: bold;";

                        seenStatuses.add(statusText);
                        return `<span style="${style}">${statusText}</span>`;
                    })
                    .join("<br>");

                localStorage.setItem(
                    "seenStatuses",
                    JSON.stringify([...seenStatuses])
                );
            }

            container.innerHTML = content || "No project status available.";
        })
        .catch((error) => {
            const container = document.getElementById("taskStatus");
            if (container) {
                container.innerHTML = `Error fetching task status: ${error}`;
            }
        });
});
