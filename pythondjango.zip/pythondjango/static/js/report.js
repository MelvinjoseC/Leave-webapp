// document.addEventListener('DOMContentLoaded', function() {
//     // Download ALL Excel (no filter)
//     const downloadAllExcelBtn = document.getElementById('downloadAllExcel');
//     if (downloadAllExcelBtn) {
//         downloadAllExcelBtn.addEventListener('click', function() {
//             // Optional: You can include list if you want to filter "all" by list as well
//             // If not needed, leave as is:
//             window.location.href = '/export-excel/';
//         });
//     }

//     // Download SELECTED Excel (project + list)
//     const downloadSelectedExcelBtn = document.getElementById('downloadSelectedExcel');
//     if (downloadSelectedExcelBtn) {
//         downloadSelectedExcelBtn.addEventListener('click', function() {
//             const projectDropdown = document.getElementById('projectDropdown');
//             const listDropdown = document.getElementById('listDropdown');
//             const selectedProject = projectDropdown ? projectDropdown.value : '';
//             const selectedList = listDropdown ? listDropdown.value : '';

//             if (!selectedProject || !selectedList) return;

//             // Always encode URI components for safety
//             const url = '/export-excel/?project=' +
//                 encodeURIComponent(selectedProject) +
//                 '&list=' +
//                 encodeURIComponent(selectedList);
//             window.location.href = url;
//         });
//     }
// });
// html2canvas(document.body, {
//   useCORS: true,
//   crossOrigin: 'anonymous',
// });

// =======================================================
// 📘 PROJECT REPORT PDF GENERATOR (Smart Row Pagination + Chart Fix + Tight Table Padding)
// =======================================================
document.addEventListener("DOMContentLoaded", () => {
  const downloadBtn = document.getElementById("downloadSelectedPDF");
  if (!downloadBtn) return;
  downloadBtn.addEventListener("click", generateProjectPDF);
});

// =======================================================
// 🧩 MAIN FUNCTION
// =======================================================
async function generateProjectPDF() {
  if (!window.jspdf?.jsPDF || !window.html2canvas) {
    alert("Missing jsPDF or html2canvas");
    return;
  }

  const projectDropdown = document.getElementById("projectDropdown");
  const listDropdown = document.getElementById("listDropdown");
  const monthDropdown = document.getElementById("monthDropdown");

  const selectedProject = projectDropdown?.value?.trim();
  if (!selectedProject) return alert("Select a project first.");

  const selectedList = listDropdown?.value?.trim() || "";
  const monthVal = monthDropdown?.value || "";
  const [year, month] = monthVal.split("-") || [];

  const pdf = new jspdf.jsPDF("l", "pt", "a4");
  const pageWidth = pdf.internal.pageSize.getWidth();
  const pageHeight = pdf.internal.pageSize.getHeight();

  const overlay = showOverlay("Generating PDF... please wait");

  try {
    projectDropdown.dispatchEvent(new Event("change"));
    await sleep(400);

    // 🟨 Monthly Overview
    const overview = document.getElementById("monthlyOverview");
    if (overview)
      await captureAndPaginate(pdf, overview, pageWidth, pageHeight, "MONTHLY OVERVIEW");

    // 🟩 Loop through all tabs
    const tabs = [...document.querySelectorAll(".sheet-tabs li")].slice(1);
    let projectOverviewSection = null;

    for (const li of tabs) {
      li.click();
      await sleep(400);
      const tabId = li.getAttribute("data-tab");
      const section = document.getElementById(tabId);
      if (!section) continue;
      const title = li.textContent?.trim() || "";

      if (tabId === "project_overview_tab") {
        console.log("📘 Capturing PROJECT OVERVIEW...");
        projectOverviewSection = section;
        await captureLargeTableWithPagination(
          pdf,
          section,
          "PROJECT OVERVIEW",
          pageWidth,
          pageHeight
        );
      } else {
        await captureLargeTableWithPagination(pdf, section, title, pageWidth, pageHeight);
      }
    }

    // =======================================================
    // 📊 CAPTURE CHARTS FROM PROJECT OVERVIEW (SMART SPACE + 3 PER PAGE)
    // =======================================================
    if (projectOverviewSection) {
      console.log("📊 Capturing charts from Project Overview...");

      const chartCanvases = projectOverviewSection.querySelectorAll("canvas");
      console.log("Found charts:", chartCanvases.length);

      if (chartCanvases.length > 0) {
        const pageWidth = pdf.internal.pageSize.getWidth();
        const pageHeight = pdf.internal.pageSize.getHeight();
        const marginX = 40;
        const marginY = 40;
        const chartGap = 25;
        const maxChartsPerPage = 3;

        const lastPage = pdf.internal.getNumberOfPages();
        pdf.setPage(lastPage);

        let usedHeight =
          pdf.lastAutoTable?.finalY ||
          (pdf.internal.pageSize.getHeight() * 0.4);

        // 🧩 Reduce the gap but preserve full chart height
        let currentY = usedHeight; // small padding below table
        const availableHeight = pageHeight - marginY * 2; // full height available

        // ✅ Keep consistent chart height (no artificial shrink)
        const standardChartHeight = 205;


        let chartsPlacedOnPage = 0;

        for (let i = 0; i < chartCanvases.length; i++) {
          const canvas = chartCanvases[i];
          try {
            await sleep(150);
            const imgURL = canvas.toDataURL("image/png", 1.0);

            let chartWidth = pageWidth - marginX * 2;
            let chartHeight = (canvas.height * chartWidth) / canvas.width;
            if (chartHeight > standardChartHeight) chartHeight = standardChartHeight;

            if (i === 0 && currentY + chartHeight <= pageHeight - marginY) {
              pdf.addImage(imgURL, "PNG", marginX, currentY, chartWidth, chartHeight);
              currentY += chartHeight + chartGap;
              chartsPlacedOnPage++;
              continue;
            }

            if (currentY + chartHeight <= pageHeight - marginY) {
              pdf.addImage(imgURL, "PNG", marginX, currentY, chartWidth, chartHeight);
              currentY += chartHeight + chartGap;
              chartsPlacedOnPage++;
              continue;
            }

            pdf.addPage();
            currentY = marginY;
            chartsPlacedOnPage = 0;

            pdf.addImage(imgURL, "PNG", marginX, currentY, chartWidth, chartHeight);
            currentY += chartHeight + chartGap;
            chartsPlacedOnPage++;

            if (chartsPlacedOnPage >= maxChartsPerPage && i < chartCanvases.length - 1) {
              pdf.addPage();
              currentY = marginY;
              chartsPlacedOnPage = 0;
            }
          } catch (err) {
            console.warn("⚠️ Could not capture chart:", err);
          }
        }
      } else {
        console.warn("⚠️ No chart canvases found in Project Overview section.");
      }
    }

    // 💾 Save PDF
    const fileName = `${selectedProject} Timesheet - ${year || ""}.${month || ""}.pdf`;
    pdf.save(fileName);
  } catch (err) {
    console.error("❌ PDF generation failed:", err);
    alert("An error occurred while generating the PDF. Check the console for details.");
  } finally {
    removeOverlay(overlay);
  }
}

// =======================================================
// 🧱 HELPER FUNCTIONS
// =======================================================
function showOverlay(message) {
  const overlay = document.createElement("div");
  overlay.id = "pdfLoadingOverlay";
  overlay.innerHTML = `
    <div style="
      position:fixed;top:0;left:0;width:100%;height:100%;
      background:#0008;display:flex;align-items:center;
      justify-content:center;z-index:9999;color:#fff;font-size:20px;">
      ${message}
    </div>`;
  document.body.appendChild(overlay);
  return overlay;
}

function removeOverlay(overlay) {
  if (overlay && overlay.parentNode) overlay.parentNode.removeChild(overlay);
}

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

async function waitForImages(element) {
  const imgs = Array.from(element.querySelectorAll("img"));
  await Promise.all(
    imgs.map(
      (img) =>
        img.complete ||
        new Promise((res) => {
          img.onload = res;
          img.onerror = res;
        })
    )
  );
}

// =======================================================
// 🧮 CAPTURE + PAGINATION
// =======================================================
async function captureAndPaginate(pdf, element, pageWidth, pageHeight, title = "") {
  await waitForImages(element);
  await sleep(150);

  const canvas = await html2canvas(element, {
    scale: 2,
    useCORS: true,
    scrollY: -window.scrollY,
  });

  const imgData = canvas.toDataURL("image/jpeg", 0.98);

  const sidePad = pageHeight * 0.07;
  const topPad = pageHeight * 0.07;
  const botPad = pageHeight * 0.07;
  const pageDrawable = pageHeight - topPad - botPad;

  const imgWidth = pageWidth - sidePad * 2;
  const imgHeight = (canvas.height * imgWidth) / canvas.width;

  let heightLeft = imgHeight;
  let positionY = topPad;

  // ✅ Only add a new page if the current one already has content
  const isFirstPage = pdf.getNumberOfPages() === 1;
  const isEmptyFirstPage =
    isFirstPage &&
    (!pdf.internal.pages[1] || pdf.internal.pages[1].length <= 2);

  if (!isEmptyFirstPage) {
    pdf.addPage();
  }

  pdf.addImage(imgData, "JPEG", sidePad, positionY, imgWidth, imgHeight);

  heightLeft -= pageDrawable;

  while (heightLeft > 0) {
    pdf.addPage();
    positionY = heightLeft - imgHeight + topPad;
    pdf.addImage(imgData, "JPEG", sidePad, positionY, imgWidth, imgHeight);

    if (title) {
      pdf.setFontSize(12);
      pdf.text(title, sidePad + 4, Math.max(12, topPad - 6));
    }

    heightLeft -= pageDrawable;
  }
}

// =======================================================
// 🧩 TABLE PAGINATION WITH ROW GROUPING + FIXED COLUMNS
// =======================================================
async function captureLargeTableWithPagination(pdf, section, title, pageWidth, pageHeight) {
  const table = section.querySelector("table.main-table");
  if (!table) return;

  const headerHTML = table.querySelector("thead")?.outerHTML || "";
  const footerHTML = table.querySelector("tfoot")?.outerHTML || "";
  const rows = Array.from(table.querySelectorAll("tbody tr"));
  const tableWidth = table.offsetWidth;

  const overviewHeader =
    section.querySelector(
      ".overview-header, .overview-header1, .weekly-header, .project-header, .header-section, .top-header, .report-header"
    )?.outerHTML || "";

  const colWidths = Array.from(
    table.querySelectorAll("thead tr:first-child th, thead tr:first-child td")
  ).map((th) => th.offsetWidth);

  const topMargin = 10;
  const bottomMargin = 10;
  const usableHeight = pageHeight - topMargin - bottomMargin;

  const tempDiv = document.createElement("div");
  tempDiv.style.width = tableWidth + "px";
  tempDiv.style.background = "#fff";
  document.body.appendChild(tempDiv);

  let isFirstPage = true;

  const isWeeklySheet = title.toLowerCase().includes("week");
  const isLifting = document.getElementById("listDropdown")?.value?.toUpperCase() === "LIFTING";

  function createTable(includeHeader = false, includeFooter = false) {
    const t = document.createElement("table");
    t.className = "main-table";
    const colgroup = document.createElement("colgroup");
    colWidths.forEach((w) => {
      const col = document.createElement("col");
      col.style.width = w + "px";
      colgroup.appendChild(col);
    });
    t.appendChild(colgroup);
    if (includeHeader) t.innerHTML += headerHTML;
    t.innerHTML += "<tbody></tbody>";
    if (includeFooter) t.innerHTML += footerHTML;
    return t;
  }

  const rowGroups = [];
  if (isWeeklySheet) {
    const groupSize = isLifting ? 4 : 5;
    for (let i = 0; i < rows.length; i += groupSize) {
      rowGroups.push(rows.slice(i, i + groupSize));
    }
  } else {
    rows.forEach((r) => rowGroups.push([r]));
  }

  let tableContainer = createTable(true, false);
  tempDiv.appendChild(tableContainer);
  let tbody = tableContainer.querySelector("tbody");

  for (let g = 0; g < rowGroups.length; g++) {
    const group = rowGroups[g];
    group.forEach((r) => tbody.appendChild(r.cloneNode(true)));

    if (tempDiv.scrollHeight > usableHeight) {
      group.forEach(() => tbody.removeChild(tbody.lastChild));

      if (isFirstPage && overviewHeader)
        tempDiv.insertAdjacentHTML("afterbegin", overviewHeader);

      // 🔧 Temporarily tighten cell padding before capture
      const allCells = tempDiv.querySelectorAll("td, th");
      allCells.forEach(cell => {
        cell.dataset.originalPadding = cell.style.padding || "";
        cell.style.padding = "4px 6px";   // ✅ reduce space inside cells
        cell.style.lineHeight = "1.6";
      });

      await captureAndPaginate(pdf, tempDiv, pageWidth, pageHeight, title);

      // 🔁 Restore original padding
      allCells.forEach(cell => {
        cell.style.padding = cell.dataset.originalPadding;
        delete cell.dataset.originalPadding;
      });

      isFirstPage = false;
      tempDiv.innerHTML = "";
      tableContainer = createTable(false, false);
      tempDiv.appendChild(tableContainer);
      tbody = tableContainer.querySelector("tbody");

      group.forEach((r) => tbody.appendChild(r.cloneNode(true)));
    }
  }

  if (tbody.children.length > 0) {
    const remaining = Array.from(tbody.children).map((tr) => tr.cloneNode(true));
    tempDiv.innerHTML = "";
    const includeHeaderOnFinal = isFirstPage;
    const finalTable = createTable(includeHeaderOnFinal, true);
    tempDiv.appendChild(finalTable);
    const finalBody = finalTable.querySelector("tbody");
    remaining.forEach((r) => finalBody.appendChild(r));

    if (isFirstPage && overviewHeader)
      tempDiv.insertAdjacentHTML("afterbegin", overviewHeader);

    // 🔧 Tighten padding for final page too
    const allCells = tempDiv.querySelectorAll("td, th");
    allCells.forEach(cell => {
      cell.dataset.originalPadding = cell.style.padding || "";
      cell.style.padding = "4px 6px";
      cell.style.lineHeight = "1.6";
    });

    await captureAndPaginate(pdf, tempDiv, pageWidth, pageHeight, title);

    allCells.forEach(cell => {
      cell.style.padding = cell.dataset.originalPadding;
      delete cell.dataset.originalPadding;
    });
  }

  document.body.removeChild(tempDiv);
}



//REPORT VIEW JS


let summaryMap = {};
// 🔹 Update the MONTH input with YYYY.MM
const monthInput = document.querySelector('input[name="monthnum"]');
if (monthInput) {
    const monthNum = String(firstDate.getMonth() + 1).padStart(2, '0'); // 01–12
    monthInput.value = `${firstDate.getFullYear()}.${monthNum}`;
}
document.addEventListener('DOMContentLoaded', function () {
  const preparedOnInput = document.querySelector('input[name="prepared_on"]');
  if (preparedOnInput) {
    const today = new Date();
    const formattedDate = today.toLocaleDateString('en-GB'); // dd/mm/yyyy
    preparedOnInput.value = formattedDate;
  }
});


function updateMonthInputFromProject(projectRows) {
  if (!projectRows || projectRows.length === 0) return;

  const monthInput = document.querySelector('input[name="monthnum"]');
  if (monthInput) {
    const firstDate = new Date(projectRows[0].date1);
    const year = firstDate.getFullYear();
    const month = String(firstDate.getMonth() + 1).padStart(2, '0');
    monthInput.value = `${year}.${month}`;
  }
}

// SELECT MONTH 

let tracker_project_data = [];
let globalPrevMonthRows = [];
let selectedMonth = "", selectedYear = "";
function updateFrontSheetTotalsFromOverview() {
  const overviewTable = document.querySelector('#project_overview_tab .main-table');
  if (!overviewTable) return;

  let totalApproved = 0;
  let totalSpentToDate = 0;

  // Loop through all data rows (skip header)
  overviewTable.querySelectorAll('tbody tr').forEach(tr => {
    const cells = tr.querySelectorAll('td');
    if (cells.length >= 6) {
      const approved = parseFloat(cells[2]?.innerText || 0); // Column C
      const spent = parseFloat(cells[5]?.innerText || 0);    // Column F
      if (!isNaN(approved)) totalApproved += approved;
      if (!isNaN(spent)) totalSpentToDate += spent;
    }
  });

  // ✅ Update visible TOTAL row inside Project Overview
  const approvedCell = document.getElementById('totalApprovedCell');
  const spentCell = document.getElementById('totalSpentCell');
  if (approvedCell) approvedCell.innerText = totalApproved.toFixed(2);
  if (spentCell) spentCell.innerText = totalSpentToDate.toFixed(2);

  // ✅ Update the Front Sheet inputs
  const approvedInput = document.querySelector('input[name="total_hours_approved"]');
  const spentInput = document.querySelector('input[name="total_hours_spent"]');
  if (approvedInput) approvedInput.value = totalApproved.toFixed(2);
  if (spentInput) spentInput.value = totalSpentToDate.toFixed(2);

  console.log('✅ Front Sheet + Overview Totals Updated:', {
    totalApproved,
    totalSpentToDate
  });
}

document.addEventListener('DOMContentLoaded', function() {
    const monthDropdown = document.getElementById('monthDropdown');
    const listDropdown = document.getElementById('listDropdown');
    const projectDropdown = document.getElementById('projectDropdown');
    const sheetTabs = document.querySelector('.sheet-tabs');
    const monthlyOverview = document.getElementById('monthlyOverview');

    // Utility to fetch and initialize
    fetch('/report-view/', { headers: { 'X-Requested-With': 'XMLHttpRequest' } })
        .then(response => response.json())
        .then(data => {
            tracker_project_data = data.tracker_project_data || [];
            buildMonthDropdown();
            filterAndDispatch(); // Initialize UI with default (previous month)
        });

    function buildMonthDropdown() {
        // Build month dropdown
        const allMonths = [...new Set(tracker_project_data.map(row => {
            if (!row.date1) return null;
            const d = new Date(row.date1);
            return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, '0');
        }).filter(Boolean))];

        // Always show "Select Month" as default
        monthDropdown.innerHTML = '<option value="">Select Month</option>';

        // Sort months in descending order
        allMonths.sort((a, b) => b.localeCompare(a));

        // Add each month to dropdown
        allMonths.forEach(val => {
            const [year, month] = val.split('-');
            const dateObj = new Date(year, month - 1, 1);
            const display = dateObj.toLocaleString('default', { month: 'long', year: 'numeric' });
            const opt = document.createElement('option');
            opt.value = val;
            opt.textContent = display;
            monthDropdown.appendChild(opt);
        });

        // ❌ Removed auto-selection of the latest month
        // User must now manually select a month
    }


    // When month changes, reset and filter everything
    monthDropdown.addEventListener('change', function () {
        if (this.value) {
            const [year, month] = this.value.split('-');
            selectedYear = parseInt(year, 10);
            selectedMonth = parseInt(month, 10);
        } else {
            const today = new Date();
            selectedYear = today.getMonth() === 0 ? today.getFullYear() - 1 : today.getFullYear();
            selectedMonth = today.getMonth() === 0 ? 12 : today.getMonth();
        }
        listDropdown.innerHTML = '<option value="">Select List</option>';
        projectDropdown.innerHTML = '<option value="">Select Project</option>';
        projectDropdown.disabled = true;
        filterAndDispatch();   // ✅ always re-filter when month changes
        // 🔹 Recalculate if project/list already selected
        const selectedProject = this.value;
    const selectedList = document.getElementById("listDropdown")?.value || "";

    updateMonthlyOverview(selectedProject, selectedList, globalPrevMonthRows); // 🔹 force update here
    });


    // Filtering function for selected month
    function filterAndDispatch() {
        let rows = [];

        if (selectedMonth && selectedYear) {
            // ✅ Explicit month selected → show only that month
            rows = tracker_project_data.filter(row => {
                if (!row.date1) return false;
                const d = new Date(row.date1);
                return d.getFullYear() === selectedYear && (d.getMonth() + 1) === selectedMonth;
            });
        } else {
            // ✅ No selection → include both current + previous month
            const today = new Date();
            const currentMonth = today.getMonth() + 1;
            const currentYear = today.getFullYear();

            let prevMonth = today.getMonth();
            let prevYear = today.getFullYear();
            if (prevMonth === 0) {
                prevMonth = 12;
                prevYear -= 1;
            }

            rows = tracker_project_data.filter(row => {
                if (!row.date1) return false;
                const d = new Date(row.date1);
                const m = d.getMonth() + 1;
                const y = d.getFullYear();
                return (y === currentYear && m === currentMonth) ||
                    (y === prevYear && m === prevMonth);
            });
        }

        // 🔹 Always update global rows
        globalPrevMonthRows = rows;

        // 🔹 Dispatch event
        const event = new CustomEvent('trackerProjectDataReady', { detail: { prevMonthRows: rows } });
        document.dispatchEvent(event);
    }




// ---------------- DISPATCH AFTER DATA FILTERED ----------------
function dispatchDataReady(rows) {
    // Populate LIST dropdown with unique values for this month
    const uniqueLists = [...new Set(rows.map(row => row.list).filter(Boolean))];
    listDropdown.innerHTML = '<option value="">Select List</option>';
    uniqueLists.forEach(list => {
        const opt = document.createElement('option');
        opt.value = list;
        opt.textContent = list;
        listDropdown.appendChild(opt);
    });

    // Reset downstream
    projectDropdown.innerHTML = '<option value="">Select Project</option>';
    projectDropdown.disabled = true;

    // Reset UI
    Array.from(sheetTabs.querySelectorAll('li')).forEach((li, idx) => { if (idx > 0) li.remove(); });
    Array.from(document.querySelectorAll('.tab-content')).forEach(el => el.remove());
    monthlyOverview.style.display = 'none';
}

// ---------------- LIST CHANGE ----------------
listDropdown.addEventListener('change', function () {
    const selectedList = this.value;

    const filteredProjects = globalPrevMonthRows
        .filter(row => row.list === selectedList)
        .map(row => row.projects)
        .filter(Boolean);

    const uniqueProjects = [...new Set(filteredProjects)];

    projectDropdown.innerHTML = '<option value="">Select Project</option>';
    uniqueProjects.forEach(project => {
        const opt = document.createElement('option');
        opt.value = project;
        opt.textContent = project;
        projectDropdown.appendChild(opt);
    });

    projectDropdown.disabled = false;

    // Clear downstream data until project selected
    Array.from(sheetTabs.querySelectorAll('li')).forEach((li, idx) => { if (idx > 0) li.remove(); });
    Array.from(document.querySelectorAll('.tab-content')).forEach(el => el.remove());
    monthlyOverview.style.display = 'none';
});

// ---------------- PROJECT CHANGE ----------------
projectDropdown.addEventListener('change', function () {
    const selectedProject = this.value;
    const selectedList = listDropdown.value;

    if (!selectedProject || !selectedList) return;

    // Reset tabs/content
    Array.from(sheetTabs.querySelectorAll('li')).forEach((li, idx) => { if (idx > 0) li.remove(); });
    Array.from(document.querySelectorAll('.tab-content')).forEach(el => el.remove());

    // Show monthly overview
    monthlyOverview.style.display = 'block';

    // Build weekly sheet/tabs for this project+list
    const projectRows = globalPrevMonthRows.filter(row =>
        row.list === selectedList &&
        (row.projects === selectedProject || row.project === selectedProject)
    );
    // 🔹 Attach listeners for weekly editable cells
    attachWeeklySheetListeners();

    // 🔹 Update Monthly Overview totals, project part, designation from weekly DOM
    refreshFromWeekly();
});

// ---------------- INIT ON LOAD ----------------
filterAndDispatch();

});

// 🔹 Global effectiveness (default 100%)
let userEffectiveness = 100;

/**
 * Calculate effectiveness-adjusted time
 */
function roundUpToHalfHour(value) {
    const num = parseFloat(value) || 0;
    const effectiveTime = num * (userEffectiveness / 100);

    // Round normally to nearest 0.5
    return Math.round(effectiveTime * 2) / 2;

    // OR, if you want exact (no rounding):
    // return effectiveTime;
}


// Fetch effectiveness first, THEN dispatch data-ready
function initReport() {
    fetch('/api/get_user_effectiveness/')
        .then(res => res.json())
        .then(data => {
            if (data.effectiveness) {
                userEffectiveness = parseFloat(data.effectiveness) || 100;
            }
        })
        .catch(() => {
            console.warn("⚠️ Failed to fetch effectiveness, using default 100%");
        })
        .finally(() => {
            // ✅ Only now build tables & trigger events
            fetch('/report-view/', {
                headers: { 'X-Requested-With': 'XMLHttpRequest' }
            })
            .then(res => res.json())
            .then(data => {
                const tracker_project_data = data.tracker_project_data || [];
                const event = new CustomEvent('trackerProjectDataReady', {
                    detail: { prevMonthRows: tracker_project_data }
                });
                document.dispatchEvent(event);
            });
        });
}

document.addEventListener('DOMContentLoaded', initReport);

function formatHours(val) {
  return roundUpToHalfHour(val).toFixed(1);
}
async function updateMonthlyOverview(selectedProject, selectedList, rows) {
    if (!selectedProject || !selectedList) return;

    const projectRows = rows.filter(row =>
        (row.project === selectedProject || row.projects === selectedProject) &&
        row.list === selectedList
    );

    // Local calculation (fallback)
    const totalHoursApproved = calculateUniqueApprovedHours(filteredRows);

    function calculateCumulativeTotal(selectedProject, selectedYear, selectedMonth, monthlyCalendarRows, trackerRows) {
    let total = 0;
    const cutoff = selectedYear * 100 + selectedMonth;

    // Group MonthlyCalendar
    const monthlyMap = {};
    monthlyCalendarRows
        .filter(r => r.project === selectedProject)
        .forEach(r => {
            const d = new Date(r.date);
            const ym = d.getFullYear() * 100 + (d.getMonth() + 1);
            if (ym <= cutoff) {
                monthlyMap[ym] = (monthlyMap[ym] || 0) + (Number(r.time) || 0);
            }
        });

    // Group TrackerTasks
    const trackerMap = {};
    trackerRows
        .filter(r => (r.projects === selectedProject || r.project === selectedProject) && r.date1)
        .forEach(r => {
            const d = new Date(r.date1);
            const ym = d.getFullYear() * 100 + (d.getMonth() + 1);
            if (ym <= cutoff) {
                trackerMap[ym] = (trackerMap[ym] || 0) + (Number(r.time) || 0);
            }
        });

    // Collect all months up to cutoff
    const allMonths = [...new Set([...Object.keys(trackerMap), ...Object.keys(monthlyMap)])]
        .map(Number)
        .filter(ym => ym <= cutoff)
        .sort((a, b) => a - b);

    allMonths.forEach(ym => {
        if (monthlyMap[ym] && trackerMap[ym]) {
            // ✅ If month exists in BOTH → take only MonthlyCalendar
            total += monthlyMap[ym];
        } else if (monthlyMap[ym]) {
            // ✅ If only in MonthlyCalendar → take raw
            total += monthlyMap[ym];
        } else if (trackerMap[ym]) {
            // ✅ If only in TrackerTasks → round
            total += Math.round(trackerMap[ym] * 2) / 2;
        }
    });

    return total;
}

    const totalHoursSpent = calculateCumulativeTotal(
        selectedProject,
        selectedYear,
        selectedMonth,
        monthlyCalendarRows,   // you need to pass your MonthlyCalendar dataset here
        tracker_project_data
    );


    // Update inputs immediately (so something shows)
    const approvedInput = document.querySelector('input[name="total_hours_approved"]');
    const spentInput = document.querySelector('input[name="total_hours_spent"]');
    const monthlyInput = document.getElementById('monthlyTotalHoursInput');
    if (approvedInput) approvedInput.value = totalHoursApproved.toFixed(2);
    if (spentInput) spentInput.value = roundUpToHalfHour(totalHoursSpent).toFixed(2);
    if (monthlyInput) monthlyInput.value = (totalHoursSpent).toFixed(2);

    if (projectRows.length > 0) {
        let year = selectedYear;
        let month = selectedMonth;
        if (!year || !month) {
            const firstDate = new Date(projectRows[0].date1);
            year = firstDate.getFullYear();
            month = firstDate.getMonth() + 1;
        }


        // 🔹 Fetch backend hours for that project/month
        // 🔹 Always calculate from weekly-sheet
        const totalFromWeekly = getTotalHoursFromWeekly();
        if (monthlyInput) monthlyInput.value = totalFromWeekly.toFixed(2);
        const monthlyCell = document.getElementById('monthlyTotalHoursCell');
        if (monthlyCell) monthlyCell.textContent = totalFromWeekly.toFixed(2);


        // Update header
        const firstDate = new Date(projectRows[0].date1);
        const monthLabel = firstDate.toLocaleString('en-US', { month: 'long' }).toUpperCase();
        const yearShort = String(year).slice(2);
        const weekNumbers = projectRows.map(r => getISOWeek(new Date(r.date1)));
        const weekMin = Math.min(...weekNumbers);
        const weekMax = Math.max(...weekNumbers);

        const projectHoursHeader = document.getElementById('projectHoursHeader');
        if (projectHoursHeader) {
            projectHoursHeader.textContent =
                `TOTAL PROJECT HOURS - (${monthLabel}-${yearShort}) - (WEEK ${weekMin} TO WEEK ${weekMax})`;
        }

        // Update hidden month input
        const monthInput = document.querySelector('input[name="monthnum"]');
        if (monthInput) {
            monthInput.value = `${year}.${String(month).padStart(2, '0')}`;
        }
    }
}


document.addEventListener('DOMContentLoaded', function () {
    const sheetTabs = document.querySelector('.sheet-tabs');
    const projectDropdown = document.getElementById('projectDropdown');
    const listDropdown = document.getElementById('listDropdown');   // ▶️ CHANGES: Added List dropdown
    const monthlyOverview = document.getElementById('monthlyOverview');
    // Remove all week tabs and week content initially
    Array.from(sheetTabs.querySelectorAll('li')).forEach((li, idx) => { if (idx > 0) li.remove(); });
    Array.from(document.querySelectorAll('.tab-content')).forEach(el => el.remove());
    monthlyOverview.style.display = 'none';

    // Helper to create week tab and content
    function createWeekTab(weekLabel, weekId, weekContentHtml) {
        const li = document.createElement('li');
        li.setAttribute('data-tab', weekId);
        li.textContent = weekLabel;
        sheetTabs.appendChild(li);

        const div = document.createElement('div');
        div.className = 'tab-content';
        div.id = weekId;
        div.innerHTML = weekContentHtml;
        document.querySelector('.tabs-container').appendChild(div);
    }
console.log("Sample row:", tracker_project_data[0]);
    function buildProjectOverview(selectedProject, selectedList) {
    if (!selectedProject || !selectedList) return;

    // Filter the global data
    const rows = (window.tracker_project_data || []).filter(row =>
        (row.projects === selectedProject || row.project === selectedProject) &&
        row.list === selectedList
    );

    if (rows.length === 0) return;

    // Example: recalc total hours
    const totalApproved = rows.reduce((sum, r) => sum + (Number(r.task_benchmark) || 0), 0);
    const totalSpent = rows.reduce((sum, r) => sum + (Number(r.time) || 0), 0);

    console.log(`Project Overview for ${selectedProject}/${selectedList}:`, {
        approved: totalApproved,
        spent: totalSpent
    });

    // TODO: update DOM (tables, charts, headers, etc.)
    const projectHoursHeader = document.getElementById('projectHoursHeader');
    if (projectHoursHeader) {
        projectHoursHeader.textContent =
            `PROJECT OVERVIEW — ${selectedProject} (${selectedList})`;
    }
}

    // Listen for AJAX data ready event
    document.addEventListener('trackerProjectDataReady', function(e) {
        const prevMonthRows = e.detail.prevMonthRows;
        window._trackerProjectData = prevMonthRows; // For PDF download logic

        // ▶️ CHANGES: Populate LIST dropdown with unique values
        const uniqueLists = [...new Set(prevMonthRows.map(row => row.list).filter(Boolean))];
        listDropdown.innerHTML = '<option value="" disabled selected>Select List</option>';
        uniqueLists.forEach(list => {
            const opt = document.createElement('option');
            opt.value = list;
            opt.textContent = list;
            listDropdown.appendChild(opt);
        });

        // ▶️ CHANGES: When LIST changes, populate PROJECT dropdown for that list
        projectDropdown.disabled = true;
        $('#listDropdown').on('change', function() {
            const selectedList = this.value;
            const filteredProjects = prevMonthRows
                .filter(row => row.list === selectedList)
                .map(row => row.projects)
                .filter(Boolean);
            const uniqueProjects = [...new Set(filteredProjects)];
            projectDropdown.innerHTML = '<option value="" disabled selected>Select Project</option>';
            uniqueProjects.forEach(project => {
                const opt = document.createElement('option');
                opt.value = project;
                opt.textContent = project;
                projectDropdown.appendChild(opt);
            });
            projectDropdown.disabled = false;

            // Clear tabs and overview when list is changed
            Array.from(sheetTabs.querySelectorAll('li')).forEach((li, idx) => { if (idx > 0) li.remove(); });
            Array.from(document.querySelectorAll('.tab-content')).forEach(el => el.remove());
            monthlyOverview.style.display = 'none';
        });
        updateMonthlyOverviewVisibility(listDropdown.value);

        // On PROJECT select, show week tabs for that project and list, keep monthlyOverview visible
        $('#projectDropdown').on('change', function() {
            // Reset UI
            Array.from(sheetTabs.querySelectorAll('li')).forEach((li, idx) => { if (idx > 0) li.remove(); });
            Array.from(document.querySelectorAll('.tab-content')).forEach(el => el.remove());
            monthlyOverview.style.display = 'block';
            Array.from(document.querySelectorAll('.tab-content')).forEach(el => el.style.display = 'none');
            Array.from(sheetTabs.querySelectorAll('li')).forEach(t => t.classList.remove('active'));

            if (!window.Chart) {
                const script = document.createElement('script');
                script.src = 'https://cdn.jsdelivr.net/npm/chart.js';
                document.head.appendChild(script);
            }

            // Always filter by BOTH selectedList and selectedProject
            const selectedList = listDropdown.value;
            const selectedProject = this.value;
            const projectRows = prevMonthRows.filter(row =>
                row.list === selectedList &&
                (row.projects === selectedProject || row.project === selectedProject)
            );

            if (projectRows.length > 0) {
                const firstDate = new Date(projectRows[0].date1);
                const monthInput = document.querySelector('input[name="monthnum"]');
                if (monthInput) {
                    const monthNum = String(firstDate.getMonth() + 1).padStart(2, '0');
                    monthInput.value = `${firstDate.getFullYear()}.${monthNum}`;
                }
            }

            // ✅ Group strictly by ISO week
            const weekMap = {};
            projectRows.forEach(row => {
                if (row.date1) {
                    const d = new Date(row.date1);
                    const isoWeekNum = getISOWeek(d);
                    const isoYear = d.getFullYear();

                    row.isoWeek = isoWeekNum;
                    row.isoYear = isoYear;

                    const key = `${isoYear}-W${isoWeekNum}`;
                    if (!weekMap[key]) weekMap[key] = [];
                    weekMap[key].push(row);
                }
            });

            updateMonthlyOverviewVisibility(listDropdown.value);
            buildProjectOverview(selectedProject, selectedList);

            // Render tabs in chronological order
            const weekKeys = Object.keys(weekMap).sort();
            weekKeys.forEach(key => {
                const weekRows = weekMap[key];
                const { isoWeek, isoYear } = weekRows[0];

                // Get start & end date in this week
                const sortedDates = weekRows.map(r => new Date(r.date1)).sort((a, b) => a - b);
                const startDateStr = sortedDates[0].toLocaleDateString('en-GB');
                const endDateStr = sortedDates[sortedDates.length - 1].toLocaleDateString('en-GB');

                const weekLabel = `WEEK ${isoWeek}`;
                const weekId = `sheet_week_${isoYear}_${isoWeek}`;
                const chartCanvasId = `chart_${weekId}`;

                const weekContentHtml = `
        <link rel="stylesheet" href="/static/css/report.css">
        <div class="weekly-overview">
        <div class="overview-header">
            <div class="header-left">
            <table class="project-table">
                <tr>
                <td colspan="2"><strong>WEEKLY OVERVIEW — (WEEK ${isoWeek})</strong></td>
                </tr>
                <tr><td><strong>PROJECT</strong></td><td><input type="text" value="${selectedProject}" readonly /></td></tr>
                <tr><td><strong>WEEK START DATE</strong></td><td><input type="text" value="${startDateStr}" readonly /></td></tr>
                <tr><td><strong>WEEK END DATE</strong></td><td><input type="text" value="${endDateStr}" readonly /></td></tr>
            </table>
            </div>
            <div class="header-right">
            <img src="/static/images/logo.png" alt="Logo" class="header-logo" crossOrigin="anonymous" />
            </div>
        </div>

        <table id="weekly-sheet" class="main-table weekly-sheet">
            <thead>
            <tr>
                <th>DWG NO</th>
                <th>SCOPE</th>
                <th>STATUS</th>
                <th>START DATE</th>
                <th>END DATE</th>
                <th>REVISION</th>
                <th>HOURS</th>
            </tr>
            </thead>
            <tbody>
${
(listDropdown.value && listDropdown.value.trim().toUpperCase() === "LIFTING")
    ? (() => {
        const selectedProject = document.getElementById("projectDropdown")?.value || "";
        const selectedList    = document.getElementById("listDropdown")?.value || "";
        const groupedRows = {};

        // ✅ Filter rows for this project/list only
        const rowsForThisWeek = (weekMap[key] || []).filter(r =>
            (r.projects === selectedProject || r.project === selectedProject) &&
            (!selectedList || r.list === selectedList)
        );


        rowsForThisWeek.forEach(row => {
            // Build grouping key
            const key = [
                row.scope,
                row.category,
                row.d_no,
                row.rev || row.rev_no,
                row.ref_no || "",
                row.mail_no || "",
                row.assigned || row.designation || "",
                row.isoWeek,   // ✅ use isoWeek
                row.projects || "",
                row.list || ""
            ].join("||");

            if (!groupedRows[key]) {
                groupedRows[key] = {
                    ...row,
                    times: [Number(row.time) || 0],
                    commentsArr: [(row.comments || "").trim()].filter(Boolean),
                    startDate: row.date1 ? new Date(row.date1) : null,
                    endDate: row.date1 ? new Date(row.date1) : null,
                    // Mark if this group already has an edited entry
                    edited: !!row.monthly_id
                };
            } else {
                // If the new row is edited, override the group's time and mark as edited.
                if (row.monthly_id) {
                    groupedRows[key].times = [Number(row.time) || 0];
                    groupedRows[key].edited = true;
                } else {
                    // Only add the time if the group has not been marked as edited.
                    if (!groupedRows[key].edited) {
                        groupedRows[key].times.push(Number(row.time) || 0);
                    }
                }
                // Always update comments array (if not a duplicate)
                const c = (row.comments || "").trim();
                if (c && !groupedRows[key].commentsArr.includes(c)) {
                    groupedRows[key].commentsArr.push(c);
                }
                // Update start and end dates as needed.
                const d = row.date1 ? new Date(row.date1) : null;
                if (d) {
                    if (!groupedRows[key].startDate || d < groupedRows[key].startDate) {
                        groupedRows[key].startDate = d;
                    }
                    if (!groupedRows[key].endDate || d > groupedRows[key].endDate) {
                        groupedRows[key].endDate = d;
                    }
                }
            }
        });

        return Object.values(groupedRows).map(row => {
          const totalTime = row.times.reduce((a, b) => a + b, 0);

          // ✅ Skip rows where edited and hours == 0
          if (row.monthly_id && totalTime === 0) return '';

          // If the current comments field already appears to be numbered, use it as is
          const alreadyNumbered = row.comments && row.comments.trim().match(/^1\)/);


            const allComments = alreadyNumbered 
                ? row.comments 
                : (row.commentsArr.length > 1
                    ? row.commentsArr.map((comment, index) => `${index + 1}) ${comment}`).join('<br>')
                    : (row.commentsArr[0] || "").replace(/\n/g, '<br>')
                );
            return `
                <tr data-id="${row.tracker_id}" data-monthly-id="${row.monthly_id || ''}" data-date="${row.date1 || ''}" data-list="${row.list || ''}">
                    <td>${row.d_no || ''}</td>
                    <td contenteditable="true">${row.title || ''}</td>
                    <td contenteditable="true" class="status-completed">${row.status || 'COMPLETED'}</td>
                    <td contenteditable="true">${row.startDate ? row.startDate.toLocaleDateString('en-GB') : ''}</td>
                    <td contenteditable="true">${row.endDate ? row.endDate.toLocaleDateString('en-GB') : ''}</td>
                    <td contenteditable="true">${row.rev || ''}</td>
                    <td contenteditable="true">${
                        row.monthly_id
                            ? (totalTime.toFixed(1))                // already saved → show raw
                            : (roundUpToHalfHour(totalTime).toFixed(1))  // fresh load → apply reduction
                    }</td>

                </tr>
                <tr>
                    <td class="lifting-row-label">MAIL NUMBER:</td>
                    <td contenteditable="true" colspan="6" style="color:#EC008C">${row.mail_no || ""}</td>
                </tr>
                <tr>
                    <td class="lifting-row-label">REFERENCE NUMBER:</td>
                    <td contenteditable="true" colspan="6" style="color:#EC008C">${row.ref_no || ""}</td>
                </tr>
                <tr>
                    <td class="lifting-row-label">DESCRIPTION OF WORK:</td>
                    <td contenteditable="true" colspan="6">${allComments}</td>
                </tr>
            `;
        }).join('');
    })()
    : (() => {
        const selectedProject = document.getElementById("projectDropdown")?.value || "";
        const selectedList    = document.getElementById("listDropdown")?.value || "";
        const groupedRows = {};

        const rowsForThisWeek = (weekMap[key] || []).filter(r =>
            (r.projects === selectedProject || r.project === selectedProject) &&
            (!selectedList || r.list === selectedList)
        );


        rowsForThisWeek.forEach(row => {
           function norm(s) { return (s ?? '').toString().trim().toUpperCase(); }

                    const key = [
                    norm(row.projects || row.project),
                    norm(row.list),
                    norm(row.scope),
                    norm(row.category),
                    norm(row.d_no),
                    norm(row.rev || row.rev_no),
                    row.isoWeek,
                    ].join("||");


            if (!groupedRows[key]) {
                groupedRows[key] = {
                    ...row,
                    times: [],
                    commentsArr: [(row.comments || "").trim()].filter(Boolean),
                    startDate: row.date1 ? new Date(row.date1) : null,
                    endDate: row.date1 ? new Date(row.date1) : null,
                    edited: !!row.monthly_id
                };

                if (row.monthly_id) {
                    groupedRows[key].times = [Number(row.time) || 0];
                } else {
                    groupedRows[key].times.push(Number(row.time) || 0);
                }
            } else {
                if (row.monthly_id) {
                    groupedRows[key].times = [Number(row.time) || 0];
                    groupedRows[key].edited = true;
                } else if (!groupedRows[key].edited) {
                    groupedRows[key].times.push(Number(row.time) || 0);
                }

                // comments merge
                const c = (row.comments || "").trim();
                if (c && !groupedRows[key].commentsArr.includes(c)) {
                    groupedRows[key].commentsArr.push(c);
                }
            }

        });

        return Object.values(groupedRows).map(row => {
            const totalTime = row.times.reduce((a, b) => a + b, 0);

            // ✅ Skip rows where edited and hours == 0
            if (row.monthly_id && totalTime === 0) return '';

            // If the current comments field already appears to be numbered, use it as is
            const alreadyNumbered = row.comments && row.comments.trim().match(/^1\)/);

            const allComments = alreadyNumbered 
                ? row.comments 
                : (row.commentsArr.length > 1
                    ? row.commentsArr.map((comment, index) => `${index + 1}) ${comment}`).join('<br>')
                    : (row.commentsArr[0] || "").replace(/\n/g, '<br>')
                );

            return `
                <tr data-id="${row.tracker_id}" data-monthly-id="${row.monthly_id || ''}" data-date="${row.date1 || ''}" data-list="${row.list || ''}">
                    <td class="row-label">PROJECT PART:</td>
                    <td contenteditable="true">${row.scope || ''}</td>
                    <td contenteditable="true" class="status-completed">${row.status || 'COMPLETED'}</td>
                    <td contenteditable="true">${row.startDate ? row.startDate.toLocaleDateString('en-GB') : ''}</td>
                    <td contenteditable="true">${row.endDate ? row.endDate.toLocaleDateString('en-GB') : ''}</td>
                    <td contenteditable="true">${row.rev || ''}</td>
                    <td contenteditable="true">${
                        row.monthly_id
                            ? (totalTime.toFixed(1))                // already saved → show raw
                            : (roundUpToHalfHour(totalTime).toFixed(1))  // fresh load → apply reduction
                    }</td>


                </tr>
                <tr>
                    <td>${row.d_no || ''}</td>
                    <td contenteditable="true" colspan="6">${row.title || ''}</td>
                </tr>
                <tr>
                    <td class="row-label">PHASE:</td>
                    <td contenteditable="true" colspan="6">${row.category || ''}</td>
                </tr>
                <tr>
                    <td class="row-label">DONE BY:</td>
                    <td contenteditable="true" colspan="6">
                        ${row.designation || getUserRole(row.assigned, userroles) || ''}
                    </td>
                </tr>
                <tr>
                    <td class="row-label">DESCRIPTION OF WORK:</td>
                    <td contenteditable="true" colspan="6" class="multiline-cell">${allComments}</td>
                </tr>
            `;
        }).join('');
    })()
}


  </tbody>
</table>

  ${weekId === 'project-overview' ? `
  <canvas id="chart_${weekId}"></canvas>
` : ''}

</div>
`;
function getUserRole(assigned, userrolesArray) {
    if (!assigned || !userrolesArray || !userrolesArray.length) return '';
    assigned = assigned.trim().toLowerCase();
    const user = userrolesArray.find(u => u.name && u.name.trim().toLowerCase() === assigned);
    return user ? user.role : '';
}


                createWeekTab(weekLabel, weekId, weekContentHtml);

                // Draw chart after tab is created
                setTimeout(() => {
                    if (!window.Chart) return;
                    const canvas = document.getElementById(chartCanvasId);
                    if (!canvas) return;
                    const ctx = canvas.getContext('2d');
                    new Chart(ctx, {
                        type: 'bar',
                        data: {
                            labels: weekRows.map(r => r.scope || r.d_no || ''),
                            datasets: [{
                                label: 'Hours',
                                data: weekRows.map(r => Number(r.time) || 0),
                                backgroundColor: 'rgba(54, 162, 235, 0.5)',
                                borderColor: 'rgba(54, 162, 235, 1)',
                                borderWidth: 1
                            }]
                        },
                        options: {
                            responsive: false,
                            plugins: { legend: { display: false } },
                            scales: { y: { beginAtZero: true } }
                        }
                    });
                }, 300);
            });
updateFrontSheetTotalsFromOverview();

            // --- Add PROJECT OVERVIEW tab/button at the end ---
// --- Add PROJECT OVERVIEW tab/button at the end ---
const overviewTabId = 'project_overview_tab';

// Remove duplicate tab if exists
const existingOverviewTab = sheetTabs.querySelector(`li[data-tab="${overviewTabId}"]`);
if (existingOverviewTab) existingOverviewTab.remove();
const existingOverviewContent = document.getElementById(overviewTabId);
if (existingOverviewContent) existingOverviewContent.remove();

// --- Build summary table for all projects/tasks (ALL TIME) ---
const isLifting = selectedList === "LIFTING";
const summaryMap = {};
const selectedProjectRows = tracker_project_data.filter(
  row => row.projects === selectedProject && row.list === selectedList
);

// Parse selected month and year for comparisons
const currentMonth = Number(selectedMonth);
const currentYear = Number(selectedYear);

// Build base summary entries
selectedProjectRows.forEach(row => {
  const projectPart = row.scope || '';
  const task = row.title || '';
  const approvedHours = Number(row.task_benchmark || row.approved_hours_per_po || 0);
  const key = projectPart + '||' + task;

  if (!summaryMap[key]) {
    summaryMap[key] = {
      projectPart,
      task,
      approvedHours,
      hoursSpentThisMonth: 0,
      hoursPrior: 0,
      totalHoursToDate: 0,
      totalHoursRemaining: 0,
      percentBudget: 0,
    };
    if (!isLifting) summaryMap[key].extraHoursWorked = 0;
  }
});

// --- Calculate HOURS SPENT THIS MONTH directly from weekly sheet ---
Object.values(summaryMap).forEach(item => {
  let totalForThisTask = 0;

  if (isLifting) {
    document.querySelectorAll('#weekly-sheet tbody tr[data-id]').forEach(tr => {
      const taskName = (tr.cells[1]?.innerText || '').trim().toUpperCase();
      const taskHours = parseFloat((tr.cells[6]?.innerText || '').trim()) || 0;
      if (taskName === (item.task || '').trim().toUpperCase()) {
        totalForThisTask += taskHours;
      }
    });
  } else {
    document.querySelectorAll('#weekly-sheet tbody tr[data-id]').forEach(tr => {
      const projectPart = (tr.cells[1]?.innerText || '').trim().toUpperCase();
      const nextRow = tr.nextElementSibling;
      const taskName = (nextRow?.cells?.[1]?.innerText || '').trim().toUpperCase();
      const taskHours = parseFloat((tr.cells[6]?.innerText || '').trim()) || 0;

      if (
        projectPart === (item.projectPart || '').trim().toUpperCase() &&
        taskName === (item.task || '').trim().toUpperCase()
      ) {
        totalForThisTask += taskHours;
      }
    });
  }

  item.hoursSpentThisMonth = totalForThisTask || 0;
});

// --- Calculate HOURS PRIOR TO THIS MONTH (Tracker + Monthlycalendar condition) ---
Object.values(summaryMap).forEach(item => {
  let totalPrior = 0;

  tracker_project_data
    .filter(r => r.projects === selectedProject && r.list === selectedList)
    .forEach(r => {
      const date = new Date(r.date1);
      const year = date.getFullYear();
      const month = date.getMonth() + 1;

      const sameTask =
        (r.title || '').trim().toUpperCase() === (item.task || '').trim().toUpperCase();
      const sameScope =
        (r.scope || '').trim().toUpperCase() === (item.projectPart || '').trim().toUpperCase();

      const isEarlier =
        year < currentYear || (year === currentYear && month < currentMonth);

      if (sameTask && (!isLifting ? sameScope : true) && isEarlier) {
        const monthExistsInMonthly = tracker_project_data.some(
          x =>
            x.source === "monthly" &&
            x.projects === selectedProject &&
            x.list === selectedList &&
            x.date1 &&
            new Date(x.date1).getFullYear() === year &&
            new Date(x.date1).getMonth() + 1 === month
        );

        // ✅ Apply correct rounding logic
        if (r.source !== "monthly" && !monthExistsInMonthly) {
          // Tracker data → round to nearest 0.5 using helper
          totalPrior += roundUpToHalfHour(r.time);
        } else if (r.source === "monthly") {
          // Monthly data → already rounded, add directly
          totalPrior += Number(r.time) || 0;
        }
      }
    });

  item.hoursPrior = totalPrior;
});

// --- Calculate totals ---
const totalHoursApproved = calculateUniqueApprovedHours(
  tracker_project_data.filter(
    row => row.projects === selectedProject && row.list === selectedList
  )
);

let totalHoursSpent = 0;
document.querySelectorAll('#weekly-sheet tbody tr[data-id]').forEach(tr => {
  const val = parseFloat((tr.cells[6]?.innerText || '').trim());
  if (!isNaN(val) && val > 0) totalHoursSpent += val;
});

// Update inputs
const approvedInput = document.querySelector('input[name="total_hours_approved"]');
const spentInput = document.querySelector('input[name="total_hours_spent"]');
if (approvedInput) approvedInput.value = totalHoursApproved.toFixed(2);
if (spentInput) spentInput.value = (Number(totalHoursSpent) || 0).toFixed(2);

// --- Final calculations ---
Object.values(summaryMap).forEach(item => {
  item.totalHoursToDate = item.hoursSpentThisMonth + item.hoursPrior;
  item.totalHoursRemaining = Math.max(0, item.approvedHours - item.totalHoursToDate);
  if (!isLifting) {
    item.extraHoursWorked = Math.max(0, item.totalHoursToDate - item.approvedHours);
  }
  item.percentBudget =
    item.approvedHours > 0
      ? ((item.totalHoursToDate / item.approvedHours) * 100).toFixed(2) + '%'
      : '';
});

// --- Build Table + Chart UI ---
const summaryTableHeaders = isLifting
  ? [
      "PACKAGE",
      "TASK",
      "APPROVED HOURS PER PO",
      "HOURS SPENT THIS MONTH",
      "HOURS PRIOR TO THIS MONTH",
      "TOTAL HOURS SPENT TO DATE",
      "TOTAL HOURS REMAINING",
      "% BUDGET PROGRESS",
    ]
  : [
      "PROJECT PART",
      "TASK",
      "APPROVED HOURS PER PO",
      "HOURS SPENT THIS MONTH",
      "HOURS PRIOR TO THIS MONTH",
      "TOTAL HOURS SPENT TO DATE",
      "TOTAL HOURS REMAINING",
      "EXTRA HOURS WORKED",
      "% BUDGET PROGRESS",
    ];

const summaryTableHtml = `
  <table class="main-table" id="project_overview_table">
    <thead>
      <tr>${summaryTableHeaders.map(h => `<th>${h}</th>`).join('')}</tr>
    </thead>
    <tbody>
      ${Object.values(summaryMap)
        .map(item => `
        <tr>
          <td>${item.projectPart}</td>
          <td>${item.task}</td>
          <td>${item.approvedHours}</td>
          <td>${item.hoursSpentThisMonth}</td>
          <td>${item.hoursPrior}</td>
          <td>${item.totalHoursToDate}</td>
          <td>${item.totalHoursRemaining}</td>
          ${isLifting ? '' : `<td>${item.extraHoursWorked}</td>`}
          <td>${item.percentBudget}</td>
        </tr>`).join('')}
    </tbody>
    <tfoot>
    <tr class="totals-row" style="font-weight:bold;background: #ffffff;">
        <td colspan="2" style="text-align:center;">TOTALS:</td>
        <td id="totalApprovedCell">0</td>
        <td></td>
        <td></td>
        <td id="totalSpentCell">0</td>
        <td colspan="${isLifting ? 2 : 3}"></td>
    </tr>
    </tfoot>
  </table>
`;


// ✅ Restore summaryLabels, approvedData, spentData, summaryChartId
const summaryLabels = Object.values(summaryMap).map(item =>`${item.task}`);
const approvedData = Object.values(summaryMap).map(i => i.approvedHours);
const spentData = Object.values(summaryMap).map(i => i.totalHoursToDate);
const summaryChartId = 'project_overview_chart';

// --- Final overview tab HTML ---
const overviewContentHtml = `
  <div class="project-overview-section">
    <table class="overview-header1">
      <tr>
        <td class="header-left1"><span class="overview-title">PROJECT OVERVIEW</span></td>
        <td class="header-right2"><img src="/static/images/logo.png" crossOrigin="anonymous" alt="Logo" class="header-logo1" /></td>
      </tr>
    </table>
    ${summaryTableHtml}
    <div class="canvas-container"></div>
  </div>
`;



createWeekTab('PROJECT OVERVIEW', overviewTabId, overviewContentHtml);
// 🔹 Call totals updater here
setTimeout(updateFrontSheetTotalsFromOverview, 300);
// --- Draw grouped bar chart after tab creation ---
setTimeout(() => {
  if (!window.Chart) return;
  const container = document.querySelector('.canvas-container');
  if (!container) return;
  container.innerHTML = '';

  // Utility: chunk arrays into groups of 10
  function chunkArray(arr, size) {
    const result = [];
    for (let i = 0; i < arr.length; i += size) result.push(arr.slice(i, i + size));
    return result;
  }

  const labelChunks = chunkArray(summaryLabels, 10);
  const approvedChunks = chunkArray(approvedData, 10);
  const spentChunks = chunkArray(spentData, 10);

  // 🎨 Custom plugin: Striped background inside chart area
  const stripedBackground = {
    id: 'stripedBackground',
    beforeDraw: (chart) => {
      const { ctx, chartArea } = chart;
      if (!chartArea) return; // skip until layout is ready

      const { left, top, width, height } = chartArea;

      // Create diagonal stripe pattern
      const patternCanvas = document.createElement('canvas');
      const pctx = patternCanvas.getContext('2d');
      const stripeSize = 12; // adjust thickness
      patternCanvas.width = stripeSize;
      patternCanvas.height = stripeSize;

      pctx.fillStyle = '#f7f7f7'; // light base
      pctx.fillRect(0, 0, stripeSize, stripeSize);

      pctx.strokeStyle = '#e5e5e5'; // stripe color
      pctx.lineWidth = 2;
      pctx.beginPath();
      pctx.moveTo(0, stripeSize);
      pctx.lineTo(stripeSize, 0);
      pctx.stroke();

      const pattern = ctx.createPattern(patternCanvas, 'repeat');

      ctx.save();
      ctx.fillStyle = pattern;
      ctx.fillRect(left, top, width, height);
      ctx.restore();
    }
  };

  // Draw charts for each label chunk
  labelChunks.forEach((labelsChunk, idx) => {
    while (labelsChunk.length < 10) {
      labelsChunk.push('');
      approvedChunks[idx].push(null);
      spentChunks[idx].push(null);
    }

    // ✅ Create canvas
    const canvas = document.createElement('canvas');
    canvas.id = `${summaryChartId}_${idx}`;
    canvas.className = 'overview-chart';
    container.appendChild(canvas);

    // ✅ Draw chart
    new Chart(canvas.getContext('2d'), {
      type: 'bar',
      data: {
        labels: labelsChunk,
        datasets: [
          {
            label: 'APPROVED HOURS PER PO',
            data: approvedChunks[idx],
            backgroundColor: '#F04693',
            borderRadius: 4,
            barThickness: 25
          },
          {
            label: 'TOTAL HOURS SPENT TO DATE',
            data: spentChunks[idx],
            backgroundColor: '#00B0F0',
            borderRadius: 4,
            barThickness: 25
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        layout: { padding: 20 },
        plugins: {
          legend: {
            display: true,
            position: 'top',
            labels: {
              color: 'black',
              font: { size: 13, weight: 'bold' }
            }
          },
          title: {
            display: idx === 0,
            text: 'BUDGET OVERVIEW',
            font: { size: 18, weight: 'bold' },
            color: 'black',
            padding: { top: 10, bottom: 20 }
          },
          tooltip: { enabled: true },
          datalabels: {
            anchor: 'end',
            align: 'end',
            color: 'black',
            font: { weight: 'bold' },
            formatter: value => (value !== null ? value : '')
          }
        },
        scales: {
          x: {
            title: { display: true, text: 'Tasks', color: 'black', font: { weight: 'bold' } },
            ticks: {
              maxRotation: 0,
              minRotation: 0,
              autoSkip: false,
              color: 'black',
              font: { size: 12, family: 'Roboto' },
              callback: function (value) {
                const label = this.getLabelForValue(value);
                if (!label) return '';

                const words = label.split(' ');
                const lines = [];
                let line = '';

                words.forEach(word => {
                  if (word.length > 15) {
                    const subWords = word.match(/.{1,15}/g) || [word];
                    subWords.forEach(sub => {
                      if (line.length + sub.length > 18) {
                        lines.push(line.trim());
                        line = sub + ' ';
                      } else {
                        line += sub + ' ';
                      }
                    });
                  } else if ((line + word).length > 18) {
                    lines.push(line.trim());
                    line = word + ' ';
                  } else {
                    line += word + ' ';
                  }
                });

                lines.push(line.trim());
                return lines; // Chart.js auto-stacks
              }
            },
            grid: { display: false }
          },
          y: {
            title: { display: true, text: 'Hours', color: 'black', font: { weight: 'bold' } },
            ticks: { color: 'black', font: { size: 12 } },
            grid: { color: '#ddd' },
            beginAtZero: true
          }
        }
      },
      plugins: [ChartDataLabels, stripedBackground] // ✅ include striped background plugin
    });
  });
}, 300);

// --- Add click handlers for all tabs (including overview) ---
Array.from(sheetTabs.querySelectorAll('li')).forEach((li, idx) => {
  if (idx === 0) return;
  li.addEventListener('click', function() {
    monthlyOverview.style.display = 'none';
    Array.from(sheetTabs.querySelectorAll('li')).forEach(t => t.classList.remove('active'));
    li.classList.add('active');
    Array.from(document.querySelectorAll('.tab-content')).forEach(content => {
      if (content.id === li.getAttribute('data-tab')) {
        content.classList.add('active');
        content.style.display = 'block';
      } else {
        content.classList.remove('active');
        content.style.display = 'none';
      }
    });
  });
});

        });
    });

    // Helper: ISO week number
    function getISOWeek(date) {
        const target = new Date(date.valueOf());
        const dayNr = (date.getDay() + 6) % 7;
        target.setDate(target.getDate() - dayNr + 3);
        const firstThursday = target.valueOf();
        target.setMonth(0, 1);
        if (target.getDay() !== 4) {
            target.setMonth(0, 1 + ((4 - target.getDay()) + 7) % 7);
        }
        return 1 + Math.ceil((firstThursday - target) / 604800000);
    }

    // Only show monthlyOverview at first
    monthlyOverview.style.display = 'block';
});
let userroles = [];

function fetchUserRoles() {
    // Call the Django endpoint (adjust URL if you use a different one)
    fetch('/userinfo-list/')
        .then(response => response.json())
        .then(data => {
            userroles = data.userroles || [];
        })
        .catch(error => {
            console.error("Failed to fetch user roles:", error);
            userroles = [];
        });
}

function updateProjectHoursHeader() {
    const projectHoursHeader = document.getElementById('projectHoursHeader');
    if (!projectHoursHeader) return;

    const dates = [];
    document.querySelectorAll('#weekly-sheet tbody tr[data-id]').forEach(tr => {
        // if you have a date attribute
        const dateStr = tr.getAttribute('data-date') || tr.querySelector('td[data-date]')?.innerText;
        if (dateStr) {
            const d = new Date(dateStr);
            if (!isNaN(d)) dates.push(d);
        }
    });

    if (dates.length === 0) return;

    const minDate = new Date(Math.min(...dates));
    const maxDate = new Date(Math.max(...dates));

    const monthLabel = minDate.toLocaleString('en-US', { month: 'long' }).toUpperCase();
    const yearShort = String(minDate.getFullYear()).slice(2);

    function getISOWeek(date) {
        const target = new Date(date.valueOf());
        const dayNr = (date.getDay() + 6) % 7;
        target.setDate(target.getDate() - dayNr + 3);
        const firstThursday = target.valueOf();
        target.setMonth(0, 1);
        if (target.getDay() !== 4) {
            target.setMonth(0, 1 + ((4 - target.getDay()) + 7) % 7);
        }
        return 1 + Math.ceil((firstThursday - target) / 604800000);
    }

    const weekMin = getISOWeek(minDate);
    const weekMax = getISOWeek(maxDate);

    projectHoursHeader.textContent =
        `TOTAL PROJECT HOURS - (${monthLabel}-${yearShort}) - (WEEK ${weekMin} TO WEEK ${weekMax})`;
}


function buildScopeTableFromWeekly() {
    const tableBody = document.querySelector('.project-part-table tbody');
    if (!tableBody) return;

    const scopeHours = {};
    document.querySelectorAll('#weekly-sheet tbody tr[data-id]').forEach(tr => {
        const scope = (tr.getAttribute('data-scope') || '').trim() ||
                      (tr.querySelector('td:nth-child(2)')?.innerText || "Unknown").trim();
        const hours = parseFloat(tr.querySelector('td:nth-child(7)')?.innerText) || 0;
        scopeHours[scope] = (scopeHours[scope] || 0) + hours;
    });

    tableBody.innerHTML = '';
    Object.entries(scopeHours).forEach(([scope, hours]) => {
        const tr = document.createElement('tr');
        tr.innerHTML = `<td>${scope}</td><td><input type="number" value="${hours.toFixed(2)}"></td>`;
        tableBody.appendChild(tr);
    });
}

function buildDesignationTableFromWeekly() {
    const designationTableBody = document.querySelector('.designation-table tbody');
    if (!designationTableBody) return;

    const roleHours = {};
    document.querySelectorAll('#weekly-sheet tbody tr[data-id]').forEach(tr => {
        const doneByRow = tr.nextElementSibling?.cells?.[0]?.innerText?.trim().toUpperCase() === "DONE BY"
            ? tr.nextElementSibling
            : null;

        if (doneByRow) {
            const designation = (doneByRow.cells[1]?.innerText || "UNKNOWN").trim();
            const hours = parseFloat(tr.querySelector('td:nth-child(7)')?.innerText) || 0;
            roleHours[designation] = (roleHours[designation] || 0) + hours;
        }
    });

    designationTableBody.innerHTML = '';
    Object.entries(roleHours).forEach(([role, hours]) => {
        const tr = document.createElement('tr');
        tr.innerHTML = `<td>${role}</td><td><input type="number" value="${hours.toFixed(2)}"></td>`;
        designationTableBody.appendChild(tr);
    });
}


// Call this early, e.g. on page load
document.addEventListener('DOMContentLoaded', fetchUserRoles);

// Fetch tracker_project_data via AJAX from /report-view/ endpoint
document.addEventListener('DOMContentLoaded', function() {
    fetch('/report-view/', {
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
    .then(response => response.json())
    .then(data => {
        const tracker_project_data = data.tracker_project_data || [];
        console.log('All tracker_project_data:', tracker_project_data);

        // Get today's date
        const today = new Date();
        const currentYear = today.getFullYear();
        const currentMonth = today.getMonth() + 1; // Months are 0-based, so add 1
        const currentDate = today.getDate();
        console.log('Current Year:', currentYear);
        console.log('Current Month:', currentMonth);
        console.log('Current Date:', currentDate);

        // Get previous month and year
        let prevMonth = today.getMonth(); // 0-based, so this is current month
        let prevYear = today.getFullYear();
        if (prevMonth === 0) {
            prevMonth = 12;
            prevYear -= 1;
        }

        // Filter rows where date1 is in previous month
        // Use selectedMonth/Year if available, otherwise fallback
        const rows = tracker_project_data.filter(row => {
            if (!row.date1) return false;
            const d = new Date(row.date1);
            if (selectedYear && selectedMonth) {
                return d.getFullYear() === selectedYear && (d.getMonth() + 1) === selectedMonth;
            } else {
                // fallback: previous month
                let prevMonth = today.getMonth();
                let prevYear = today.getFullYear();
                if (prevMonth === 0) {
                    prevMonth = 12;
                    prevYear -= 1;
                }
                return d.getFullYear() === prevYear && (d.getMonth() + 1) === prevMonth;
            }
        });

        console.log('Rows from previous month:', rows);

        // Dispatch a custom event so the template can populate the dropdown
        const event = new CustomEvent('trackerProjectDataReady', { detail: { prevMonthRows: rows } });
        document.dispatchEvent(event);

    })
    .catch(err => {
        console.error('Error fetching tracker_project_data:', err);
    });
});


//FRONT SHEET FOR MONTHLY OVERVIEW
// ✅ Helper to calculate unique approved hours
function calculateUniqueApprovedHours(rows) {
    const seen = new Set();
    let total = 0;

    rows.forEach(row => {
        const key = [
            row.scope || "",
            row.category || "",
            row.rev_no || row.rev || "",
            row.d_no || "",
            row.mail_no || "",
            row.ref_no || ""
        ].join("||");

        if (!seen.has(key)) {
            seen.add(key);
            total += Number(row.task_benchmark) || 0;
        }
    });

    return total;
}

function getActiveYearMonth() {
    if (selectedYear && selectedMonth) return [selectedYear, selectedMonth];
    const today = new Date();
    let y = today.getFullYear();
    let m = today.getMonth();
    if (m === 0) { m = 12; y -= 1; }
    return [y, m];
}

// ----------------- Helpers -----------------
function getTotalHoursFromWeekly() {
    let total = 0;
    document.querySelectorAll('#weekly-sheet tbody tr').forEach(tr => {
        const cell = tr.querySelector('td:nth-child(7)');
        if (!cell) return;

        let val = 0;
        if (cell.querySelector('input')) {
            val = parseFloat(cell.querySelector('input').value);
        } else {
            val = parseFloat((cell.innerText || '').trim());
        }

        if (!isNaN(val)) total += val;
    });
    return total;
}

// ----------------- Auto-refresh from weekly sheet -----------------
function refreshFromWeekly() {
    const rows = document.querySelectorAll('#weekly-sheet tbody tr');
    if (!rows.length) return;

    // --- Monthly total hours (front page) ---
    let totalMonthlyHours = 0;
    rows.forEach(tr => {
        const cell = tr.querySelector('td:nth-child(7)');
        if (cell) {
            const val = parseFloat((cell.innerText || "").trim()) || 0;
            totalMonthlyHours += val;
        }
    });

    const monthlyInput = document.getElementById('monthlyTotalHoursInput');
    const monthlyCell = document.getElementById('monthlyTotalHoursCell');
    if (monthlyInput) monthlyInput.value = totalMonthlyHours.toFixed(2);
    if (monthlyCell) monthlyCell.textContent = totalMonthlyHours.toFixed(2);

    // --- Project Part Table (Scope) ---
    const scopeTableBody = document.querySelector('.project-part-table tbody');
    if (scopeTableBody) {
        const scopeHours = {};
        rows.forEach((tr, idx) => {
            if (idx % 5 === 0) { // 1,6,11,... rows (0-based index)
                const scope = (tr.querySelector('td:nth-child(2)')?.innerText || "UNKNOWN").trim();
                const val = parseFloat((tr.querySelector('td:nth-child(7)')?.innerText || "").trim()) || 0;
                scopeHours[scope] = (scopeHours[scope] || 0) + val;
            }
        });

        scopeTableBody.innerHTML = '';
        Object.entries(scopeHours).forEach(([scope, hours]) => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${scope}</td>
                <td><input type="number" value="${hours.toFixed(2)}" readonly></td>
            `;
            scopeTableBody.appendChild(tr);
        });
    }

    // --- Designation Table (Role) ---
const designationTableBody = document.querySelector('.designation-table tbody');
if (designationTableBody) {
    const designationHours = {};
    rows.forEach((tr, idx) => {
        if ((idx - 3) % 5 === 0 && idx >= 3) { // 4,9,14,19... rows
            const designation = (tr.querySelector('td:nth-child(2)')?.innerText || "UNKNOWN").trim();

            // take hours from the corresponding block's first row (idx-3)
            const taskRow = rows[idx - 3];
            let hours = 0;
            if (taskRow) {
                const val = parseFloat((taskRow.querySelector('td:nth-child(7)')?.innerText || "").trim()) || 0;
                hours = val;
            }

            designationHours[designation] = (designationHours[designation] || 0) + hours;
        }
    });

    designationTableBody.innerHTML = '';
    Object.entries(designationHours).forEach(([designation, hours]) => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${designation}</td>
            <td><input type="number" value="${hours.toFixed(2)}" readonly></td>
        `;
        designationTableBody.appendChild(tr);
    });
}
// update project header if needed
updateProjectHoursHeader();
setTimeout(updateFrontSheetTotalsFromOverview, 300);
}

// ----------------- Main Code -----------------
document.addEventListener('DOMContentLoaded', function () {
    const projectDropdown = document.getElementById('projectDropdown');
    if (!projectDropdown) return;

    $('#projectDropdown').on('change', function () {
        const selectedProject = this.value;
        const selectedList = document.getElementById("listDropdown")?.value || "";

        // Update hidden inputs
        const inputProject = document.querySelector('input[name="project"]');
        const inputProjectName = document.querySelector('input[name="project_name"]');
        if (inputProject) inputProject.value = selectedProject;
        if (inputProjectName) inputProjectName.value = selectedProject;

        // build weekly tabs & table here (your existing logic)

        // 🔹 after weekly rows are inserted
        attachWeeklySheetListeners();
        setTimeout(refreshFromWeekly, 50); // small delay ensures DOM rows exist
    });

    // Init dropdowns
    $('#listDropdown').select2({
        placeholder: "Select List",
        allowClear: true,
        width: 'resolve'
    });
    $('#projectDropdown').select2({
        placeholder: "Select Project",
        allowClear: true,
        width: 'resolve'
    });

    // Auto-select first project if exists
    if ($('#projectDropdown option').length > 1) {
        $('#projectDropdown').val($('#projectDropdown option').eq(1).val()).trigger('change');
    }
});

// ----------------- Visibility toggle -----------------
function updateMonthlyOverviewVisibility(selectedList) {
    const projectPartSection = document.querySelector('.project-part-table');
    const designationSection = document.querySelector('.designation-table');
    const totalHoursApprovedRows = document.querySelectorAll('.totals-table');

    if (selectedList && selectedList.trim().toUpperCase() === "LIFTING") {
        if (projectPartSection) projectPartSection.style.display = "none";
        if (designationSection) designationSection.style.display = "none";
        totalHoursApprovedRows.forEach(row => row.style.display = "none");
    } else {
        if (projectPartSection) projectPartSection.style.display = "";
        if (designationSection) designationSection.style.display = "";
        totalHoursApprovedRows.forEach(row => row.style.display = "");
    }
}

// ----------------- Weekly cell listeners -----------------
function attachWeeklySheetListeners() {
    document.querySelectorAll('#weekly-sheet tbody tr td:nth-child(7)').forEach(cell => {
        cell.setAttribute('contenteditable', 'true');
        cell.addEventListener('input', refreshFromWeekly);
    });
}

// ---------- Add once near top ----------
async function refreshAllViewsAfterSave() {
  const listDropdown = document.getElementById('listDropdown');
  const projectDropdown = document.getElementById('projectDropdown');

  const selectedList = listDropdown?.value || '';
  const selectedProject = projectDropdown?.value || '';

  // Clear old tabs/content
  document.querySelectorAll('.tab-content').forEach(el => el.remove());
  document.querySelectorAll('.sheet-tabs li:not(:first-child)').forEach(el => el.remove());

  // Trigger rebuild flows
  if (selectedList) {
    listDropdown.dispatchEvent(new Event('change'));
    await new Promise(r => setTimeout(r, 150));
  }
  if (selectedProject) {
    projectDropdown.dispatchEvent(new Event('change'));
    await new Promise(r => setTimeout(r, 150));
  }

  if (typeof buildProjectOverview === 'function') buildProjectOverview(selectedProject, selectedList);
  if (typeof updateFrontSheetTotalsFromOverview === 'function') updateFrontSheetTotalsFromOverview();
  if (typeof refreshFromWeekly === 'function') refreshFromWeekly();
  if (typeof updateMonthlyOverview === 'function') updateMonthlyOverview(selectedProject, selectedList, window.globalPrevMonthRows || []);
  if (typeof updateMonthlyOverviewVisibility === 'function') updateMonthlyOverviewVisibility(selectedList);
}

function getTotalFromWeeklyDom() {
  let total = 0;
  document.querySelectorAll('#weekly-sheet tbody tr[data-id]').forEach(tr => {
    const v = parseFloat((tr.cells?.[6]?.innerText || '').trim());
    if (!isNaN(v)) total += v;
  });
  return total;
}
// ---------- End add once ----------

document.addEventListener('DOMContentLoaded', function () {
  const saveBtn = document.getElementById('reportsave');
  if (!saveBtn) {
    console.error("Save button not found in DOM");
    return;
  }

  function findRowByLabel(headerTr, labelText, maxHops = 8) {
    let r = headerTr.nextElementSibling;
    const target = (labelText || '').trim().toUpperCase();
    let hops = 0;
    while (r && hops < maxHops) {
      if (r.hasAttribute('data-id')) break;
      const c0 = (r.cells?.[0]?.innerText || '').trim().toUpperCase().replace(/\s*:\s*$/, '');
      if (c0 === target) return r;
      r = r.nextElementSibling;
      hops++;
    }
    return null;
  }

  function getWeekNumber(date) {
    if (!(date instanceof Date)) date = new Date(date);
    const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
    const dayNum = d.getUTCDay() || 7;
    d.setUTCDate(d.getUTCDate() + 4 - dayNum);
    const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
    return Math.ceil((((d - yearStart) / 86400000) + 1) / 7);
  }

  saveBtn.addEventListener('click', function () {
    const baseRows = document.querySelectorAll('#weekly-sheet tbody tr[data-id]');
    const updates = [];

    baseRows.forEach(tr => {
      const trackerId = tr.getAttribute('data-id');
      const monthlyId = tr.getAttribute('data-monthly-id') || null;
      const listType  = (tr.getAttribute('data-list') || '').trim().toUpperCase();
      const cells     = tr.querySelectorAll('td');

      const status     = (cells[2]?.innerText || '').trim();
      const start_date = (cells[3]?.innerText || '').trim();
      const end_date   = (cells[4]?.innerText || '').trim();
      const rev_no     = (cells[5]?.innerText || '').trim();
      const time       = parseFloat((cells[6]?.innerText || '').trim()) || 0;

      const updateObj = { tracker_id: trackerId, monthly_id: monthlyId, status, start_date, end_date, rev_no, time };

      if (listType === 'LIFTING') {
        updateObj.d_no  = (cells[0]?.innerText || '').trim();
        updateObj.title = (cells[1]?.innerText || '').trim();
        const mailRow = findRowByLabel(tr, 'MAIL NUMBER');
        const refRow  = findRowByLabel(tr, 'REFERENCE NUMBER');
        const descRow = findRowByLabel(tr, 'DESCRIPTION OF WORK');
        updateObj.mail_no  = (mailRow?.cells?.[1]?.innerText || '').trim();
        updateObj.ref_no   = (refRow?.cells?.[1]?.innerText || '').trim();
        updateObj.comments = (descRow?.cells?.[1]?.innerText || '').trim();
      } else {
        const dwgRow = tr.nextElementSibling || null;
        updateObj.d_no  = (dwgRow?.cells?.[0]?.innerText || '').trim();
        updateObj.scope = (cells[1]?.innerText || '').trim();
        const phaseRow = findRowByLabel(tr, 'PHASE');
        const doneRow  = findRowByLabel(tr, 'DONE BY');
        const descRow  = findRowByLabel(tr, 'DESCRIPTION OF WORK');
        updateObj.category    = (phaseRow?.cells?.[1]?.innerText || '').trim();
        updateObj.designation = (doneRow?.cells?.[1]?.innerText || '').trim();
        updateObj.comments    = (descRow?.cells?.[1]?.innerText || '').trim();
      }

      updates.push(updateObj);
    });

    if (!updates.length) {
      alert("No data to save or update");
      return;
    }

    // loader
    const loader = document.createElement('div');
    loader.id = 'savingLoader';
    loader.textContent = 'Saving report... please wait';
    Object.assign(loader.style, {
      position: 'fixed', top: '50%', left: '50%', transform: 'translate(-50%, -50%)',
      background: 'rgba(0,0,0,0.7)', color: '#fff', padding: '15px 25px',
      borderRadius: '8px', zIndex: '9999'
    });
    document.body.appendChild(loader);

    fetch('/save-weekly-report/', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-CSRFToken': getCookie('csrftoken') },
      body: JSON.stringify({ updates })
    })
    .then(res => res.json())
    .then(data => {
      document.getElementById('savingLoader')?.remove();

      if (!data.success) {
        alert('Save failed: ' + (data.error || 'Unknown error'));
        return;
      }

      // visual feedback
      const toast = document.createElement('div');
      toast.textContent = '✅ Report saved! Updating…';
      Object.assign(toast.style, {
        position: 'fixed', bottom: '20px', right: '20px', background: '#4CAF50',
        color: '#fff', padding: '10px 20px', borderRadius: '8px', zIndex: '9999', fontWeight: 'bold'
      });
      document.body.appendChild(toast);
      setTimeout(() => toast.remove(), 2000);

      // optimistic UI: update just-saved rows on screen
      if (Array.isArray(data.updated)) {
        data.updated.forEach(rowData => {
          document.querySelectorAll(`#weekly-sheet tbody tr[data-id="${rowData.tracker_id}"]`).forEach(tr => {
            tr.setAttribute('data-monthly-id', rowData.monthly_id || '');
            const cells = tr.querySelectorAll('td');
            cells[1].innerText = (tr.getAttribute('data-list') || '').toUpperCase() === 'LIFTING'
              ? (rowData.title || cells[1].innerText)
              : (rowData.scope || cells[1].innerText);
            cells[2].innerText = rowData.status || '';
            cells[3].innerText = rowData.start_date || '';
            cells[4].innerText = rowData.end_date || '';
            cells[5].innerText = rowData.rev_no || '';
            cells[6].innerText = (rowData.time ?? '').toString();
          });
        });

        // Update totals on screen immediately (optimistic)
        const totalHoursSpent = getTotalFromWeeklyDom();
        const approvedInput = document.querySelector('input[name="total_hours_approved"]');
        const spentInput = document.querySelector('input[name="total_hours_spent"]');
        const monthlyInput = document.getElementById('monthlyTotalHoursInput');
        const monthlyCell = document.getElementById('monthlyTotalHoursCell');
        // approved will be recalculated after re-fetch (from overview), keep for now
        if (spentInput)  spentInput.value  = totalHoursSpent.toFixed(2);
        if (monthlyInput) monthlyInput.value = totalHoursSpent.toFixed(2);
        if (monthlyCell) monthlyCell.textContent = totalHoursSpent.toFixed(2);
      }

      // now fetch fresh data and rebuild everything
      return fetch(`/report-view/?t=${Date.now()}`, {
        headers: { 'X-Requested-With': 'XMLHttpRequest' },
        cache: 'no-store'
      })
      .then(res => res.json())
      .then(newData => {
        window.tracker_project_data = Array.isArray(newData.tracker_project_data)
          ? [...newData.tracker_project_data]
          : Object.values(newData.tracker_project_data || {});
        return refreshAllViewsAfterSave();
      })
      .catch(err => {
        console.error("Auto-refresh failed:", err);
        alert("Saved, but refresh failed — please reload manually.");
      });
    })
    .catch(err => {
      document.getElementById('savingLoader')?.remove();
      console.error(err);
      alert('Error saving report');
    });
  });
});

async function refreshAllViewsAfterSave() {
  const listDropdown = document.getElementById('listDropdown');
  const projectDropdown = document.getElementById('projectDropdown');

  const selectedList = listDropdown?.value || '';
  const selectedProject = projectDropdown?.value || '';

  // Clear old tabs/content
  document.querySelectorAll('.tab-content').forEach(el => el.remove());
  document.querySelectorAll('.sheet-tabs li:not(:first-child)').forEach(el => el.remove());

  // Re-dispatch change events to rebuild weekly + monthly views
  if (selectedList) {
    listDropdown.value = selectedList;
    listDropdown.dispatchEvent(new Event('change'));
    await new Promise(r => setTimeout(r, 250));
  }
  if (selectedProject) {
    projectDropdown.value = selectedProject;
    projectDropdown.dispatchEvent(new Event('change'));
    await new Promise(r => setTimeout(r, 250));
  }

  // Update the rest (guard in case functions don’t exist yet)
  if (typeof buildProjectOverview === 'function')
    buildProjectOverview(selectedProject, selectedList);
  if (typeof updateFrontSheetTotalsFromOverview === 'function')
    updateFrontSheetTotalsFromOverview();
  if (typeof refreshFromWeekly === 'function')
    refreshFromWeekly();
  if (typeof updateMonthlyOverview === 'function')
    updateMonthlyOverview(selectedProject, selectedList, window.globalPrevMonthRows || []);
  if (typeof updateMonthlyOverviewVisibility === 'function')
    updateMonthlyOverviewVisibility(selectedList);
}


// unchanged helper
function getCookie(name) {
  let cookieValue = null;
  if (document.cookie && document.cookie !== '') {
    const cookies = document.cookie.split(';');
    for (let cookie of cookies) {
      cookie = cookie.trim();
      if (cookie.startsWith(name + '=')) {
        cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
        break;
      }
    }
  }
  return cookieValue;
}