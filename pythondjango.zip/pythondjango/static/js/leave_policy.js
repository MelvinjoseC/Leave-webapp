// Disable context menu and block shortcuts that bypass the read-only policy view.
document.addEventListener("contextmenu", (event) => event.preventDefault());

document.addEventListener("keydown", (event) => {
    const keyLower = event.key.toLowerCase();

    if (event.ctrlKey && keyLower === "p") {
        event.preventDefault();
        alert("Printing is disabled for this document.");
        return;
    }

    if (event.ctrlKey && keyLower === "s") {
        event.preventDefault();
        alert("Saving is disabled for this document.");
        return;
    }

    if (keyLower === "s" && event.shiftKey && event.metaKey) {
        event.preventDefault();
        alert("Screenshots are disabled for this document.");
        return;
    }

    if (event.metaKey && (keyLower === "p" || keyLower === "s")) {
        event.preventDefault();
        return;
    }

    if (event.key === "F12" || (event.ctrlKey && event.shiftKey && keyLower === "i")) {
        event.preventDefault();
        alert("Developer tools are disabled.");
    }
});
