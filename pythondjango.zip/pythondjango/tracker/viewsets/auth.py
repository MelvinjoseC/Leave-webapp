import json

from django.http import JsonResponse
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt

from ..models import EmployeeDetails, UserinfoView
from .common import require_session_user_json


def _parse_json_body(request):
    try:
        body = request.body.decode("utf-8") if request.body else "{}"
        return json.loads(body)
    except (UnicodeDecodeError, json.JSONDecodeError):
        raise ValueError("Invalid request format.")


def _build_session_payload(user):
    authentication = getattr(user, "authentication", "") or ""
    designation = getattr(user, "designation", "") or ""
    return {
        "employee_id": user.employee_id,
        "name": user.name,
        "designation": designation,
        "authentication": authentication,
        "role": authentication.lower(),
    }


def login(request):
    if request.method == "POST":
        try:
            data = _parse_json_body(request)
        except ValueError as exc:
            return JsonResponse({"success": False, "message": str(exc)})

        username = data.get("username")
        password = data.get("password")
        user = (
            EmployeeDetails.objects.only("employee_id", "name", "designation", "authentication")
            .filter(name=username, password=password)
            .first()
        )

        if user:
            user_data = _build_session_payload(user)

            # Save user details in the session for per-user access
            request.session["user_id"] = user.employee_id
            request.session["user_data"] = user_data
            return JsonResponse({"success": True, "redirect_url": "/task_dashboard/"})
        else:
            return JsonResponse(
                {"success": False, "message": "Invalid username or password."}
            )

    return render(request, "signin.html")


@csrf_exempt
def reset_password(request):
    if request.method != 'POST':
        return JsonResponse({'success': False, 'error': 'Invalid request'})

    username = request.POST.get('username')
    email = request.POST.get('email')
    new_password = request.POST.get('new_password')

    try:
        employee = EmployeeDetails.objects.get(name=username, email=email)
        employee.password = new_password  # ⚠️ Plain text (not secure)
        employee.save()
        return JsonResponse({'success': True})
    except EmployeeDetails.DoesNotExist:
        return JsonResponse({'success': False, 'error': 'Invalid username or email'})


def sign_up(request):
    if request.method == "POST":
        try:
            data = _parse_json_body(request)
        except ValueError as exc:
            return JsonResponse({"success": False, "message": str(exc)})

        username = data.get("username")
        password = data.get("password")

        if not username or not password:
            return JsonResponse(
                {
                    "success": False,
                    "message": "Both username and password are required.",
                }
            )

        designation = (
            EmployeeDetails.objects.filter(name=username, password=password)
            .values_list("authentication", flat=True)
            .first()
        )

        if designation:
            if designation.lower() == "admin":
                return render(
                    request, "employee_form.html"
                )  # Render the HTML form for admin users
            else:
                return JsonResponse(
                    {
                        "success": False,
                        "message": "Only admin users are allowed to sign up.",
                    }
                )
        return JsonResponse(
            {"success": False, "message": "Invalid username or password."}
        )

    return JsonResponse({"success": False, "message": "Invalid request method."})


def save_employee_details(request):
    if request.method != "POST":
        return JsonResponse({"success": False, "message": "Invalid request method."})

    name = request.POST.get("name")
    designation = request.POST.get("designation")
    date_joined = request.POST.get("date_joined")
    email = request.POST.get("email")
    phone_number = request.POST.get("phone_number")
    department = request.POST.get("department")

    status = request.POST.get("status", "Active")
    password = request.POST.get("password")
    image = request.FILES.get("image")

    employee = EmployeeDetails(
        name=name,
        designation=designation,
        date_joined=date_joined,
        email=email,
        phone_number=phone_number,
        department=department,
        status=status,
        password=password,
        image=image.read() if image else None,
    )
    employee.save()

    return JsonResponse({"success": True, "name": employee.name})


def userinfo_list(request):
    userroles = UserinfoView.objects.all().values('name', 'role')
    return JsonResponse({"userroles": list(userroles)})


@require_session_user_json
def check_admin_status(request):

    username = request.session_user_data.get("name")
    auth_result = (
        EmployeeDetails.objects.filter(name=username)
        .values_list("authentication", flat=True)
        .first()
    )
    auth_value = str(auth_result or "").strip().lower()

    return JsonResponse({
        "is_admin": auth_value == "admin",
        "is_md": auth_value == "md",
    })

__all__ = [
    "login",
    "reset_password",
    "sign_up",
    "save_employee_details",
    "userinfo_list",
    "check_admin_status",
]
