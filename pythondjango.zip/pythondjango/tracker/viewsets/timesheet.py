import json
from datetime import datetime, timedelta

from django.db import connection
from django.db.models import Case, FloatField, Sum, Value, When
from django.http import JsonResponse
from django.utils import timezone
from django.views.decorators.csrf import csrf_exempt

from ..models import Holiday, LeaveApplication, TrackerTasks
from .common import get_session_user_data


@csrf_exempt
def get_hoursheet_data(request):
    try:
        user_data = get_session_user_data(request)
        if not user_data:
            return JsonResponse({"error": "User not logged in."}, status=401)

        username = user_data.get("name")
        if not username:
            return JsonResponse({"error": "Invalid user data."}, status=400)

        # --- Parse date range ---
        start_date = request.GET.get("start_date")
        end_date = request.GET.get("end_date")

        if not start_date or not end_date:
            today = datetime.today()
            start_of_week = today - timedelta(days=today.weekday())  # Monday
            end_of_week = start_of_week + timedelta(days=6)          # Sunday
            start_date = start_of_week.date()
            end_date = end_of_week.date()
        else:
            start_date = datetime.strptime(start_date, "%Y-%m-%d").date()
            end_date = datetime.strptime(end_date, "%Y-%m-%d").date()

        # --- Fetch tasks ---
        tasks = TrackerTasks.objects.filter(
            date1__range=[start_date, end_date],
            assigned=username
        )

        day_keys = ["mon", "tue", "wed", "thur", "fri", "sat", "sun"]

        # --- Group rows ---
        week_rows = {}
        for task in tasks:
            key = (
                task.projects,
                task.scope,
                task.title,
                task.category or "",
                task.rev or "",
                task.d_no or "",
                task.mail_no or "",
                task.ref_no or "",
            )

            if key not in week_rows:
                week_rows[key] = {
                    "projects": task.projects,
                    "scope": task.scope,
                    "title": task.title,
                    "category": task.category or "",
                    "rev": task.rev or "",
                    "d_no": task.d_no or "",
                    "mail_no": task.mail_no or "",
                    "ref_no": task.ref_no or "",
                    "comments": {},
                    "mon": 0, "tue": 0, "wed": 0, "thur": 0,
                    "fri": 0, "sat": 0, "sun": 0,
                }

            weekday = day_keys[task.date1.weekday()]
            week_rows[key][weekday] += float(task.time or 0)

            if task.comments:
                week_rows[key]["comments"][weekday] = task.comments

        # --- Prepare final list ---
        result_data = []
        for row in week_rows.values():
            row["total_hours"] = sum(row[d] for d in day_keys)
            result_data.append(row)

        # --- Dropdowns ---
        dropdowns = list(
            TrackerTasks.objects.values("projects", "scope", "title", "category").distinct()
        )

        return JsonResponse({
            "draw": int(request.GET.get("draw", 1)),
            "recordsTotal": len(result_data),
            "recordsFiltered": len(result_data),
            "data": result_data,
            "dropdowns": dropdowns,
        })

    except Exception as e:
        return JsonResponse({"error": str(e)}, status=500)


@csrf_exempt
def delete_timesheet_row(request):
    if request.method == 'POST':
        try:
            user_data = get_session_user_data(request)
            if not user_data:
                return JsonResponse({"status": "error", "message": "User not logged in."}, status=401)

            username = user_data.get("name")
            if not username:
                return JsonResponse({"status": "error", "message": "Invalid user data."}, status=400)

            data = json.loads(request.body)

            project = data.get('projects')
            scope = data.get('scope')
            title = data.get('title')
            category = data.get('category', '')

            # ✅ Require week_start
            week_start_str = data.get('week_start')
            if not week_start_str:
                return JsonResponse({"status": "error", "message": "week_start is required"}, status=400)

            try:
                week_start = datetime.strptime(week_start_str, "%Y-%m-%d").date()
            except ValueError:
                return JsonResponse({"status": "error", "message": "Invalid date format for week_start"}, status=400)

            week_end = week_start + timedelta(days=6)

            # ✅ Delete only this user's data for that week
            deleted_count, _ = TrackerTasks.objects.filter(
                projects=project,
                scope=scope,
                title=title,
                category=category,
                assigned=username,
                date1__range=(week_start, week_end)
            ).delete()

            return JsonResponse({"status": "success", "deleted": deleted_count})

        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)}, status=400)

    return JsonResponse({"status": "error", "message": "Method not allowed"}, status=405)


@csrf_exempt
def submit_timesheet(request):
    try:
        if request.method not in ["POST", "PUT"]:
            return JsonResponse({"status": "error", "message": "Method not allowed"}, status=405)

        user_data = get_session_user_data(request)
        if not user_data:
            return JsonResponse({"status": "error", "message": "User not logged in."}, status=401)

        username = user_data.get("name")
        data = json.loads(request.body.decode("utf-8"))

        if isinstance(data, dict):
            data = [data]

        for entry in data:
            # --- Validate required fields ---
            if not entry.get("projects") or not entry.get("scope") or not entry.get("title"):
                return JsonResponse({"status": "error", "message": "Missing required fields."}, status=400)

            # --- Parse and validate date ---
            # ✅ Parse and validate date
            try:
                date1 = datetime.strptime(entry["date1"], "%Y-%m-%d").date()
            except (KeyError, ValueError):
                return JsonResponse({
                    "status": "error",
                    "message": f"Invalid date format: {entry.get('date1')}"
                }, status=400)

            # 🚫 Prevent future date entries
            today = timezone.now().date()  # safer with timezone awareness
            if date1 > today:
                return JsonResponse({
                    "status": "error",
                    "message": f"Cannot add or update timesheet entries for future dates ({date1})."
                }, status=400)


            # --- Handle zero-hour entries (delete if exists) ---
            try:
                time_value = float(entry.get("time") or 0)
            except ValueError:
                time_value = 0.0

            if time_value <= 0:
                deleted_count, _ = TrackerTasks.objects.filter(
                    projects=entry["projects"],
                    scope=entry["scope"],
                    title=entry["title"],
                    category=entry.get("category", ""),
                    date1=date1,
                    assigned=username,
                ).delete()

                print(f"🗑️ Deleted {deleted_count} rows for {username} on {date1} (time=0).")
                continue

            # --- Check for existing task ---
            existing_task = TrackerTasks.objects.filter(
                projects=entry["projects"],
                scope=entry["scope"],
                title=entry["title"],
                category=entry.get("category", ""),
                date1=date1,
                assigned=username,
            ).first()

            if existing_task:
                # --- Detect if anything changed (time, comments, identifiers) ---
                has_changed = any([
                    float(existing_task.time or 0) != float(time_value),
                    (existing_task.comments or "").strip() != (entry.get("comments", "") or "").strip(),
                    existing_task.projects != entry["projects"],
                    existing_task.scope != entry["scope"],
                    existing_task.title != entry["title"],
                    existing_task.category != entry.get("category", "")
                ])

                if not has_changed:
                    # ✅ Skip update if data is identical (prevents duplicate saves)
                    print(f"⏭️ Skipped unchanged entry for {username} on {date1}")
                    continue

                # --- Update time and comments ---
                existing_task.time = time_value
                existing_task.comments = entry.get("comments", "")

                # --- If identifiers changed, refresh linked metadata ---
                if any([
                    existing_task.projects != entry["projects"],
                    existing_task.scope != entry["scope"],
                    existing_task.title != entry["title"],
                    existing_task.category != entry.get("category", "")
                ]):
                    existing_task.projects = entry["projects"]
                    existing_task.scope = entry["scope"]
                    existing_task.title = entry["title"]
                    existing_task.category = entry.get("category", "")

                    last_task = TrackerTasks.objects.filter(
                        projects=entry["projects"],
                        scope=entry["scope"],
                        title=entry["title"],
                        category=entry.get("category", "")
                    ).exclude(id=existing_task.id).order_by("-date1").first()

                    existing_task.task_benchmark = last_task.task_benchmark if last_task else 0
                    existing_task.d_no = last_task.d_no if last_task else ""
                    existing_task.rev = last_task.rev if last_task else ""
                    existing_task.mail_no = last_task.mail_no if last_task else ""
                    existing_task.ref_no = last_task.ref_no if last_task else ""
                    existing_task.list = last_task.list if last_task else ""

                existing_task.save()
                print(f"💾 Updated modified entry for {username} on {date1}")


            else:
                # --- Create new record ---
                last_task = TrackerTasks.objects.filter(
                    projects=entry["projects"],
                    scope=entry["scope"],
                    title=entry["title"],
                    category=entry.get("category", "")
                ).order_by("-date1").first()

                TrackerTasks.objects.create(
                    projects=entry["projects"],
                    scope=entry["scope"],
                    title=entry["title"],
                    category=entry.get("category", ""),
                    date1=date1,
                    assigned=username,
                    time=time_value,
                    comments=entry.get("comments", ""),
                    task_benchmark=entry.get("task_benchmark") or (last_task.task_benchmark if last_task else 0),
                    d_no=entry.get("d_no") or (last_task.d_no if last_task else ""),
                    rev=entry.get("rev") or (last_task.rev if last_task else ""),
                    mail_no=entry.get("mail_no") or (last_task.mail_no if last_task else ""),
                    ref_no=entry.get("ref_no") or (last_task.ref_no if last_task else ""),
                    list=entry.get("list") or (last_task.list if last_task else "")
                )

            # ==========================================================
            # 🧮 WEEKLY COMPENSATION CALCULATION (Final Correct Version)
            # ==========================================================
            from datetime import timedelta
            from django.db.models import Sum, FloatField, Case, When, Value

            year, week, _ = date1.isocalendar()
            first_day = datetime.fromisocalendar(year, week, 1).date()  # Monday
            last_day = datetime.fromisocalendar(year, week, 7).date()   # Sunday

            # --- Get all tasks for this week ---
            tasks_in_week = TrackerTasks.objects.filter(
                assigned=username, date1__range=[first_day, last_day]
            )
            total_week_hours = tasks_in_week.aggregate(total=Sum("time"))["total"] or 0.0

            # --- Get holidays in the week ---
            holidays_in_week = list(
                Holiday.objects.filter(date__range=[first_day, last_day])
                .values_list("date", flat=True)
            )
            holiday_count = len(holidays_in_week)

            # --- Calculate leave days (half/full day handling) ---
            leaves_in_week = (
                LeaveApplication.objects.filter(
                    username__iexact=username,
                    start_date__lte=last_day,
                    end_date__gte=first_day,
                )
                .annotate(
                    leave_value=Case(
                        When(leave_type="Half Day", then=Value(0.5)),
                        When(leave_type="Full Day", then=Value(1.0)),
                        default=Value(0.0),
                        output_field=FloatField(),
                    )
                )
                .aggregate(total=Sum("leave_value"))["total"]
                or 0.0
            )

            # ==========================================================
            # ✅ EXPECTED HOURS CALCULATION
            # ==========================================================
            BASELINE_HOURS = 45.0  # 5 working days × 9 hrs/day
            expected_hours = BASELINE_HOURS - ((holiday_count * 9) + (leaves_in_week * 9))
            if expected_hours < 0:
                expected_hours = 0

            extra_hours = total_week_hours - expected_hours

            # --- Identify weekend & holiday work ---
            weekend_days = [
                first_day + timedelta(days=i)
                for i in range(7)
                if (first_day + timedelta(days=i)).weekday() >= 5  # Saturday & Sunday
            ]
            weekend_or_holiday_tasks = TrackerTasks.objects.filter(
                assigned=username,
                date1__in=weekend_days + holidays_in_week
            ).aggregate(total=Sum("time"))["total"] or 0.0

            # ==========================================================
            # 🧠 COMPENSATION DECISION LOGIC
            # ==========================================================
            if weekend_or_holiday_tasks > 0:
                if extra_hours >= 8:
                    is_compensated = 1.0
                    status = "Full Day Earned (Weekend/Holiday Work)"
                elif extra_hours >= 4:
                    is_compensated = 0.5
                    status = "Half Day Earned (Weekend/Holiday Work)"
                else:
                    is_compensated = 0.0
                    status = "Not Compensated (Insufficient Extra Hours)"
            else:
                is_compensated = 0.0
                status = "Not Compensated (No Weekend/Holiday Work)"

            # ==========================================================
            # ✅ UPDATE LOGIC — Reset weekdays, update weekends/holidays only
            # ==========================================================
            weekday_tasks_updated = TrackerTasks.objects.filter(
                assigned=username,
                date1__range=[first_day, last_day]
            ).exclude(
                date1__in=weekend_days + holidays_in_week
            ).update(is_compensated=0)

            special_tasks_updated = TrackerTasks.objects.filter(
                assigned=username,
                date1__in=weekend_days + holidays_in_week
            ).update(is_compensated=is_compensated)

            print(
                f"✅ Week {week} ({first_day}–{last_day}) | Total={total_week_hours} | Expected={expected_hours} | "
                f"Extra={extra_hours} | Weekend/Holiday Hours={weekend_or_holiday_tasks} | "
                f"Leaves={leaves_in_week} | Holidays={holiday_count} | "
                f"Weekday reset={weekday_tasks_updated} | Updated={special_tasks_updated} | {status}"
            )

            print(
                f"🧮 Expected Hours = 45 - (({holiday_count} holidays × 9) + "
                f"({leaves_in_week} leave days × 9)) = {expected_hours}"
            )



        return JsonResponse({
            "status": "success",
            "message": "Timesheet saved/updated successfully."
        })

    except Exception as e:
        import traceback
        traceback.print_exc()
        return JsonResponse({"status": "error", "message": str(e)}, status=500)


def get_times_by_date(request):
    if request.method == 'GET':
        # Get the date1 parameter from the GET request
        date1 = request.GET.get('date1', None)
        
        if not date1:
            return JsonResponse({'error': 'date1 parameter is required'}, status=400)
        
        try:
            # Fetch rows matching the provided date1
            select_query = """
                SELECT id, title, `list`, projects, scope, category, date1, time, comments, assigned, rev, d_no,
                FROM tracker_project 
                WHERE date1 = %s
                ORDER BY id ASC
            """
            with connection.cursor() as cursor:
                cursor.execute(select_query, [date1])
                rows = cursor.fetchall()
                columns = [col[0] for col in cursor.description]
            
            # Convert the query result to a list of dictionaries
            timesheet_entries = [dict(zip(columns, row)) for row in rows]

            # Return the results as a JSON response
            return JsonResponse({'timesheet_entries': timesheet_entries}, status=200)
        
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)

    return JsonResponse({'error': 'Invalid request method'}, status=405)


def get_all_times_by_month(request):
    year = request.GET.get('year')
    month = request.GET.get('month')

    if not year or not month:
        return JsonResponse({'error': 'Year and month parameters are required'}, status=400)

    try:
        # Query to get entries for the given year and month
        query = """
            SELECT id, title, date1, time, projects, scope ,comments, assigned
            FROM tracker_project 
            WHERE YEAR(date1) = %s AND MONTH(date1) = %s
        """
        with connection.cursor() as cursor:
            cursor.execute(query, [year, month])
            rows = cursor.fetchall()
            columns = [col[0] for col in cursor.description]

        # Convert query result to a list of dictionaries
        timesheet_entries = [dict(zip(columns, row)) for row in rows]

        return JsonResponse({'timesheet_entries': timesheet_entries}, status=200)

    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)


def get_tasks_by_date(request):
    date1 = request.GET.get('date1')

    if not date1:
        return JsonResponse({'error': 'date1 parameter is required'}, status=400)

    try:
        query = """
            SELECT id, title, projects, scope, date1, time, comments, rev, d_no,
            FROM tracker_project 
            WHERE date1 = %s
        """
        with connection.cursor() as cursor:
            cursor.execute(query, [date1])
            rows = cursor.fetchall()
            columns = [col[0] for col in cursor.description]

        tasks = [dict(zip(columns, row)) for row in rows]
        return JsonResponse({'tasks': tasks}, status=200)

    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)

__all__ = [
    "get_hoursheet_data",
    "delete_timesheet_row",
    "submit_timesheet",
    "get_times_by_date",
    "get_all_times_by_month",
    "get_tasks_by_date",
]
