import base64
import json
from datetime import datetime

from django.http import JsonResponse
from django.shortcuts import render

from ..models import EmployeeDetails, ProjectTacker, TrackerTasks, UserinfoView
from .common import get_session_user_data, require_session_user_json


def task_dashboard(request):
    user_data = get_session_user_data(request) or {}

    # Default data
    user_id = user_data.get("employee_id")
    name = user_data.get("name", "Guest")
    designation = user_data.get("designation") or "NO DESIGNATION"
    authentication = user_data.get("authentication")
    image_base64 = None

    if user_id:
        employee = (
            EmployeeDetails.objects.only("designation", "image")
            .filter(employee_id=user_id)
            .first()
        )
        if employee:
            designation = employee.designation or designation
            if employee.image:
                image_base64 = base64.b64encode(employee.image).decode("utf-8")

    # ✅ Determine admin/MD status safely
    is_admin_or_md = authentication and authentication.lower() in ['admin', 'md']

    # Pass data to the template
    return render(
        request,
        "tasks_dashboard.html",
        {
            "name": name,
            "designation": designation,
            "authentication": authentication,  # ✅ optional but consistent
            "image_base64": image_base64,
            "employee_id": user_id,
            "is_admin_or_md": is_admin_or_md,
        },
    )


def convert_bytes_safe(data):
    """Convert bytes to strings where possible, handle non-UTF-8 bytes gracefully."""
    if isinstance(data, bytes):
        try:
            # Try decoding as UTF-8
            return data.decode("utf-8")
        except UnicodeDecodeError:
            # If decoding fails, return a placeholder or handle it differently
            return f"[binary data: {len(data)} bytes]"  # Or return None to ignore it

    if isinstance(data, dict):
        return {key: convert_bytes_safe(value) for key, value in data.items()}
    if isinstance(data, list):
        return [convert_bytes_safe(item) for item in data]
    return data


@require_session_user_json
def task_dashboard_api(request):
    user_name = request.session_user_data.get("name")

    project_statuses = list(
        ProjectTacker.objects.filter(sender_name=user_name).values_list("status", flat=True)
    )

    tasks = list(
        TrackerTasks.objects.all().values(
            "id",
            "title",
            "scope",
            "date1",
            "time",
            "assigned",
            "category",
            "projects",
            "list",
            "rev",
            "comments",
            "task_benchmark",
            "d_no",
            "mail_no",
            "ref_no",
            "verification_status",
            "task_status",
            "team",
        )
    )

    employee_details = convert_bytes_safe(
        list(
            EmployeeDetails.objects.values(
                "employee_id",
                "name",
                "designation",
                "email",
                "phone_number",
                "department",
                "status",
                "authentication",
                "image",
            )
        )
    )

    return JsonResponse(
        {
            "success": True,
            "message": "Data fetched successfully",
            "status_list": project_statuses,
            "tasks": tasks,
            "employee_details": employee_details,
        }
    )


def fetch_task_dashboard_data(user_id, selected_date_str):
    """
    Fetch the data required for the task dashboard.

    Args:
        user_id (int): The ID of the logged-in user.
        selected_date_str (str): The selected date as a string.

    Returns:
        dict: A dictionary containing designation, selected_date, monthly_calendar_data, and userroles.
    """
    # Fetch the user's designation
    designation = (
        EmployeeDetails.objects.filter(employee_id=user_id)
        .values_list("designation", flat=True)
        .first()
    )

    # Parse the selected date or use the current date
    try:
        selected_date = (
            datetime.strptime(selected_date_str, "%Y-%m-%d").date()
            if selected_date_str
            else datetime.now().date()
        )
    except ValueError:
        selected_date = datetime.now().date()
        print("Invalid date format provided. Defaulting to today's date.")

    # Fetch task data for the selected date
    monthly_calendar_qs = TrackerTasks.objects.filter(date1=selected_date).values(
        "id",
        "title",
        "scope",
        "date1",
        "time",
        "assigned",
        "category",
        "projects",
        "list",
        "rev",
        "comments",
        "task_benchmark",
        "d_no",
        "mail_no",
        "ref_no",
        "verification_status",
        "task_status",
        "team",
    )
    monthly_calendar_data = [
        {
            "id": row["id"],
            "title": row["title"],
            "scope": row["scope"],
            "date": row["date1"],
            "time": row["time"],
            "assigned": row["assigned"],
            "category": row["category"],
            "project": row["projects"],
            "list": row["list"],
            "rev_no": row["rev"],
            "comments": row["comments"],
            "benchmark": row["task_benchmark"],
            "d_no": row["d_no"],
            "mail_no": row["mail_no"],
            "ref_no": row["ref_no"],
            "verification_status": row["verification_status"],
            "task_status": row["task_status"],
            "team": row["team"],
        }
        for row in monthly_calendar_qs
    ]

    # Fetch all user roles from UserinfoView
    userroles = list(UserinfoView.objects.values("name", "role"))

    return {
        "designation": designation,
        "selected_date": selected_date,
        "monthly_calendar_data": monthly_calendar_data,
        "userroles": userroles,  # <--- included!
    }


__all__ = [
    "task_dashboard",
    "convert_bytes_safe",
    "task_dashboard_api",
    "fetch_task_dashboard_data",
]
