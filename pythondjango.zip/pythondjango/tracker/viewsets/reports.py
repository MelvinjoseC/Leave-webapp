import base64
import math
from datetime import timedelta

from django.db.models import Case, Count, FloatField, Q, Value, When
from django.http import JsonResponse
from django.shortcuts import render

from ..models import (
    EmployeeDetails,
    Holiday,
    LeaveApplication,
    Monthlycalendar,
    TrackerTasks,
    UserinfoView,
)
from .common import get_session_user_data


def apply_effectiveness(raw_time, assigned, user_effectiveness, default_eff=100.0):
    """
    Apply effectiveness % reduction and round UP to nearest 0.5.
    raw_time      = numeric hours from DB
    assigned      = string (employee name)
    user_effectiveness = dict {name.lower(): effectiveness%}
    default_eff   = 100 if no entry found
    """
    try:
        raw = float(raw_time or 0)
    except (TypeError, ValueError):
        raw = 0.0

    key = (assigned or "").strip().lower()
    eff = float(user_effectiveness.get(key, default_eff))

    adjusted = (raw * eff) / 100.0
    adjusted = math.ceil(adjusted * 2) / 2.0  # round up to nearest 0.5

    return raw, adjusted


def report_view_page(request):
    user_data = get_session_user_data(request)

    # 1. Fetch all TrackerTasks
    all_tasks = list(TrackerTasks.objects.all())

    # 2. Fetch all Monthlycalendar rows
    monthly_rows = Monthlycalendar.objects.all().order_by("-updated")

    # 3. Build effectiveness lookup {name.lower(): effectiveness}
    user_effectiveness = {
        (u.name or "").strip().lower(): float(u.effectiveness or 100)
        for u in UserinfoView.objects.all()
    }

    # 4. Build lookup: (d_no, date) -> Monthlycalendar (latest only)
    monthly_lookup = {}
    for m in monthly_rows:
        key = (m.d_no, m.date)
        if key not in monthly_lookup:
            monthly_lookup[key] = m

    # 5. Merge TrackerTasks + Monthlycalendar
    merged_data = []
    for task in all_tasks:
        raw_time, adjusted_time = apply_effectiveness(
            task.time, task.assigned, user_effectiveness
        )

        base_row = {
            "tracker_id": task.id,
            "monthly_id": None,
            "d_no": task.d_no,
            "title": task.title,
            "scope": task.scope,
            "category": task.category,
            "designation": getattr(task, "designation", ""),   # ✅ include designation
            "assigned": task.assigned,
            "status": getattr(task, "status", ""),
            "rev_no": task.rev,
            "time": raw_time,                 # raw value from DB
            "effective_time": adjusted_time,  # adjusted using effectiveness
            "comments": getattr(task, "comments", ""),
            "mail_no": getattr(task, "mail_no", ""),
            "ref_no": getattr(task, "ref_no", ""),
            "projects": task.projects,
            "list": task.list,
            "date1": task.date1,
            "task_benchmark": getattr(task, "task_benchmark", 0),
            "source": "tracker",
        }

        # Override with Monthlycalendar if exists
        monthly = monthly_lookup.get((task.d_no, task.date1))
        if monthly:
            raw_time, adjusted_time = apply_effectiveness(
                monthly.time if monthly.time is not None else base_row["time"],
                monthly.assigned or task.assigned,
                user_effectiveness
            )

            base_row.update({
                "monthly_id": monthly.id,
                "title": monthly.title or base_row["title"],
                "scope": monthly.scope or base_row["scope"],
                "category": monthly.category or base_row["category"],
                "designation": getattr(monthly, "designation", "") or base_row["designation"],  # ✅ pull from monthly
                "assigned": monthly.assigned or base_row["assigned"],
                "status": monthly.status or base_row["status"],
                "rev_no": monthly.rev_no or base_row["rev_no"],
                "time": raw_time,                 # raw
                "effective_time": adjusted_time,  # adjusted
                "comments": monthly.comments or base_row["comments"],
                "mail_no": monthly.mail_no or base_row["mail_no"],
                "ref_no": monthly.ref_no or base_row["ref_no"],
                "projects": monthly.project or base_row["projects"],
                "list": monthly.list or base_row["list"],
                "source": "monthly",
            })

        merged_data.append(base_row)

    # Sidebar user info
    user_id = user_data.get("employee_id", None) if user_data else None
    name = user_data.get("name", "Guest") if user_data else "Guest"
    designation = user_data.get("designation", "NO DESIGNATION") if user_data else "NO DESIGNATION"
    # Convert BLOB image to Base64 string (safe for HTML <img>)
    image_base64 = None
    if user_data and user_data.get("image"):
        try:
            # Encode the binary image data
            image_base64 = base64.b64encode(user_data["image"]).decode('utf-8')
        except Exception as e:
            print("Error converting image:", e)

    if user_id:
        try:
            employee = EmployeeDetails.objects.get(employee_id=user_id)
            designation = employee.designation
            if employee.image:
                image_base64 = base64.b64encode(employee.image).decode("utf-8")
        except EmployeeDetails.DoesNotExist:
            designation = "Employee not found"

    # JSON response
    if request.headers.get("x-requested-with") == "XMLHttpRequest" or request.GET.get("format") == "json":
        return JsonResponse({"tracker_project_data": merged_data}, safe=False)

    # Render template
    return render(
        request,
        "report_view.html",
        {
            "tracker_project_data": merged_data,
            "range_6": range(6),
            "name": name,
            "designation": designation,
            "image_base64": image_base64,
            "employee_id": user_id,
        },
    )


def generate_pie_chart(request):

    # ✅ Ensure user is logged in
    user_data = get_session_user_data(request)
    if not user_data:
        return JsonResponse({"error": "User not logged in."}, status=401)

    username = user_data.get("name")  # Get username from session user data

    try:
        # ✅ Fetch Leave Data using ORM
        leave_data = LeaveApplication.objects.filter(
            username=username, md_status='Approved'
        ).values(
            'leave_type'
        ).annotate(
            count=Count('id')
        )

        # ✅ Initialize counts
        full_day_leave = 0
        half_day_leave = 0
        work_from_home = 0

        # ✅ Get all holidays for current year
        holidays = set(Holiday.objects.values_list("date", flat=True))

        # ✅ Fetch all approved leave records (not just aggregated)
        leaves = LeaveApplication.objects.filter(
            username=username
        ).filter(
            Q(status='Approved') | Q(status='Final Approved')
        ).values('start_date', 'end_date', 'leave_type')

        for leave in leaves:
            start = leave["start_date"]
            end = leave["end_date"]
            leave_type = leave["leave_type"]

            # Build list of all days between start & end
            current = start
            total_days = 0
            while current <= end:
                # ✅ Skip weekends and holidays
                if current.weekday() not in (5, 6) and current not in holidays:
                    total_days += 1
                current += timedelta(days=1)

            # ✅ Count leave days by type
            if leave_type == "Full Day":
                full_day_leave += total_days
            elif leave_type == "Half Day":
                half_day_leave += total_days * 0.5
            elif leave_type == "Work From Home":
                work_from_home += total_days

        # ✅ Fetch Attendance Data (Redeemed Leaves) using ORM
        from django.db.models import FloatField, Value, Case, When

        redeemed_days = (
            TrackerTasks.objects
            .filter(
                assigned=username,
                redeemed=1,
                comp_status__in=["Half Day", "Full Day"]
            )
            .values("date1")  # keep date1 for grouping
            .annotate(
                day_value=Case(
                    When(comp_status="Full Day", then=Value(1.0)),
                    When(comp_status="Half Day", then=Value(0.5)),
                    default=Value(0.0),
                    output_field=FloatField(),
                )
            )
        )

        unique_days = {}
        for record in redeemed_days:
            date = record["date1"]
            value = record["day_value"]
            if date not in unique_days:
                unique_days[date] = value
            else:
                # take the higher one if same date has multiple
                unique_days[date] = max(unique_days[date], value)

        redeemed_days_total = sum(unique_days.values())
        total_working_days = 20 + redeemed_days_total

        # ✅ Calculate Balance Leave Available
        balance_leave = total_working_days - (full_day_leave + (half_day_leave))

        return JsonResponse({
            "balance_leave": balance_leave,
            "full_day_leave": full_day_leave,
            "half_day_leave": half_day_leave,
            "work_from_home": work_from_home,
        })

    except Exception as e:
        return JsonResponse({"error": str(e)}, status=500)

__all__ = [
    "apply_effectiveness",
    "report_view_page",
    "generate_pie_chart",
]
