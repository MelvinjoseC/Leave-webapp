import base64
import json
from datetime import date, datetime, timedelta

from django.core.files.storage import default_storage
from django.db import models
from django.http import JsonResponse
from django.shortcuts import redirect, render
from django.views.decorators.csrf import csrf_exempt

from ..models import EmployeeDetails, Holiday, LeaveApplication, TrackerTasks
from .common import get_session_user_data, require_session_user_json


def _parse_date(value, formats=("%Y-%m-%d", "%d-%m-%Y")):
    for fmt in formats:
        try:
            return datetime.strptime(value.strip(), fmt).date()
        except (ValueError, AttributeError):
            continue
    return None


def _load_employee(employee_id, fields):
    return (
        EmployeeDetails.objects.filter(employee_id=employee_id)
        .values(*fields)
        .first()
    )


def _get_employee_role(name):
    role = (
        EmployeeDetails.objects.filter(name__iexact=name)
        .values_list("authentication", flat=True)
        .first()
    )
    return (role or "").strip().lower()


def leave_policy_view(request):
    """
    Displays the Leave Policy PDF in a dedicated page.
    """
    return render(request, "leave_policy.html")


def mainleavepage_view(request):
    user_data = get_session_user_data(request)
    if not user_data:
        return JsonResponse({"error": "User not logged in."}, status=401)

    user_id = user_data.get("employee_id")
    name = user_data.get("name", "Guest")
    designation = user_data.get("designation")
    image_base64 = None

    # ✅ Always fetch image (and fill missing designation)
    if user_id:
        employee = _load_employee(user_id, ("designation", "image"))
        if employee:
            designation = designation or (employee.get("designation") or "No Designation")
            image_field = employee.get("image")
            if image_field:
                if isinstance(image_field, bytes):
                    image_base64 = base64.b64encode(image_field).decode("utf-8")
                else:
                    with default_storage.open(image_field.name, "rb") as img_file:
                        image_base64 = base64.b64encode(img_file.read()).decode("utf-8")

    today = datetime.today().date()
    current_year = today.year

    # ✅ Fetch holidays
    holidays = (
        Holiday.objects.filter(date__year=current_year)
        .exclude(date__week_day=7)
        .order_by("date")
    )
    holidays = [{"name": h.name, "date": h.date.strftime("%Y-%m-%d")} for h in holidays]

    # ✅ Fetch leave applications
    leave_applications = LeaveApplication.objects.filter(username=name).values(
        "id", "start_date", "end_date", "reason", "username", "approver",
        "leave_type", "created_at", "updated_at", "status"
    )

    # ✅ Check admin/MD
    is_admin = False
    is_md = False
    auth_value = _get_employee_role(name)
    is_admin = auth_value == "admin"
    is_md = auth_value == "md"

    return render(request, "mainleavepage.html", {
        "name": name,
        "designation": designation,
        "image_base64": image_base64,
        "employee_id": user_id,
        "is_admin": is_admin,
        "is_md": is_md,
        "holidays": holidays,
        "leave_applications": leave_applications,
    })


@require_session_user_json
def apply_leave_view(request):

    if request.method == "POST":
        try:
            current_user_name = request.session_user_data["name"]

            # ✅ Step 2: Get form fields
            start_date = request.POST.get("from_date", "").strip()
            end_date = request.POST.get("to_date", "").strip()
            leave_type = request.POST.get("leave-type", "").strip()
            reason = request.POST.get("reason", "").strip()  # Optional
            approver_name = request.POST.get("approver", "").strip()

            # ✅ Step 3: Validate required fields (reason optional)
            if not all([start_date, end_date, leave_type, approver_name]):
                return JsonResponse({"error": "Required fields missing."}, status=400)

            # ✅ Step 4: Convert to date objects
            today = date.today()
            start = _parse_date(start_date, ("%Y-%m-%d",))
            end = _parse_date(end_date, ("%Y-%m-%d",))
            if not start or not end:
                return JsonResponse({"error": "Invalid date format."}, status=400)

            if start < today:
                return JsonResponse({"error": "Cannot apply leave for past dates."}, status=400)
            if end < start:
                return JsonResponse({"error": "End date cannot be before start date."}, status=400)

            # ✅ Step 5: Build all days between start and end
            all_dates = []
            current = start
            while current <= end:
                all_dates.append(current)
                current += timedelta(days=1)

            # ✅ Step 6: Fetch holidays dynamically from DB
            holidays = set(
                Holiday.objects.filter(date__range=[start, end]).values_list("date", flat=True)
            )

            # ✅ Step 7: Exclude weekends (Sat/Sun) and holidays
            valid_dates = [d for d in all_dates if d.weekday() not in (5, 6) and d not in holidays]
            skipped_dates = [d for d in all_dates if d not in valid_dates]

            if not valid_dates:
                return JsonResponse({
                    "error": "All selected dates fall on weekends or holidays. Please choose working days."
                }, status=400)

            leave_days = len(valid_dates)

            # ✅ Step 8: Get approver details
            approver_record = EmployeeDetails.objects.filter(name__iexact=approver_name).first()
            if not approver_record:
                return JsonResponse({"error": f"Approver '{approver_name}' not found."}, status=404)

            approver_role = approver_record.authentication.lower()

           # ✅ Step 9: Determine leave status
            if approver_role == "md":
                # MD as approver — directly goes to MD pending approval
                status_value = "Approved"
                md_status_value = "Pending"
                message = f"Leave submitted successfully for {leave_days} working day(s) and sent for MD approval."
            else:
                # Normal case — admin or other approver
                status_value = "Pending"
                md_status_value = "Pending"
                message = f"Leave request submitted successfully for {leave_days} working day(s) and sent for approval."

            # ✅ Step 10: Save leave application
            LeaveApplication.objects.create(
                start_date=start,
                end_date=end,
                reason=reason,
                username=current_user_name,
                approver=approver_name,
                leave_type=leave_type,
                status=status_value,
                md_status=md_status_value,
            )

            # ✅ Step 11: Return message including weekends/holidays info
            if skipped_dates:
                skipped_str = ", ".join([d.strftime("%Y-%m-%d") for d in skipped_dates])
                message += f" (Skipped weekends/holidays: {skipped_str})"

            return JsonResponse({"message": message, "leave_days": leave_days}, status=200)

        except Exception as e:
            print("[ERROR] apply_leave_view:", str(e))
            return JsonResponse({"error": f"Something went wrong: {str(e)}"}, status=500)

    return JsonResponse({"error": "Invalid request method."}, status=405)


def get_holidays(request):
    """Fetch upcoming holidays only for the current year, excluding Saturdays."""
    try:
        today = datetime.today().date()
        current_year = today.year  # Get current year dynamically

        # Query the Holiday model to get holidays for the current year, excluding Saturdays
        holidays = Holiday.objects.filter(date__year=current_year).exclude(date__week_day=7).order_by('date')

        # Convert holidays to JSON format with status
        holiday_list = []
        for holiday in holidays:
            holiday_date = holiday.date
            status = "past" if holiday_date < today else "upcoming"

            holiday_list.append({
                "name": holiday.name,
                "date": holiday_date.strftime("%Y-%m-%d"),
                "status": status  # Add status for styling in JS
            })

        return JsonResponse({"holidays": holiday_list})

    except Exception as e:
        return JsonResponse({"error": str(e)}, status=500)


@require_session_user_json
def leave_application_view(request):
    current_user_name = request.session_user_data["name"]

    try:
        # ✅ Fetch Leave Counts by Type (Approved) using Django ORM
        leave_data = (
            LeaveApplication.objects.filter(username=current_user_name, status='Approved')
            .values('leave_type')
            .annotate(count=models.Count('id'))
        )
        leave_counts = {entry['leave_type']: entry['count'] for entry in leave_data}
        full_day_leave = leave_counts.get('Full Day', 0)
        half_day_leave = leave_counts.get('Half Day', 0)
        work_from_home = leave_counts.get('Work From Home', 0)

        # ✅ Fetch Redeemed Days from Attendance using Django ORM
        # ✅ Calculate total redeemed compensated days from TrackerTasks
        redeemed_tasks = TrackerTasks.objects.filter(
            assigned=current_user_name,
            redeemed=1
        )

        redeemed_days = 0.0  # Initialize total

        for task in redeemed_tasks:
            if task.comp_status and "half" in task.comp_status.lower():
                redeemed_days += 0.5
            elif task.comp_status and "full" in task.comp_status.lower():
                redeemed_days += 1.0

        # ✅ Calculate Balance Leave
        total_working_days = 20 + redeemed_days
        balance_leave = total_working_days - (full_day_leave + (half_day_leave * 0.5))

        # ✅ Fetch Leave Applications List using Django ORM
        leave_records = LeaveApplication.objects.filter(username=current_user_name).values(
            'id', 'start_date', 'end_date', 'reason', 'username', 'approver',
            'leave_type', 'created_at', 'updated_at', 'status', 'md_status'
        )

        # ✅ Add "Paid"/"Unpaid" Label Based on balance_leave
        labeled_leaves = []
        for leave in leave_records:
            if balance_leave > 0:
                leave["leave_payment_type"] = "Paid Leave"
                balance_leave -= 1  # Deduct 1 day per leave counted as paid
            else:
                leave["leave_payment_type"] = "Unpaid Leave"
            labeled_leaves.append(leave)

        return JsonResponse({
            "leave_applications": labeled_leaves,
            "balance_leave": balance_leave,
            "full_day_leave": full_day_leave,
            "half_day_leave": half_day_leave,
            "work_from_home": work_from_home,
            "redeemed_days": redeemed_days,
        })

    except Exception as e:
        return JsonResponse({"error": str(e)}, status=500)


@require_session_user_json
def leave_approvals_view(request):
    current_user_name = request.session_user_data["name"]

    # ✅ Get current user's role
    role = _get_employee_role(current_user_name)
    if not role:
        return JsonResponse({"error": "User not found."}, status=404)

    # ✅ ADMIN — show leaves assigned to this admin
    if role == "admin":
        pending_leaves = LeaveApplication.objects.filter(
            status="Pending",
            approver__icontains=current_user_name
        )

    # ✅ MD — show leaves waiting for MD approval
    elif role == "md":
        pending_leaves = LeaveApplication.objects.filter(
            models.Q(status="Approved", md_status="Pending") |
            models.Q(status="Approved", approver__icontains="MD")
        )

    else:
        return JsonResponse({"error": "Forbidden: Only Admins or MDs can access this."}, status=403)

    data = list(pending_leaves.values(
        "id",
        "username",
        "start_date",
        "end_date",
        "reason",
        "leave_type",
        "created_at",
        "updated_at",
        "status",
        "md_status",
        "approver"
    ))
    return JsonResponse(data, safe=False)


@csrf_exempt
@require_session_user_json
def update_leave_status(request):
    current_user_name = request.session_user_data["name"]

    role = _get_employee_role(current_user_name)
    if not role:
        return JsonResponse({"error": "User not found."}, status=404)

    if request.method != "POST":
        return JsonResponse({"error": "Invalid request method. Use POST."}, status=405)

    try:
        data = json.loads(request.body)
        leave_id = data.get("id")
        new_status = str(data.get("status", "")).strip().lower()  # ✅ normalize

        if not leave_id or not new_status:
            return JsonResponse({"error": "Missing required fields."}, status=400)

        leave = LeaveApplication.objects.get(id=leave_id)

        # ✅ ADMIN ACTIONS
        if role == "admin":
            if new_status == "approved":
                leave.status = "Approved"
                leave.md_status = "Pending"
                leave.save()
                return JsonResponse({"message": "Leave approved by Admin and sent to MD for final approval."})

            elif new_status == "rejected":
                leave.status = "Rejected"
                leave.md_status = "Rejected"
                leave.save()
                return JsonResponse({"message": "Leave rejected by Admin."})

        # ✅ MD ACTIONS
        elif role == "md":
            if new_status in ("final approved", "approved", "finalapproved"):
                leave.status = "Final Approved"
                leave.md_status = "Approved"
                leave.save()

                # ✅ Optional: Deduct leave balance
                emp = EmployeeDetails.objects.filter(name=leave.username).first()
                if emp and hasattr(emp, "remaining_leaves"):
                    emp.remaining_leaves = max(0, emp.remaining_leaves - 1)
                    emp.save()

                return JsonResponse({"message": "Leave fully approved by MD."})

            elif new_status == "rejected":
                leave.status = "Rejected"
                leave.md_status = "Rejected"
                leave.save()
                return JsonResponse({"message": "Leave rejected by MD."})

        else:
            return JsonResponse({"error": "Unauthorized user."}, status=403)

        # ✅ DEFAULT RETURN — catches unknown statuses
        return JsonResponse({
            "error": f"Invalid status value '{new_status}' provided. Expected one of: Approved, Final Approved, Rejected."
        }, status=400)

    except LeaveApplication.DoesNotExist:
        return JsonResponse({"error": "Leave not found."}, status=404)

    except Exception as e:
        return JsonResponse({"error": str(e)}, status=500)


@require_session_user_json
def md_leave_approvals_view(request):
    user_data = request.session_user_data
    is_md = _get_employee_role(user_data["name"]) == "md"

    if not is_md:
        return JsonResponse({"error": "Forbidden: Only MDs can access this."}, status=403)

    # ✅ Show only:
    # - Leaves that have admin-approved (status='Approved')
    # - md_status still pending
    # - or directly requested to MD (approver__icontains='MD' AND status='Pending')
    pending_md_leaves = LeaveApplication.objects.filter(
        models.Q(status='Approved') & models.Q(md_status='Pending')
    ).values(
        'id', 'start_date', 'end_date', 'reason', 'username', 'approver',
        'leave_type', 'created_at', 'updated_at', 'status', 'md_status'
    )

    return JsonResponse(list(pending_md_leaves), safe=False)


@require_session_user_json
def delete_leave_application_view(request, leave_id):

    if request.method != "POST":
        return JsonResponse({"error": "Invalid request method. Use POST instead."}, status=405)

    current_user_name = request.session_user_data["name"]

    try:
        # Fetch the leave application using Django ORM
        leave = LeaveApplication.objects.get(id=leave_id, username=current_user_name)

        start_date = leave.start_date
        status = leave.status.lower()

        # Check if the start date is in the past
        if start_date < datetime.today().date():
            return JsonResponse({"error": "You cannot delete leave applications with a start date in the past."}, status=403)

        # Delete the leave application
        leave.delete()

        return JsonResponse({"success": "✅ Leave application deleted successfully."})

    except LeaveApplication.DoesNotExist:
        return JsonResponse({"error": "Leave application not found or unauthorized."}, status=404)

    except Exception as e:
        return JsonResponse({"error": f"Internal Server Error: {str(e)}"}, status=500)


@require_session_user_json
def edit_leave_application_view(request, leave_id):

    if request.method != "POST":
        return JsonResponse({"error": "Invalid request method."}, status=405)

    current_user_name = request.session_user_data["name"]
    data = request.POST

    # Convert the provided start_date to a datetime object
    try:
        start_date = datetime.strptime(data.get("start_date"), "%Y-%m-%d").date()
    except ValueError:
        return JsonResponse({"error": "Invalid start date format."}, status=400)

    # Check if the start date is in the past
    if start_date < datetime.today().date():
        return JsonResponse({"error": "You cannot update the leave application to a past date."}, status=403)

    try:
        # Fetch the leave application object
        leave_application = LeaveApplication.objects.get(id=leave_id, username=current_user_name)

        # Update the fields
        leave_application.start_date = start_date
        leave_application.end_date = data.get("end_date")
        leave_application.reason = data.get("reason")
        leave_application.leave_type = data.get("leave_type")
        leave_application.updated_at = datetime.now()  # Update the timestamp

        # Save the updated leave application to the database
        leave_application.save()

        return JsonResponse({"success": "Leave application updated successfully."})

    except LeaveApplication.DoesNotExist:
        return JsonResponse({"error": "Leave application not found or unauthorized."}, status=404)

    except Exception as e:
        return JsonResponse({"error": f"Internal Server Error: {str(e)}"}, status=500)

__all__ = [
    "leave_policy_view",
    "mainleavepage_view",
    "apply_leave_view",
    "get_holidays",
    "leave_application_view",
    "leave_approvals_view",
    "update_leave_status",
    "md_leave_approvals_view",
    "delete_leave_application_view",
    "edit_leave_application_view",
]
