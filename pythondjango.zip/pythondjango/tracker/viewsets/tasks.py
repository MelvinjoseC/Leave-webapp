import json
import traceback
from datetime import date, datetime, timedelta

from django.core.cache import cache
from django.db import transaction
from django.http import JsonResponse
from django.utils.dateparse import parse_date
from django.views.decorators.csrf import csrf_exempt

from ..models import ProjectTacker, TrackerTasks
from .common import get_session_user_data, require_session_user_json

DROPDOWN_CACHE_KEY = "task_dropdown_data_v1"
DROPDOWN_CACHE_TIMEOUT = 120  # seconds


def _invalidate_task_dropdown_cache():
    cache.delete(DROPDOWN_CACHE_KEY)


def _get_task_dropdown_data():
    cached = cache.get(DROPDOWN_CACHE_KEY)
    if cached is not None:
        return cached

    dropdown_data = {
        "list": list(
            TrackerTasks.objects.exclude(list__isnull=True)
            .exclude(list="")
            .values_list("list", flat=True)
            .distinct()
        ),
        "projects": [
            {"list": row[0], "name": row[1]}
            for row in TrackerTasks.objects.exclude(list__isnull=True)
            .exclude(projects__isnull=True)
            .exclude(projects="")
            .values_list("list", "projects")
            .distinct()
        ],
        "scope": [
            {"project": row[0], "name": row[1]}
            for row in TrackerTasks.objects.exclude(projects__isnull=True)
            .exclude(scope__isnull=True)
            .exclude(scope="")
            .values_list("projects", "scope")
            .distinct()
        ],
        "titles": [
            {"scope": row[0], "name": row[1]}
            for row in TrackerTasks.objects.exclude(scope__isnull=True)
            .exclude(title__isnull=True)
            .exclude(title="")
            .values_list("scope", "title")
            .distinct()
        ],
        "category": [
            {"task": row[0], "name": row[1]}
            for row in TrackerTasks.objects.exclude(title__isnull=True)
            .exclude(category__isnull=True)
            .exclude(category="")
            .values_list("title", "category")
            .distinct()
        ],
    }

    cache.set(DROPDOWN_CACHE_KEY, dropdown_data, DROPDOWN_CACHE_TIMEOUT)
    return dropdown_data


def _get_user_context(request):
    user_data = getattr(request, "session_user_data", None)
    if not user_data:
        user_data = get_session_user_data(request)
    username = (user_data.get("name") or "").strip()
    role = (user_data.get("role") or user_data.get("authentication") or "").lower()
    is_privileged = role in ("admin", "md")
    return user_data, username, is_privileged


@csrf_exempt
@require_session_user_json
def create_task(request):
    _, username, is_privileged = _get_user_context(request)
    if not is_privileged:
        return JsonResponse({"error": "Forbidden: Admin access required."}, status=403)

    if request.method == "POST":
        try:
            data = json.loads(request.body.decode("utf-8"))
            excel_tasks = data.get("tasks", [])

            # ---- SAFE DATE PARSER ----
            def safe_parse_date(value):
                if not value:
                    return None

                # Already python date/datetime
                if isinstance(value, datetime):
                    return value.date()
                if isinstance(value, date):
                    return value

                # Excel serial number
                if isinstance(value, (int, float)):
                    # Excel base date: 1899-12-30
                    return (datetime(1899, 12, 30) + timedelta(days=float(value))).date()

                # String date: dd-mm-yyyy or yyyy-mm-dd
                if isinstance(value, str):
                    # Try dd-mm-yyyy format first
                    try:
                        return datetime.strptime(value, "%d-%m-%Y").date()
                    except:
                        pass
                    # Fallback: django parse_date
                    return parse_date(value)

                return None

            # ---- SAVE DATA ----
            for task in excel_tasks:
                TrackerTasks.objects.create(
                    title=task.get("title", ""),
                    projects=task.get("projects", ""),
                    scope=task.get("scope", ""),
                    category=task.get("category", ""),
                    task_benchmark=float(task.get("task_benchmark") or 0),
                    d_no=task.get("d_no", ""),
                    rev=task.get("rev", ""),
                    mail_no=task.get("mail_no", ""),
                    ref_no=task.get("ref_no", ""),
                    start=safe_parse_date(task.get("start")),
                    end=safe_parse_date(task.get("end")),
                    list=task.get("list", ""),
                )

            _invalidate_task_dropdown_cache()
            return JsonResponse({"message": "Tasks created successfully!"}, status=201)

        except Exception as e:
            traceback.print_exc()
            return JsonResponse({"error": str(e)}, status=500)

    return JsonResponse({"error": "Invalid request method."}, status=405)

@csrf_exempt
@require_session_user_json
def edit_task(request):
    user_data, username, is_privileged = _get_user_context(request)
    if request.method == "POST":
        try:
            data = json.loads(request.body.decode("utf-8"))
            task_id = data.get("id")
            if not task_id:
                return JsonResponse({"error": "Task ID is required"}, status=400)

            task = TrackerTasks.objects.get(id=task_id)
            if not is_privileged:
                task_owner = (task.assigned or "").strip().lower()
                if task_owner != username.lower():
                    return JsonResponse({"error": "Forbidden: Task not accessible."}, status=403)

            task.title = data.get("title", "")
            task.projects = data.get("project", "")
            task.scope = data.get("scope", "")
            task.category = data.get("category", "")
            task.start = parse_date(data.get("start_date"))
            task.end = parse_date(data.get("end_date"))
            task.rev = data.get("rev_no", "")
            task.d_no = data.get("d_no", "")
            task.task_benchmark = data.get("task_benchmark", None)

            task.save()
            _invalidate_task_dropdown_cache()
            return JsonResponse({"message": "Task updated successfully!"}, status=200)

        except TrackerTasks.DoesNotExist:
            return JsonResponse({"error": "Task not found"}, status=404)
        except Exception as e:
            return JsonResponse({"error": str(e)}, status=500)

    return JsonResponse({"error": "Invalid request method"}, status=405)


@csrf_exempt
@require_session_user_json
def get_task_by_title_project_scope(request):
    _, username, is_privileged = _get_user_context(request)
    if request.method == "GET":
        title = request.GET.get("title")
        project = request.GET.get("project")
        scope = request.GET.get("scope")

        if not (title and project and scope):
            return JsonResponse({"error": "Missing title, project, or scope"}, status=400)

        try:
            filters = {"title": title, "projects": project, "scope": scope}
            if not is_privileged:
                filters["assigned__iexact"] = username
            task = TrackerTasks.objects.get(**filters)

            return JsonResponse({
                "title": task.title,
                "list": task.list,
                "project": task.projects,
                "scope": task.scope,
                "priority": task.priority,
                "assigned_to": task.assigned,
                "checker": task.checker,
                "qc_3_checker": task.qc3_checker,
                "category": task.category,
                "start_date": task.start.isoformat() if task.start else '',
                "end_date": task.end.isoformat() if task.end else '',
                "verification_status": task.verification_status,
                "task_status": task.task_status,
                "rev_no": task.rev,
                "d_no": task.d_no,
                "task_benchmark": task.task_benchmark
            })

        except TrackerTasks.DoesNotExist:
            return JsonResponse({"error": "Task not found"}, status=404)
        except Exception as e:
            return JsonResponse({"error": str(e)}, status=500)

    return JsonResponse({"error": "Invalid request method"}, status=405)


@require_session_user_json
def get_filter_data(request):
    _, username, is_privileged = _get_user_context(request)
    if request.method != "GET":
        return JsonResponse({"error": "Invalid request method."}, status=405)
    try:
        # Get required date range
        start_date_str = request.GET.get('start_date')
        end_date_str = request.GET.get('end_date')
        if not start_date_str or not end_date_str:
            return JsonResponse({'error': 'Start and end date are required.'}, status=400)

        start_date = datetime.strptime(start_date_str, "%Y-%m-%d").date()
        end_date = datetime.strptime(end_date_str, "%Y-%m-%d").date()

        # Optional cascading filters
        selected_project = request.GET.get('project')
        selected_scope = request.GET.get('scope')
        selected_task = request.GET.get('task')

        # Filter base queryset
        queryset = TrackerTasks.objects.filter(date1__range=(start_date, end_date))
        if not is_privileged:
            queryset = queryset.filter(assigned__iexact=username)

        if selected_project:
            queryset = queryset.filter(projects=selected_project)
        if selected_scope:
            queryset = queryset.filter(scope=selected_scope)
        if selected_task:
            queryset = queryset.filter(title=selected_task)

        # Return distinct dropdown values based on current filter level
        projects = queryset.values_list('projects', flat=True).distinct()
        scopes = queryset.values_list('scope', flat=True).distinct()
        tasks = queryset.values_list('title', flat=True).distinct()
        categories = queryset.values_list('category', flat=True).distinct()

        return JsonResponse({
            'projects': list(projects),
            'scopes': list(scopes),
            'tasks': list(tasks),
            'categories': list(categories)
        })

    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)


@require_session_user_json
def get_task_details_view(request):
    if request.method != "GET":
        return JsonResponse({"error": "Invalid request method."}, status=405)

    _, username, is_privileged = _get_user_context(request)
    task_id = request.GET.get("task_id")

    if not task_id:
        return JsonResponse({"error": "Task ID is required"}, status=400)

    try:
        filters = {"id": task_id}
        if not is_privileged:
            filters["assigned__iexact"] = username

        task = (
            TrackerTasks.objects.filter(**filters)
            .values(
                "id",
                "title",
                "projects",
                "scope",
                "date1",
                "time",
                "comments",
                "list",
                "category",
                "task_status",
                "assigned",
            )
            .first()
        )

        if not task:
            return JsonResponse({"error": "Task not found"}, status=404)

        task.pop("assigned", None)
        dropdown_data = _get_task_dropdown_data()

        return JsonResponse({"task": task, "dropdowns": dropdown_data}, status=200)

    except Exception as e:
        return JsonResponse({"error": str(e)}, status=500)


@csrf_exempt
@require_session_user_json
def update_timesheet(request):
    _, username, is_privileged = _get_user_context(request)
    if request.method != "POST":
        return JsonResponse({"error": "Invalid request method. Use POST."}, status=405)

    try:
        data = json.loads(request.body.decode("utf-8"))

        task_id = data.get("task_id")
        list_value = data.get("list", "").strip()
        projects = data.get("projects", "").strip()
        scope = data.get("scope", "").strip()
        title = data.get("title", "").strip()
        category = data.get("category", "").strip()
        task_status = data.get("task_status", "").strip()
        date1 = data.get("date1", "").strip()
        comments = data.get("comments", "").strip()

        try:
            time = float(data.get("time", 0))
        except ValueError:
            return JsonResponse({"error": "Invalid value for 'time'. It must be a number."}, status=400)

        if not task_id:
            return JsonResponse({"error": "task_id parameter is required"}, status=400)

        # ✅ Retrieve the task being updated
        try:
            task = TrackerTasks.objects.get(id=task_id)
        except TrackerTasks.DoesNotExist:
            return JsonResponse({"error": "Task not found"}, status=404)

        if not is_privileged:
            task_owner = (task.assigned or "").strip().lower()
            if task_owner != username.lower():
                return JsonResponse({"error": "Forbidden: Task not accessible."}, status=403)

        # ✅ Search for an existing task to fetch team and benchmark
        reference_queryset = TrackerTasks.objects.filter(
            list=list_value,
            projects=projects,
            scope=scope,
            title=title,
            category=category
        ).exclude(id=task_id)
        if not is_privileged:
            reference_queryset = reference_queryset.filter(assigned__iexact=username)
        reference_task = reference_queryset.order_by('-id').first()

        # Fallbacks if no matching task found
        team_value = reference_task.team if reference_task else ""
        benchmark_value = reference_task.task_benchmark if reference_task else 0

        # ✅ Update fields
        task.list = list_value
        task.projects = projects
        task.scope = scope
        task.title = title
        task.category = category
        task.task_status = task_status
        task.date1 = date1 if date1 else None
        task.time = time
        task.comments = comments
        task.team = team_value
        task.task_benchmark = benchmark_value

        with transaction.atomic():
            task.save()

        _invalidate_task_dropdown_cache()
        return JsonResponse({"message": "Timesheet updated successfully."}, status=200)

    except json.JSONDecodeError:
        return JsonResponse({"error": "Invalid JSON format"}, status=400)
    except Exception as e:
        print("Error:", str(e))
        return JsonResponse({"error": str(e)}, status=500)


@require_session_user_json
def delete_task(request):
    _, username, is_privileged = _get_user_context(request)
    if request.method != "GET":
        return JsonResponse({'error': 'Invalid request method.'}, status=405)
    task_id = request.GET.get('task_id')

    if not task_id:
        return JsonResponse({'error': 'task_id parameter is required'}, status=400)

    try:
        task_id = int(task_id)
    except (TypeError, ValueError):
        return JsonResponse({'error': 'task_id must be a valid integer.'}, status=400)

    try:
        queryset = TrackerTasks.objects.filter(id=task_id)
        if not is_privileged:
            queryset = queryset.filter(assigned__iexact=username)

        deleted_count, _ = queryset.delete()
        if deleted_count == 0:
            return JsonResponse({'error': 'Task not found.'}, status=404)

        _invalidate_task_dropdown_cache()
        return JsonResponse({'message': 'Task deleted successfully'}, status=200)

    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)


@csrf_exempt
@require_session_user_json
def task_action(request):
    _, username, is_privileged = _get_user_context(request)
    if not is_privileged:
        return JsonResponse({"success": False, "message": "Forbidden: Admin access required."}, status=403)

    if request.method != "POST":
        return JsonResponse({"success": False, "message": "Invalid request method."}, status=405)

    try:
        data = json.loads(request.body)
        task_data = data.get("task_data")
        action = data.get("action")

        if not task_data or "name" not in task_data or "d_no" not in task_data:
            return JsonResponse({"success": False, "message": "Task data or identifiers missing."}, status=400)

        project_tracker = ProjectTacker.objects.filter(name=task_data.get("name")).first()
        if not project_tracker:
            return JsonResponse({"success": False, "message": "Project task not found."}, status=404)

        to_approve_data = project_tracker.to_aproove
        if not to_approve_data:
            return JsonResponse({"success": False, "message": "No tasks to approve."}, status=404)

        task = None
        for t in to_approve_data if isinstance(to_approve_data, list) else [to_approve_data]:
            if t.get("d_no") == task_data.get("d_no"):
                task = t
                break

        if not task:
            return JsonResponse({"success": False, "message": "Task not found in project data."}, status=404)

        if action not in ("accept", "reject"):
            return JsonResponse({"success": False, "message": "Invalid action specified."}, status=400)

        project_tracker.status = "Approved" if action == "accept" else "Rejected"
        project_tracker.save()

        if action == "accept":
            tracker_task, created = TrackerTasks.objects.get_or_create(d_no=task.get("d_no"))

            tracker_task.title = task.get("task_title") or task.get("title")
            tracker_task.d_no = task.get("d_no")
            tracker_task.scope = task.get("scope")
            tracker_task.rev = task.get("rev_no")
            tracker_task.checker = task.get("checker")
            tracker_task.projects = task.get("project")
            tracker_task.category = task.get("category")
            tracker_task.end = task.get("end_date")
            tracker_task.priority = task.get("priority")
            tracker_task.start = task.get("start_date")
            tracker_task.assigned = task.get("assigned_to")
            tracker_task.task_status = task.get("task_status") or "Accepted"
            tracker_task.qc3_checker = task.get("qc_3_checker")
            tracker_task.verification_status = task.get("verification_status", True)
            tracker_task.project_status = "Accepted"

            tracker_task.save()
            _invalidate_task_dropdown_cache()

        return JsonResponse({"success": True, "message": f"Task has been {action}ed."})

    except json.JSONDecodeError:
        return JsonResponse({"success": False, "message": "Invalid JSON format."}, status=400)
    except Exception as e:
        return JsonResponse({"success": False, "message": f"Error: {str(e)}"}, status=500)


@csrf_exempt
def check_task_status(request):

    if request.method == "POST":
        try:
            user_data = get_session_user_data(request)
            # Fetch all records where sender_name matches user_data['name']
            if not user_data:
                return JsonResponse(
                    {"status": None, "message": "User not authenticated"}, status=401
                )

            sender_name = user_data.get("name")

            projects = ProjectTacker.objects.filter(sender_name__icontains=sender_name)

            if not projects.exists():
                return JsonResponse(
                    {"status": None, "message": "No projects found for sender"},
                    status=404,
                )

            approved_rejected_projects = []

            for project in projects:
                # Convert to_aproove JSONField to a Python dictionary
                to_aprove_data = (
                    json.loads(project.to_aproove)
                    if isinstance(project.to_aproove, str)
                    else project.to_aproove
                )

                if project.status in ["Accepted", "Rejected", "Pending"]:
                    approved_rejected_projects.append(
                        {
                            "status": project.status,
                            "project": to_aprove_data.get("project", "Unknown Project"),
                        }
                    )

            return JsonResponse({"projects": approved_rejected_projects})

        except json.JSONDecodeError:
            return JsonResponse(
                {"status": None, "message": "Invalid JSON format"}, status=400
            )
        except Exception as e:
            return JsonResponse(
                {"status": None, "message": f"Internal server error: {str(e)}"},
                status=500,
            )

    return JsonResponse(
        {"status": None, "message": "Invalid request method"}, status=405
    )

__all__ = [
    "create_task",
    "edit_task",
    "get_task_by_title_project_scope",
    "get_filter_data",
    "get_task_details_view",
    "update_timesheet",
    "delete_task",
    "task_action",
    "check_task_status",
]
