from . import attendance as _attendance
from . import auth as _auth
from . import comp_off as _comp_off
from . import dashboard as _dashboard
from . import leave as _leave
from . import notifications as _notifications
from . import projects as _projects
from . import reports as _reports
from . import tasks as _tasks
from . import team as _team
from . import timesheet as _timesheet
from . import user_info as _user_info
from .common import get_session_user_data


def _export(module):
    names = getattr(module, "__all__", [])
    for name in names:
        globals()[name] = getattr(module, name)
    return list(names)


__all__ = []
for _module in (
    _auth,
    _reports,
    _dashboard,
    _tasks,
    _timesheet,
    _attendance,
    _leave,
    _comp_off,
    _projects,
    _team,
    _notifications,
    _user_info,
):
    __all__.extend(_export(_module))

__all__.append("get_session_user_data")
