import base64
import json
from datetime import date, datetime, timedelta

from django.core.exceptions import ObjectDoesNotExist
from django.db import connection
from django.db.models import Count, F, FloatField, Q, Sum, Value, When
from django.db.models.functions import Cast
from django.db.models.functions import Coalesce
from django.http import JsonResponse
from django.shortcuts import redirect, render
from django.utils.dateparse import parse_date
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_GET

from ..models import (
    Attendance,
    EmployeeDetails,
    Holiday,
    LeaveApplication,
    TrackerTasks,
)
from .common import get_session_user_data, require_session_user_json


def _week_bounds(target_date):
    start = target_date - timedelta(days=target_date.weekday())
    return start, start + timedelta(days=6)


def _summarize_leaves(username, week_start, week_end):
    leaves = LeaveApplication.objects.filter(
        username=username,
        status="Approved",
        start_date__lte=week_end,
        end_date__gte=week_start,
    )

    total_leave_days = 0
    half_day_leaves = 0
    for leave in leaves:
        overlap_start = max(leave.start_date, week_start)
        overlap_end = min(leave.end_date, week_end)
        days = (overlap_end - overlap_start).days + 1
        if "half" in (leave.leave_type or "").lower():
            half_day_leaves += 1
        else:
            total_leave_days += days

    return total_leave_days, half_day_leaves


def _parse_attendance_payload(date_str, punch_in_str, punch_out_str, break_time_str):
    try:
        attendance_date = datetime.strptime(date_str, "%Y-%m-%d").date()
        punch_in = datetime.strptime(punch_in_str, "%H:%M:%S").time()
        punch_out = datetime.strptime(punch_out_str, "%H:%M:%S").time()
        break_seconds = int(break_time_str)
    except ValueError as exc:
        raise ValueError("Invalid date or time format") from exc

    return attendance_date, punch_in, punch_out, break_seconds


def _calculate_work_hours(attendance_date, punch_in, punch_out, break_seconds):
    dt_punch_in = datetime.combine(attendance_date, punch_in)
    dt_punch_out = datetime.combine(attendance_date, punch_out)
    if dt_punch_out < dt_punch_in:
        dt_punch_out += timedelta(days=1)

    work_duration = dt_punch_out - dt_punch_in - timedelta(seconds=break_seconds)
    return max(0.0, work_duration.total_seconds() / 3600.0)


@csrf_exempt
def attendance_from_tasks(request):
    """
    ✅ Calculate attendance and compensation purely from TrackerTasks table.
    - No Attendance model usage.
    - Computes total daily and weekly hours.
    - Handles weekend/holiday and comp leave logic dynamically.
    """

    if request.method != "POST":
        return JsonResponse({"error": "Invalid request method"}, status=405)

    try:
        user_data = get_session_user_data(request)
        if not user_data:
            return JsonResponse({"error": "User not logged in."}, status=401)

        username = user_data.get("name")
        user_id = user_data.get("employee_id")

        if not user_id or not username:
            return JsonResponse({"error": "Invalid user details."}, status=403)

        # ✅ Parse the requested date
        attendance_date_str = request.POST.get("date", "").strip()
        if not attendance_date_str:
            return JsonResponse({"error": "Missing date."}, status=400)

        try:
            attendance_date = datetime.strptime(attendance_date_str, "%Y-%m-%d").date()
        except ValueError:
            return JsonResponse({"error": "Invalid date format (expected YYYY-MM-DD)."}, status=400)

        # ✅ Step 1: Get total time for the given date
        total_time = (
            TrackerTasks.objects.filter(assigned=username, date1=attendance_date)
            .aggregate(total=Sum("time"))["total"] or 0
        )

        print(f"🕓 Total worktime from TrackerTasks for {username} on {attendance_date}: {total_time} hrs")

        # ✅ Step 2: Identify weekend or holiday
        is_weekend = attendance_date.weekday() in [5, 6]  # 5=Saturday, 6=Sunday
        is_holiday = Holiday.objects.filter(date=attendance_date).exists()
        is_weekend_or_holiday = is_weekend or is_holiday

        # ✅ Step 3: Base compensation for this day
        is_compensated = 0.0
        if is_weekend_or_holiday:
            if total_time >= 8:
                is_compensated = 1.0
            elif 4 <= total_time < 8:
                is_compensated = 0.5
            else:
                is_compensated = 0.0

        # ======================================================
        # 🧮 Weekly Compensation Evaluation (based on TrackerTasks)
        # ======================================================

        week_start, week_end = _week_bounds(attendance_date)

        # ✅ Weekly total hours directly from TrackerTasks
        weekly_hours = (
            TrackerTasks.objects.filter(
                assigned=username,
                date1__range=[week_start, week_end]
            ).aggregate(total_time=Sum("time"))["total_time"] or 0
        )

        print(f"🧾 Weekly total time from TrackerTasks for {username}: {weekly_hours} hrs")

        # ✅ Step 4: Adjust for leaves
        total_leave_days, half_day_leaves = _summarize_leaves(username, week_start, week_end)

        adjusted_required = 45 - (total_leave_days * 9) - (half_day_leaves * 4.5)

        print(f"🧮 Weekly Summary: total={weekly_hours}, required={adjusted_required}, "
              f"full_leaves={total_leave_days}, half_leaves={half_day_leaves}")

        # ✅ Step 5: Final compensation check
        final_comp = is_compensated
        if is_weekend_or_holiday:
            if weekly_hours >= adjusted_required + 8:
                final_comp = 1.0
            elif weekly_hours >= adjusted_required + 4:
                final_comp = 0.5
            else:
                final_comp = 0.0

        print(f"✅ Final Compensation (TrackerTasks Only): {final_comp}")

        # ✅ Step 6: Return JSON response
        return JsonResponse({
            "message": "TrackerTasks-based compensation calculated successfully!",
            "username": username,
            "date": attendance_date.strftime("%Y-%m-%d"),
            "total_time": round(total_time, 2),
            "weekly_hours": round(weekly_hours, 2),
            "adjusted_required": adjusted_required,
            "is_weekend": is_weekend,
            "is_holiday": is_holiday,
            "is_compensated": final_comp,
            "leaves": {
                "full_days": total_leave_days,
                "half_days": half_day_leaves
            }
        })

    except Exception as e:
        print("📢 Django Error:", str(e))
        return JsonResponse({"error": f"Something went wrong: {str(e)}"}, status=500)


def attendance_calendar(request):
    user_data = get_session_user_data(request)
    
    # ✅ Ensure user is logged in
    if not user_data:
        return redirect("login_page")

    # ✅ Fetch user details from session
    user_id = user_data.get("employee_id")
    name = user_data.get("name", "Guest")
    designation = user_data.get("designation")
    image_base64 = None

    profile = None
    if user_id:
        profile = (
            EmployeeDetails.objects.only("designation", "image", "authentication")
            .filter(employee_id=user_id)
            .first()
        )
        if profile:
            designation = designation or (profile.designation or "No Designation")
            image_data = getattr(profile, "image", None)
            if image_data:
                image_base64 = base64.b64encode(bytes(image_data)).decode("utf-8")

    role = user_data.get("role") or user_data.get("authentication")
    auth_source = role or (profile.authentication if profile else "")
    is_admin_or_md = str(auth_source or "").strip().lower() in ["admin", "md"]

    # ✅ Only allow GET requests
    if request.method != "GET":
        return JsonResponse({"status": "error", "message": "Invalid request method"}, status=405)

    # ✅ Render template
    return render(request, "calendar.html", {
        "name": name,
        "designation": designation or "No Designation",
        "image_base64": image_base64,
        "employee_id": user_id,
        "is_admin_or_md": is_admin_or_md,
    })


@require_session_user_json
def attendance_view(request):

    if request.method != "POST":
        return JsonResponse({"error": "Invalid request method"}, status=405)

    try:
        user_data = request.session_user_data
        current_user_name = user_data.get("name")
        current_user_id = user_data.get("employee_id")

        if not current_user_id:
            return JsonResponse({"error": "User ID is missing."}, status=403)

        payload = {
            "date": request.POST.get("date", "").strip(),
            "punch_in": request.POST.get("punch_in", "").strip(),
            "punch_out": request.POST.get("punch_out", "").strip(),
            "break_time": request.POST.get("break_time", "").strip(),
        }

        missing = [field for field, value in payload.items() if not value]
        if missing:
            return JsonResponse({"error": f"Missing fields: {', '.join(missing)}"}, status=400)

        try:
            attendance_date, punch_in, punch_out, break_seconds = _parse_attendance_payload(
                payload["date"], payload["punch_in"], payload["punch_out"], payload["break_time"]
            )
        except ValueError:
            return JsonResponse({"error": "Invalid date or time format"}, status=400)

        work_hours = _calculate_work_hours(attendance_date, punch_in, punch_out, break_seconds)

        Attendance.objects.create(
            date=attendance_date,
            punch_in=punch_in,
            punch_out=punch_out,
            break_time=break_seconds,
            worktime=work_hours,
            user_id=current_user_id,
            username=current_user_name,
        )

        week_start, week_end = _week_bounds(attendance_date)
        weekly_hours = (
            Attendance.objects.filter(
                user_id=current_user_id,
                date__range=[week_start, week_end]
            ).aggregate(total_hours=Sum("worktime"))["total_hours"] or 0
        )
        total_leave_days, half_day_leaves = _summarize_leaves(current_user_name, week_start, week_end)
        adjusted_required = 45 - (total_leave_days * 9) - (half_day_leaves * 4.5)

        return JsonResponse({
            "message": "Attendance added successfully!",
            "username": current_user_name,
            "work_hours": round(work_hours, 2),
            "weekly_hours": round(weekly_hours, 2),
            "adjusted_required": adjusted_required,
        })

    except Exception as e:
        print("📢 Django Error:", str(e))
        return JsonResponse({"error": f"Something went wrong: {str(e)}"}, status=500)


@require_session_user_json
def get_attendance(request):

    user_id = request.session_user_data.get("employee_id")

    date_param = request.GET.get("date", "").strip()
    year = request.GET.get("year", "").strip()
    month = request.GET.get("month", "").strip()

    if year and month:
        try:
            year_int = int(year)
            month_int = int(month)
        except ValueError:
            return JsonResponse({}, status=200)

        first_day = datetime(year_int, month_int, 1).date()
        last_day = (first_day.replace(day=28) + timedelta(days=4)).replace(day=1) - timedelta(days=1)

        attendance_records = (
            Attendance.objects.filter(user_id=user_id, date__range=[first_day, last_day])
            .order_by("date")
        )
        attendance_data = [
            {
                "date": record.date.strftime("%Y-%m-%d"),
                "punch_in": str(record.punch_in),
                "punch_out": str(record.punch_out),
                "break_time": int(record.break_time),
                "worktime": float(record.worktime) if record.worktime is not None else 0.0,
            }
            for record in attendance_records
        ]
        return JsonResponse({"attendance": attendance_data}, status=200)

    if date_param:
        try:
            date_obj = datetime.strptime(date_param, "%Y-%m-%d").date()
        except ValueError:
            return JsonResponse({}, status=200)

        attendance_record = Attendance.objects.filter(user_id=user_id, date=date_obj).first()
        if attendance_record:
            return JsonResponse({
                "date": attendance_record.date.strftime("%Y-%m-%d"),
                "punch_in": str(attendance_record.punch_in),
                "punch_out": str(attendance_record.punch_out),
                "break_time": int(attendance_record.break_time),
                "worktime": float(attendance_record.worktime) if attendance_record.worktime is not None else 0.0,
            }, status=200)

    return JsonResponse({}, status=200)


@require_session_user_json
def edit_attendance_view(request):

    if request.method != "POST":
        return JsonResponse({"error": "Invalid request method"}, status=405)

    try:
        user_id = request.session_user_data.get("employee_id")
        payload = {
            "date": request.POST.get("date", "").strip(),
            "punch_in": request.POST.get("punch_in", "").strip(),
            "punch_out": request.POST.get("punch_out", "").strip(),
            "break_time": request.POST.get("break_time", "").strip(),
            "is_compensated": request.POST.get("is_compensated", "0").strip(),
        }

        missing = [field for field in ("punch_in", "punch_out", "break_time") if not payload[field]]
        if missing:
            return JsonResponse({"error": f"Missing fields: {', '.join(missing)}"}, status=400)

        try:
            attendance_date, punch_in, punch_out, break_seconds = _parse_attendance_payload(
                payload["date"], payload["punch_in"], payload["punch_out"], payload["break_time"]
            )
            is_compensated = bool(int(payload["is_compensated"]))
        except ValueError:
            return JsonResponse({"error": "Invalid date/time format!"}, status=400)

        work_hours = _calculate_work_hours(attendance_date, punch_in, punch_out, break_seconds)
        attendance = Attendance.objects.filter(user_id=user_id, date=attendance_date).first()

        if not attendance:
            return JsonResponse({"error": "Attendance record not found."}, status=404)

        attendance.punch_in = punch_in
        attendance.punch_out = punch_out
        attendance.break_time = break_seconds
        attendance.worktime = work_hours
        attendance.is_compensated = is_compensated
        attendance.save()

        return JsonResponse({"message": "✅ Attendance updated successfully!", "work_hours": work_hours}, status=200)

    except Exception:
        return JsonResponse({"error": "⚠️ Failed to update attendance. Please try again."}, status=500)


@csrf_exempt
@require_session_user_json
def delete_attendance_view(request):

    if request.method != "POST":
        return JsonResponse({"error": "Invalid request method."}, status=405)

    try:
        user_id = request.session_user_data.get("employee_id")
        attendance_date = request.POST.get("date", "").strip()

        if not attendance_date:
            return JsonResponse({"error": "Date is required."}, status=400)

        try:
            parsed_date = datetime.strptime(attendance_date, "%Y-%m-%d").date()
        except ValueError:
            return JsonResponse({"error": "Invalid date format."}, status=400)

        deleted_count, _ = Attendance.objects.filter(user_id=user_id, date=parsed_date).delete()
        if deleted_count == 0:
            return JsonResponse({"error": "Attendance record not found."}, status=404)

        return JsonResponse({"message": "Attendance deleted successfully."}, status=200)

    except Exception as e:
        return JsonResponse({"error": f"⚠️ Failed to delete attendance. Error: {str(e)}"}, status=500)


def get_monthly_weekly_attendance(request):
    user_data = get_session_user_data(request)
    if not user_data:
        return JsonResponse({"error": "User not logged in."}, status=401)

    user = user_data.get("name")

    # -------------------------------------------------
    # ✅ Detect selected month (from ?month=YYYY-MM)
    # -------------------------------------------------
    month_param = request.GET.get("month")
    if month_param:
        try:
            selected_year, selected_month = map(int, month_param.split("-"))
            today = datetime(selected_year, selected_month, 1)
        except ValueError:
            return JsonResponse({"error": "Invalid month format. Use YYYY-MM."}, status=400)
    else:
        today = datetime.today()

    # -------------------------------------------------
    # ✅ Current week range (Monday → Sunday)
    # -------------------------------------------------
    current_date = datetime.today()
    week_start = current_date - timedelta(days=current_date.weekday())  # Monday
    week_end = week_start + timedelta(days=6)                           # Sunday

    # -------------------------------------------------
    # ✅ Current month range
    # -------------------------------------------------
    first_day_of_month = today.replace(day=1)
    last_day_of_month = (first_day_of_month.replace(day=28) + timedelta(days=4)).replace(day=1) - timedelta(days=1)

    # -------------------------------------------------
    # ✅ Working days count (Mon–Fri)
    # -------------------------------------------------
    total_working_days_month = sum(
        1 for i in range(1, last_day_of_month.day + 1)
        if (first_day_of_month + timedelta(days=i - 1)).weekday() < 5
    )

    total_working_days_week = sum(
        1 for i in range(7)
        if (week_start + timedelta(days=i)).weekday() < 5
    )

    # -------------------------------------------------
    # ✅ Holidays (excluding weekends)
    # -------------------------------------------------
    holiday_count_month = Holiday.objects.filter(
        date__range=[first_day_of_month, last_day_of_month]
    ).exclude(date__week_day__in=[6, 7]).count()

    holiday_count_week = Holiday.objects.filter(
        date__range=[week_start, week_end]
    ).exclude(date__week_day__in=[6, 7]).count()

    # -------------------------------------------------
    # ✅ MD-approved leaves (excluding Work From Home)
    # -------------------------------------------------
    leave_applications_week = LeaveApplication.objects.filter(
        username=user,
        start_date=week_start,
        end_date=week_end,
        md_status="Approved"
    ).exclude(leave_type="Work From Home")

    leave_applications_month = LeaveApplication.objects.filter(
        username=user,
        start_date=first_day_of_month,
        end_date=last_day_of_month,
        md_status="Approved"
    ).exclude(leave_type="Work From Home")

    # -------------------------------------------------
    # ✅ Helper — Calculate total leave days
    # -------------------------------------------------
    def calculate_leave_days(leaves):
        total = 0.0
        for leave in leaves:
            current = leave.start_date
            while current <= leave.end_date:
                if current.weekday() < 5:  # Mon–Fri only
                    if leave.leave_type.strip().lower() == "Full Day":
                        total += 1
                    elif leave.leave_type.strip().lower() == "Half Day":
                        total += 0.5
                current += timedelta(days=1)
        return total



    leave_taken_week = calculate_leave_days(leave_applications_week)
    leave_taken_month = calculate_leave_days(leave_applications_month)

    # -------------------------------------------------
    # ✅ Expected Monthly Hours = (Working days - Holidays - Leaves) × 9
    # -------------------------------------------------
    expected_monthly_working_days = total_working_days_month - holiday_count_month - leave_taken_month
    expected_monthly_hours = max(expected_monthly_working_days * 9, 0.0)

    # -------------------------------------------------
    # ✅ Expected Weekly Hours = (Weekdays - Holidays - Leaves) × 9
    # -------------------------------------------------
    expected_weekly_working_days = total_working_days_week - holiday_count_week - leave_taken_week
    expected_weekly_hours = max(expected_weekly_working_days * 9, 0.0)

    # -------------------------------------------------
    # ✅ Total Monthly Worked Hours (Attendance)
    # -------------------------------------------------
    total_monthly_hours = Attendance.objects.filter(
        username=user,
        date__range=[first_day_of_month, last_day_of_month]
    ).aggregate(total_worktime=Sum("worktime"))["total_worktime"]

    total_monthly_hours = float(total_monthly_hours or 0.0)

    # -------------------------------------------------
    # ✅ Total Weekly Worked Hours (Current Week only)
    # -------------------------------------------------
    total_weekly_hours = Attendance.objects.filter(
        username=user,
        date__range=[week_start, week_end]
    ).aggregate(total_worktime=Sum("worktime"))["total_worktime"]

    total_weekly_hours = float(total_weekly_hours or 0.0)

    # -------------------------------------------------
    # ✅ Deduct lost time for holidays and leaves (9 hrs each)
    # -------------------------------------------------
    lost_time = float((holiday_count_week + leave_taken_week) * 9)
    total_weekly_hours = max(total_weekly_hours - lost_time, 0.0)

    # -------------------------------------------------
    # ✅ Hide weekly data when viewing another month
    # -------------------------------------------------
    current_month_str = datetime.today().strftime("%Y-%m")
    show_weekly = (not month_param or month_param == current_month_str)

    if not show_weekly:
        total_weekly_hours = 0.0
        expected_weekly_hours = 0.0

    # -------------------------------------------------
    # ✅ Final JSON Response
    # -------------------------------------------------
    return JsonResponse({
        "selected_month": first_day_of_month.strftime("%Y-%m"),
        "total_monthly_hours": round(total_monthly_hours, 2),
        "total_weekly_hours": round(total_weekly_hours, 2),
        "expected_monthly_hours": round(expected_monthly_hours, 2),
        "expected_weekly_hours": round(expected_weekly_hours, 2),
        "show_weekly": show_weekly
    })


def monthly_attendance_view(request):
    # Get the current month and year
    current_month = datetime.now().month
    current_year = datetime.now().year

    # Fetch the attendance data for the current month and year using Django ORM
    attendance_data = (
        EmployeeDetails.objects
        .filter(
            attendance__date__month=current_month,
            attendance__date__year=current_year
        )
        .annotate(
            total_worktime=Sum('attendance__worktime')  # Calculate the total worktime per employee
        )
        .values('name', 'total_worktime', 'attendance__date', 'attendance__worktime')
        .order_by('name', 'attendance__date')
    )

    # Format the data to match the previous structure
    attendance_data_list = [
        {
            'name': data['name'],
            'total_worktime': data['total_worktime'],
            'date': data['attendance__date'],
            'daily_worktime': data['attendance__worktime']
        }
        for data in attendance_data
    ]

    return render(request, "project_tracker.html", {'attendance_data': attendance_data_list})


def get_employee_names(request):
    # Fetch employee names and ids from EmployeeDetails using Django ORM
    employees = EmployeeDetails.objects.all().order_by('name').values('employee_id', 'name')

    # Prepare the data to be returned in JSON format
    employee_data = [{'id': employee['employee_id'], 'name': employee['name']} for employee in employees]

    return JsonResponse({'employees': employee_data})


def get_user_tasktime(request):
    username = request.GET.get("username")
    month = request.GET.get("month")
    year = request.GET.get("year")

    if not username:
        return JsonResponse({"error": "Missing username"}, status=400)

    try:
        if month and year:
            month = int(month)
            year = int(year)
            start_date = date(year, month, 1)
            end_date = (start_date + timedelta(days=32)).replace(day=1) - timedelta(days=1)
        else:
            today = date.today()
            start_date = today.replace(day=1)
            end_date = (start_date + timedelta(days=32)).replace(day=1) - timedelta(days=1)

        task_data = (
            TrackerTasks.objects
            .filter(assigned__icontains=username, date1__range=(start_date, end_date))
            .values("date1")
            .annotate(daily_worktime_hours=Sum("time"))
            .order_by("date1")
        )

        result = [
            {"date": t["date1"], "daily_worktime_hours": round(float(t["daily_worktime_hours"] or 0), 2)}
            for t in task_data
        ]

        return JsonResponse({"tasktime": result}, status=200)

    except Exception as e:
        import traceback
        traceback.print_exc()
        return JsonResponse({"error": str(e)}, status=500)


@require_GET
def get_attendance_task_details(request):
    """
    Behavior:
    - If username only: returns that user’s monthly summary for selected month/year.
    - If username + date: returns that user’s task details for that specific date.
    - Optional params: month (1-12), year (e.g., 2025)
    """
    username = request.GET.get("username")
    date_str = request.GET.get("date")
    month = request.GET.get("month")
    year = request.GET.get("year")

    HOURS_PER_DAY = 9

    try:
        # --- CASE 1: Username + Date → Daily tasks ---
        if username and date_str:
            target_date = parse_date(date_str)
            if not target_date:
                return JsonResponse({"error": "Invalid date format. Use YYYY-MM-DD"}, status=400)

            tasks = (
                TrackerTasks.objects
                .filter(assigned__icontains=username, date1=target_date)
                .values("projects", "scope", "category", "title", "time", "comments")
            )

            task_list = [
                {
                    "project": t.get("projects") or "—",
                    "scope": t.get("scope") or "—",
                    "category": t.get("category") or "—",
                    "title": t.get("title") or "—",
                    "hours_spent": round(float(t.get("time") or 0), 2),
                    "comments": t.get("comments") or "",
                }
                for t in tasks
            ]

            return JsonResponse({"tasks": task_list}, status=200)

        # --- CASE 2: Username only → Monthly summary ---
        elif username:
            # Determine which month/year to show
            if month and year:
                month = int(month)
                year = int(year)
                start_month = date(year, month, 1)
            else:
                # fallback to current month if not provided
                today = date.today()
                start_month = today.replace(day=1)
            # end of month
            end_month = (start_month + timedelta(days=32)).replace(day=1) - timedelta(days=1)

            # Total task hours for that user in that month
            total_task_hours = (
                TrackerTasks.objects
                .filter(assigned__icontains=username, date1__range=(start_month, end_month))
                .aggregate(total=Coalesce(Sum(Cast("time", FloatField())), 0.0))
                .get("total") or 0.0
            )

            # Approved leave days
            leaves = LeaveApplication.objects.filter(
                username=username,
                start_date__lte=end_month,
                end_date__gte=start_month,
                status__iexact="Approved"
            )
            total_leave_days = sum(
                (min(l.end_date, end_month) - max(l.start_date, start_month)).days + 1
                for l in leaves
            )
            total_leave_hours = total_leave_days * HOURS_PER_DAY

            # Expected monthly working hours
            total_days = (end_month - start_month).days + 1
            weekdays = sum(
                1 for d in range(total_days)
                if (start_month + timedelta(days=d)).weekday() < 5
            )
            expected_hours = weekdays * HOURS_PER_DAY

            net_difference = float(total_task_hours) - (expected_hours - total_leave_hours)

            monthly_summary = {
                "username": username,
                "month": start_month.strftime("%B %Y"),
                "total_task_hours": round(float(total_task_hours), 2),
                "expected_hours": expected_hours,
                "total_leave_hours": total_leave_hours,
                "net_difference": round(float(net_difference), 2),
            }

            return JsonResponse({"monthly_summary": monthly_summary}, status=200)

        else:
            return JsonResponse({"error": "Please select a user first."}, status=400)

    except Exception as e:
        import traceback
        traceback.print_exc()
        return JsonResponse({"error": f"Server error: {str(e)}"}, status=500)


def monthly_project_analysis(request):
    project_name = request.GET.get('project_name', None)

    # Start the queryset to fetch data from TrackerTasks model
    project_query = TrackerTasks.objects.all()

    # Apply filtering if project_name is provided
    if project_name:
        project_query = project_query.filter(projects=project_name)

    # Fetch the relevant fields including task_benchmark
    project_data = project_query.values('projects', 'category', 'date1', 'time', 'task_benchmark', 'title').order_by('projects', 'date1')

    # Convert the queryset to a list of dictionaries
    project_data_list = [
        {
            'projects': item['projects'],
            'category': item['category'],
            'date1': item['date1'],
            'time': item['time'],
            'task_benchmark': item['task_benchmark'],
            'title':item['title'],
        }
        for item in project_data
    ]

    return JsonResponse({'projects': project_data_list})


def get_project_categories(request):
    project_name = request.GET.get('project_name', None)

    if not project_name:
        return JsonResponse({'error': 'No project name provided'}, status=400)

    try:
        # Use Django ORM to get the distinct categories for the given project name
        categories = (
            TrackerTasks.objects
            .filter(projects=project_name)  # Filter by project name
            .values('category')  # Select the category field
            .distinct()  # Get distinct categories
        )

        # Extract the category names from the queryset
        category_list = [category['category'] for category in categories]

        # Return the categories in a JsonResponse
        return JsonResponse({'categories': category_list})

    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)


def get_week_date_range(week_offset):
    """
    Helper function to get the date range for the given week offset.
    week_offset: 0 for CW (current week), -1 for W6 (previous week), etc.
    """
    today = datetime.today()
    start_of_week = today - timedelta(days=today.weekday())  # Monday of the current week

    # Calculate the start and end of the target week
    week_start = start_of_week + timedelta(weeks=week_offset)
    week_end = week_start + timedelta(days=6)

    return week_start.date(), week_end.date()


def get_task_details_for_sidebar(request):
    selected_date = request.GET.get('date')

    if not selected_date:
        return JsonResponse({'error': 'date is required'}, status=400)

    try:
        selected_date = datetime.strptime(selected_date, '%Y-%m-%d').date()

        # Query tasks by date
        tasks = TrackerTasks.objects.filter(date1=selected_date)

        if not tasks.exists():  # ✅ Use exists() instead of evaluating queryset
            return JsonResponse({'tasks': []})  # ✅ Return empty list, not error

        # Prepare task data
        task_data = [{
            'title': task.title,
            'projects': task.projects,
            'scope': task.scope,
            'category': task.category,
            'time': task.time,
            'comments': task.comments,
            'task_benchmark': task.task_benchmark,
            'assigned': task.assigned
        } for task in tasks]

        return JsonResponse({'tasks': task_data})

    except ValueError:
        return JsonResponse({'error': 'Invalid date format, expected YYYY-MM-DD'}, status=400)
    except Exception as e:
        return JsonResponse({'error': f'An error occurred: {str(e)}'}, status=500)

__all__ = [
    "attendance_from_tasks",
    "attendance_calendar",
    "attendance_view",
    "get_attendance",
    "edit_attendance_view",
    "delete_attendance_view",
    "get_monthly_weekly_attendance",
    "monthly_attendance_view",
    "get_employee_names",
    "get_user_tasktime",
    "get_attendance_task_details",
    "monthly_project_analysis",
    "get_project_categories",
    "get_week_date_range",
    "get_task_details_for_sidebar",
]
