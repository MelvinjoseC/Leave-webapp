import json

from django.conf import settings
from django.core.mail import send_mail
from django.http import JsonResponse
from django.shortcuts import render


def notifications_view(request):
    return render(request, "notifications.html")


def send_notification(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body)
            message = data.get('message', '')
            recipient = data.get('recipient', '')
            print(recipient)  
            if not message or not recipient:
                return JsonResponse({"error": "Invalid data"}, status=400)

            send_mail(
                subject="Task Benchmark Missing",  # Email subject
                message=message,                   # The message body
                from_email=settings.DEFAULT_FROM_EMAIL,  # From address
                recipient_list=[recipient],
                       # Recipient's email
                fail_silently=False
            )
            return JsonResponse({"success": "Notification sent to admin."})
        except Exception as e:
            print(f"Failed to send email: {e}")
            return JsonResponse({"error": f"Failed to send notification: {str(e)}"}, status=500)
    else:
        return JsonResponse({"error": "Invalid request method"}, status=405)

__all__ = [
    "notifications_view",
    "send_notification",
]
