import json
from datetime import datetime, timedelta

from django.db import transaction
from django.db.models import Case, FloatField, Sum, Value, When
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt

from ..models import EmployeeDetails, Holiday, LeaveApplication, TrackerTasks
from .common import get_session_user_data, require_session_user_json


def _week_range(year, week):
    try:
        first_day = datetime.fromisocalendar(int(year), int(week), 1).date()
        last_day = first_day + timedelta(days=6)
        return first_day, last_day
    except ValueError:
        return None, None


def _summarize_week(username, first_day, last_day):
    tasks = TrackerTasks.objects.filter(
        assigned=username,
        date1__range=[first_day, last_day],
    )

    holidays = set(
        Holiday.objects.filter(date__range=[first_day, last_day])
        .values_list("date", flat=True)
    )
    weekend_days = {
        first_day + timedelta(days=i)
        for i in range(7)
        if (first_day + timedelta(days=i)).weekday() >= 5
    }

    worked_special_days = {
        task.date1 for task in tasks if task.date1 in holidays or task.date1 in weekend_days
    }

    leaves = (
        LeaveApplication.objects.filter(
            username__iexact=username,
            start_date__lte=last_day,
            end_date__gte=first_day,
        )
        .annotate(
            leave_value=Case(
                When(leave_type="Half Day", then=Value(0.5)),
                When(leave_type="Full Day", then=Value(1.0)),
                default=Value(0.0),
                output_field=FloatField(),
            )
        )
        .aggregate(total=Sum("leave_value"))
        .get("total")
        or 0.0
    )

    total_time = tasks.aggregate(total=Sum("time"))[("total")] or 0.0
    special_hours = (
        tasks.filter(date1__in=worked_special_days).aggregate(total=Sum("time"))["total"]
        or 0.0
    )

    weekdays = [
        first_day + timedelta(days=i)
        for i in range(7)
        if (first_day + timedelta(days=i)).weekday() < 5
    ]
    expected_hours = max(0.0, (len(weekdays) - len(holidays) - leaves) * 9)

    return {
        "tasks": tasks,
        "worked_special_days": worked_special_days,
        "total_time": total_time,
        "special_hours": special_hours,
        "expected_hours": expected_hours,
        "leaves": leaves,
        "holidays": holidays,
    }


@csrf_exempt
@require_session_user_json
def get_compensated_worktime(request):

    username = request.session_user_data.get("name")

    try:
        # ✅ Fetch work records grouped by ISO week/year
        weekly_records = (
            TrackerTasks.objects.filter(assigned=username)
            .values("date1__year", "date1__week")
            .annotate(total_time=Sum("time"))
            .order_by("-date1__year", "-date1__week")
        )

        compensated_worktime_data = []

        for record in weekly_records:
            year = record.get("date1__year")
            week = record.get("date1__week")
            total_time = record.get("total_time") or 0.0

            if not year or not week:
                continue

            # ✅ Compute week date range (Mon → Sun)
            first_day, last_day = _week_range(year, week)
            if not first_day:
                continue

            summary = _summarize_week(username, first_day, last_day)
            worked_special_days = list(summary["worked_special_days"])
            if not worked_special_days:
                continue

            total_time = summary["total_time"]
            expected_hours = summary["expected_hours"]
            special_hours = summary["special_hours"]
            extra_hours = total_time - expected_hours
            leaves_in_week = summary["leaves"]
            total_holidays = len(summary["holidays"])

            # =====================================================
            # 🧠 COMPENSATION LOGIC (Only if weekend/holiday work)
            # =====================================================
            if special_hours > 0:
                if extra_hours >= 8:
                    is_compensated = 1.0
                    status = "Full Day Earned"
                elif extra_hours >= 4:
                    is_compensated = 0.5
                    status = "Half Day Earned"
                else:
                    is_compensated = 0.0
                    status = "Not Compensated"
            else:
                is_compensated = 0.0
                status = "Not Compensated"

            # ✅ Preserve approval/redeemed state
            latest_task = (
                TrackerTasks.objects.filter(
                    assigned=username, date1__range=[first_day, last_day]
                )
                .order_by("-id")
                .first()
            )

            redeemed = latest_task.redeemed if latest_task else 0
            db_is_compensated = latest_task.is_compensated if latest_task else 0.0

            if db_is_compensated in [1.5, 2.0]:
                status = "Waiting for Approval"
                is_compensated = db_is_compensated
            elif db_is_compensated in [0.5, 1.0] and redeemed == 1:
                status = "Approved"
                is_compensated = db_is_compensated

            # ✅ Append to response
            compensated_worktime_data.append({
                "week": f"{year}-W{week}",
                "date": worked_special_days[0].strftime("%d-%m-%Y"),
                "work_date": worked_special_days[0].strftime("%Y-%m-%d"),
                "total_time": round(total_time, 2),
                "expected_hours": round(expected_hours, 2),
                "extra_hours": round(extra_hours, 2),
                "special_hours": round(special_hours, 2),
                "holidays": total_holidays,
                "leaves": leaves_in_week,
                "is_compensated": is_compensated,
                "redeemed": redeemed,
                "status": status,
            })

        return JsonResponse({"compensated_worktime": compensated_worktime_data}, status=200)

    except Exception as e:
        import traceback
        traceback.print_exc()
        print("❌ Error fetching compensated worktime:", str(e))
        return JsonResponse({"error": str(e)}, status=500)


@csrf_exempt
@require_session_user_json
def request_comp_leave(request):
    """
    User submits a request for compensatory leave approval (TrackerTasks only).
    Compatible with 5-day (Mon–Fri) work policy:
      - Full-day request if worked >= 8 hrs
      - Half-day request if worked >= 4 and < 8 hrs
      - Only allowed if the work date is a weekend or official holiday
    """

    # ✅ 2. Allow only POST
    if request.method != "POST":
        return JsonResponse({"error": "Method Not Allowed"}, status=405)

    try:
        data = json.loads(request.body)
        date_str = data.get("date")

        # --- Validate date field ---
        if not date_str:
            return JsonResponse({"error": "Missing date field"}, status=400)

        # Handle possible week range ("YYYY-MM-DD - YYYY-MM-DD")
        if " - " in date_str:
            date_str = date_str.split(" - ")[0].strip()

        # --- Parse the date safely ---
        parsed_date = None
        for fmt in ("%Y-%m-%d", "%d-%m-%Y"):  # support both formats
            try:
                parsed_date = datetime.strptime(date_str.strip(), fmt).date()
                break
            except ValueError:
                continue

        if not parsed_date:
            return JsonResponse({"error": f"Invalid date format: {date_str}"}, status=400)

        date_obj = parsed_date
        username = request.session_user_data.get("name")

        print(f"📅 Comp Leave Request | User: {username} | Date: {date_obj}")

        # ✅ 3. Verify user worked on this date
        tasks_that_day = TrackerTasks.objects.filter(
            assigned__iexact=username, date1=date_obj
        )

        if not tasks_that_day.exists():
            # Helpful feedback
            is_weekend = date_obj.weekday() in [5, 6]
            is_holiday = Holiday.objects.filter(date=date_obj).exists()
            if not (is_weekend or is_holiday):
                msg = "No work records found for this weekday."
            else:
                msg = "No work records found — please log your weekend/holiday work first."
            return JsonResponse({"error": msg}, status=400)

        # ✅ 4. Check if date is weekend or holiday
        is_weekend = date_obj.weekday() in [5, 6]  # Saturday=5, Sunday=6
        is_holiday = Holiday.objects.filter(date=date_obj).exists()

        if not (is_weekend or is_holiday):
            return JsonResponse({
                "error": "Compensatory leave can only be requested for work done on weekends or holidays."
            }, status=400)

        # ✅ 5. Calculate total hours worked
        total_time = tasks_that_day.aggregate(total=Sum("time"))["total"] or 0.0
        print(f"🕒 Total hours worked on {date_obj}: {total_time}")

        if total_time < 4:
            return JsonResponse({"error": "Not enough hours for compensation."}, status=400)

        # ✅ 6. Determine full-day / half-day eligibility
        if total_time >= 8:
            is_compensated = 2.0
            comp_status = "Full Day Requested"
        else:
            is_compensated = 1.5
            comp_status = "Half Day Requested"

        # ✅ 7. Update TrackerTasks for that date
        updated = tasks_that_day.update(
            is_compensated=is_compensated,
            comp_status=comp_status
        )

        print(f"✅ Updated {updated} rows | is_compensated={is_compensated} | status={comp_status}")

        # ✅ 8. Respond
        return JsonResponse({
            "message": "Compensatory leave request submitted successfully!",
            "date": date_obj.strftime("%Y-%m-%d"),
            "requested": "Full Day" if is_compensated == 2.0 else "Half Day",
            "total_hours": total_time
        }, status=200)

    except Exception as e:
        import traceback
        traceback.print_exc()
        return JsonResponse({"error": f"Failed to submit comp leave request: {str(e)}"}, status=500)


def get_pending_comp_leave_requests(request):
    """Allow both Admin and MD to view pending compensatory leave requests."""

    # ✅ Ensure user is logged in
    user_data = get_session_user_data(request)
    if not user_data:
        return JsonResponse({"error": "User not logged in."}, status=401)

    username = user_data.get("name")

    # ✅ Check if user is Admin or MD
    try:
        employee = EmployeeDetails.objects.filter(name__iexact=username).first()
        if not employee or employee.authentication.strip().upper() not in ["ADMIN", "MD"]:
            return JsonResponse({"error": "Forbidden: Only Admin or MD can view this."}, status=403)
    except Exception:
        return JsonResponse({"error": "Error checking user role."}, status=500)

    try:
        # ✅ Fetch pending comp leave requests (not yet approved)
        pending_requests = (
            TrackerTasks.objects.filter(
                is_compensated__in=[1.5, 2.0],
                redeemed=0
            )
            .values("assigned", "date1", "time", "is_compensated")
            .order_by("-date1")
        )

        pending_list = []
        for req in pending_requests:
            if req["is_compensated"] == 1.5:
                status_text = "Half Day Pending Approval"
            elif req["is_compensated"] == 2.0:
                status_text = "Full Day Pending Approval"
            else:
                status_text = "Unknown"

            pending_list.append({
                "username": req["assigned"],
                "date": req["date1"].strftime("%Y-%m-%d"),
                "total_time": req["time"],
                "status": status_text
            })

        return JsonResponse({"pending_requests": pending_list}, status=200)

    except Exception as e:
        return JsonResponse({"error": f"Error fetching requests: {str(e)}"}, status=500)


@csrf_exempt
def update_comp_leave_status(request):
    """
    MD approves or rejects compensatory leave requests (TrackerTasks only).

    Rules:
      - Only MD can perform approval/rejection.
      - Full-day request => is_compensated = 2.0
      - Half-day request => is_compensated = 1.5
      - On approval: comp_status updated, redeemed set to 1
      - On rejection: comp_status updated, redeemed set to 0
      - Automatically resets is_compensated = 0.0 after processing
    """

    # ✅ 1. Validate login
    user_data = get_session_user_data(request)
    if not user_data:
        return JsonResponse({"error": "User not logged in."}, status=401)

    username = user_data.get("name")

    # ✅ 2. Validate MD role
    employee = EmployeeDetails.objects.filter(name__iexact=username).first()
    if not employee or employee.authentication.strip().upper() != "MD":
        return JsonResponse({"error": "Forbidden: Only MD can approve/reject."}, status=403)

    # ✅ 3. Check method
    if request.method != "POST":
        return JsonResponse({"error": "Method Not Allowed"}, status=405)

    try:
        data = json.loads(request.body)
        date_str = data.get("date")
        target_user = data.get("username")
        action = data.get("action")

        if not all([date_str, target_user, action]) or action not in ["approve", "reject"]:
            return JsonResponse({"error": "Invalid request data."}, status=400)

        date_obj = datetime.strptime(date_str, "%Y-%m-%d").date()
        print(f"🧾 Comp Leave Decision | Action: {action} | User: {target_user} | Date: {date_obj}")

        # ✅ 4. Find tasks for user/date
        tasks = TrackerTasks.objects.filter(assigned__iexact=target_user, date1=date_obj)
        if not tasks.exists():
            return JsonResponse({"error": "No matching records found for this user/date."}, status=404)

        # ✅ 5. Transaction-safe update
        with transaction.atomic():
            for task in tasks:
                # --- Determine type of request ---
                if task.is_compensated == 1.5:
                    req_type = "Half Day"
                elif task.is_compensated == 2.0:
                    req_type = "Full Day"
                else:
                    continue  # Skip tasks not pending comp leave

                if action == "approve":
                    task.comp_status = f"{req_type}"
                    task.is_compensated = 0.0
                    task.redeemed = 1

                    # OPTIONAL: Automatically credit comp-off leave balance
                    # try:
                    #     leave_balance, _ = LeaveBalance.objects.get_or_create(username=target_user)
                    #     if req_type == "Half-day":
                    #         leave_balance.comp_off += 0.5
                    #     elif req_type == "Full-day":
                    #         leave_balance.comp_off += 1.0
                    #     leave_balance.save()
                    # except Exception as e:
                    #     print(f"⚠️ Warning: Failed to update leave balance for {target_user}: {e}")

                elif action == "reject":
                    task.comp_status = f"{req_type} Rejected"
                    task.is_compensated = 0.0
                    task.redeemed = 0

                task.save(update_fields=["is_compensated", "redeemed", "comp_status"])

        # ✅ 6. Final response
        return JsonResponse({
            "message": f"Compensatory leave {action}d successfully.",
            "username": target_user,
            "date": date_str,
            "action": action.capitalize()
        }, status=200)

    except Exception as e:
        transaction.set_rollback(True)
        import traceback
        traceback.print_exc()
        return JsonResponse({"error": f"Error updating comp leave status: {str(e)}"}, status=500)

__all__ = [
    "get_compensated_worktime",
    "request_comp_leave",
    "get_pending_comp_leave_requests",
    "update_comp_leave_status",
]
