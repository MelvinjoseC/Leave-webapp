import base64
import json
from collections import defaultdict
from datetime import datetime, timedelta

from django.db import connection
from django.db.models import Max, Sum
from django.http import JsonResponse
from django.shortcuts import redirect, render
from django.views.decorators.csrf import csrf_exempt

from ..forms import ProjectStatusUpdateForm
from ..models import EmployeeDetails, Monthlycalendar, ProjectTacker, TrackerTasks
from .common import get_session_user_data


def _get_user_context(request):
    user_data = get_session_user_data(request)
    if not user_data:
        return None, "", False

    username = (user_data.get("name") or "").strip()
    role = (user_data.get("authentication") or user_data.get("role") or "").lower()
    is_admin_or_md = role in ["admin", "md"]
    return user_data, username, is_admin_or_md


def get_project_hours(request):
    project_name = request.GET.get('project')
    year = request.GET.get('year')
    month = request.GET.get('month')

    if not project_name or not year or not month:
        return JsonResponse({'error': 'Project, year, and month are required.'}, status=400)

    try:
        year = int(year)
        month = int(month)
    except ValueError:
        return JsonResponse({'error': 'Invalid year or month.'}, status=400)

    # 🔹 Check Monthlycalendar first
    monthly_hours = Monthlycalendar.objects.filter(
        project=project_name,
        date__year=year,
        date__month=month
    ).aggregate(total=Sum('time'))['total']

    if monthly_hours is not None and monthly_hours > 0:
        total_hours = monthly_hours
    else:
        # 🔹 fallback to TrackerTasks
        total_hours = TrackerTasks.objects.filter(
            projects=project_name,
            date1__year=year,
            date1__month=month
        ).aggregate(total=Sum('time'))['total'] or 0

    return JsonResponse({
        'project': project_name,
        'year': year,
        'month': month,
        'total_hours': total_hours
    })


def get_admins(request):
    admins_and_mds = EmployeeDetails.objects.filter(
        authentication__in=["admin", "md"]
    ).values("employee_id", "name", "authentication")

    admin_list = [
        {"id": emp["employee_id"], "name": emp["name"], "role": emp["authentication"].capitalize()}
        for emp in admins_and_mds
    ]
    return JsonResponse({"admins": admin_list})


def project_tracker(request):
    user_data, name, is_admin_or_md = _get_user_context(request)
    if not user_data:
        return redirect("login_page")

    # ✅ Get user data from session
    user_id = user_data.get("employee_id")
    designation = user_data.get("designation")
    authentication = user_data.get("authentication")
    display_name = name or user_data.get("name", "Guest")
    image_base64 = None

    if user_id:
        employee = (
            EmployeeDetails.objects.only("designation", "authentication", "image")
            .filter(employee_id=user_id)
            .first()
        )
        if employee:
            designation = designation or (employee.designation or "No Designation")
            authentication = authentication or (employee.authentication or "No Role")

            cached_avatar = request.session.get("user_avatar_cache") or {}
            image_data = getattr(employee, "image", None)
            if image_data:
                image_bytes = bytes(image_data)
                signature = f"{len(image_bytes)}:{hash(image_bytes[:32])}"
                if cached_avatar.get("signature") != signature:
                    image_base64 = base64.b64encode(image_bytes).decode("utf-8")
                    request.session["user_avatar_cache"] = {
                        "signature": signature,
                        "value": image_base64,
                    }
                else:
                    image_base64 = cached_avatar.get("value")
            else:
                image_base64 = None
                request.session.pop("user_avatar_cache", None)

    # ✅ Fetch pending projects
    project_data = ProjectTacker.objects.filter(status="Pending").only(
        "name", "sender_name", "status", "to_aproove"
    )
    if not is_admin_or_md:
        project_data = project_data.filter(sender_name__iexact=name)

    # ✅ Flatten all 'to_approve' JSON data into a single list
    task_list = []
    for project in project_data:
        to_approve = project.to_aproove  # (Confirm correct field spelling)
        if to_approve:
            if isinstance(to_approve, dict):
                tasks = [to_approve]
            elif isinstance(to_approve, list):
                tasks = to_approve
            else:
                tasks = []

            for task in tasks:
                task_copy = task.copy()
                task_copy["project_name"] = project.name
                task_copy["sender_name"] = project.sender_name
                task_list.append(task_copy)

    # ✅ Pass context to template
    context = {
        "user_data": user_data,
        "task_list": task_list,
        "name": display_name,
        "designation": designation or "No Designation",
        "authentication": authentication or "No Role",
        "image_base64": image_base64,
        "employee_id": user_id,
        "is_admin_or_md": is_admin_or_md,
    }

    return render(request, "project_tracker.html", context)


def get_week_date_range(week_offset):
    """
    Return start and end dates (Monday-Sunday) for the requested week offset.
    week_offset=0 is the current week, -1 the previous, etc.
    """
    today = datetime.today()
    start_of_week = today - timedelta(days=today.weekday())
    week_start = start_of_week + timedelta(weeks=week_offset)
    week_end = week_start + timedelta(days=6)
    return week_start.date(), week_end.date()


def create_project_view(request):
    if request.method == "POST":
        try:
            project_name = request.POST.get("projectName")
            start_date = request.POST.get("startDate")
            end_date = request.POST.get("endDate")
            scope = request.POST.get("scope")
            category = request.POST.get("category")
            benchmark = request.POST.get("Benchmark")

            # Ensure all fields are filled
            if not all([project_name, start_date, end_date, scope, category, benchmark]):
                return JsonResponse({"error": "All fields are required!"}, status=400)

            # Insert into the database
            with connection.cursor() as cursor:
                cursor.execute("""
                    INSERT INTO tracker_project (projects, scope, category, task_benchmark, start, end)
                    VALUES (%s, %s, %s, %s, %s, %s)
                """, [project_name, scope, category, benchmark, start_date, end_date])

            return JsonResponse({"message": "Project Created Successfully!"})

        except Exception as e:
            print("Database Error:", e)  # Log the error for debugging
            return JsonResponse({"error": "Something went wrong. Please try again later."}, status=500)

    return render(request, "project_tracker.html")  # Load the form page


def get_project_datas(request):
    user_data, username, is_admin_or_md = _get_user_context(request)
    if not user_data:
        return JsonResponse({"error": "User not logged in."}, status=401)

    department = request.GET.get('department', None)  # Use 'list' here for department
    project_name = request.GET.get('project_name', None)
    category = request.GET.get('category', None)
    week_offset = int(request.GET.get('week_offset', 0))  # Week offset: 0 for CW, -1 for W6, etc.

    # Get the date range for the selected week
    week_start, week_end = get_week_date_range(week_offset)

    # Start the queryset to fetch data from TrackerTasks model
    project_query = TrackerTasks.objects.all()
    if not is_admin_or_md:
        project_query = project_query.filter(assigned__iexact=username)

    # Apply filtering if department is provided
    if department:
        project_query = project_query.filter(list=department)  # Use 'list' field for department
    
    # Apply filtering if project_name is provided
    if project_name:
        project_query = project_query.filter(projects=project_name)

    # Apply filtering if category is provided
    if category:
        project_query = project_query.filter(category=category)
    
    # Apply filtering for the week based on the date range
    project_query = project_query.filter(date1__range=[week_start, week_end])

    # Fetch the relevant fields and annotate results
    project_data = project_query.values('projects', 'category', 'date1', 'time', 'list').order_by('projects', 'date1')

    # Convert the queryset to a list of dictionaries
    project_data_list = [
        {
            'projects': item['projects'],
            'category': item['category'],
            'date1': item['date1'],
            'time': item['time'],
            'department': item['list']
        }
        for item in project_data
    ]
    
    # Get available departments for the department dropdown
    department_queryset = TrackerTasks.objects.all()
    if not is_admin_or_md:
        department_queryset = department_queryset.filter(assigned__iexact=username)
    departments = department_queryset.values('list').distinct()
    department_list = [department['list'] for department in departments]

    # Get available projects for the project dropdown based on the selected department
    if department:
        projects_queryset = TrackerTasks.objects.filter(list=department)
        if not is_admin_or_md:
            projects_queryset = projects_queryset.filter(assigned__iexact=username)
        projects = projects_queryset.values('projects').distinct()
        project_list = [project['projects'] for project in projects]
    else:
        project_list = []

    # Get available categories for the category dropdown based on the selected project
    if project_name:
        categories_queryset = TrackerTasks.objects.filter(projects=project_name)
        if not is_admin_or_md:
            categories_queryset = categories_queryset.filter(assigned__iexact=username)
        categories = categories_queryset.values('category').distinct()
        category_list = [category['category'] for category in categories]
    else:
        category_list = []

    # Available weeks (CW, W6, W5, etc.)
    week_list = [
        {'label': 'CW', 'value': 0},
        {'label': 'W6', 'value': -1},
        {'label': 'W5', 'value': -2},
        {'label': 'W4', 'value': -3},
        {'label': 'W3', 'value': -4},
        {'label': 'W2', 'value': -5},
        {'label': 'W1', 'value': -6},
    ]

    # Return the response with department, project, category, week data, and the filtered project data
    return JsonResponse({
        'departments': department_list,
        'projects': project_list,
        'categories': category_list,
        'weeks': week_list,
        'project_data': project_data_list
    })


def get_projects(request):
    user_data, username, is_admin_or_md = _get_user_context(request)
    if not user_data:
        return JsonResponse({"error": "User not logged in."}, status=401)

    project_base = TrackerTasks.objects.exclude(projects__isnull=True).exclude(projects="")
    if not is_admin_or_md:
        project_base = project_base.filter(assigned__iexact=username)

    worktime_rows = list(
        project_base.values("projects").annotate(total_worktime=Sum("time")).order_by("projects")
    )
    worktime_map = {
        row["projects"]: float(row["total_worktime"] or 0)
        for row in worktime_rows
    }

    approved_rows = project_base.values(
        "projects", "scope", "category", "title", "rev", "d_no"
    ).annotate(approved_value=Max("task_benchmark"))

    approved_map = defaultdict(float)
    for row in approved_rows:
        approved_map[row["projects"]] += float(row["approved_value"] or 0)

    project_names = list(worktime_map.keys())
    for project in approved_map.keys():
        if project not in project_names:
            project_names.append(project)

    return JsonResponse({
        "projects": project_names,
        "approvedHours": [approved_map.get(name, 0.0) for name in project_names],
        "totalWorktime": [worktime_map.get(name, 0.0) for name in project_names],
    })


def get_project_data_simple(request, project):
    # Filter only for the selected project
    tasks = TrackerTasks.objects.filter(projects=project).values(
        'projects', 'scope', 'category', 'title', 'rev', 'task_benchmark'
    )

    # For unique approved hours
    unique_keys = set()
    approved_hours = 0
    for task in tasks:
        key = (task['projects'], task['scope'], task['category'], task['title'], task['rev'])
        if key not in unique_keys:
            unique_keys.add(key)
            approved_hours += float(task['task_benchmark'] or 0)

    # Total worktime for this project
    total_worktime = TrackerTasks.objects.filter(projects=project).aggregate(
        total=Sum('time')
    )['total'] or 0

    return JsonResponse({
        "projects": [project],
        "approvedHours": [approved_hours],
        "totalWorktime": [total_worktime]
    })


def get_task_data(request, project):
    tasks = TrackerTasks.objects.filter(projects=project)

    task_names = []
    approved_hours_list = []
    total_worktime_list = []
    user_worktime_map = {}

    for task in tasks:
        task_name = task.title
        task_names.append(task_name)
        approved_hours_list.append(float(task.task_benchmark or 0))
        total_worktime_list.append(float(task.time or 0))

        user = task.assigned or "Unassigned"
        user_worktime_map[user] = user_worktime_map.get(user, 0) + float(task.time or 0)

    return JsonResponse({
        "tasks": task_names,
        "approvedHours": approved_hours_list,
        "totalWorktime": total_worktime_list,
        "userWorktimes": user_worktime_map
    })


def get_project(request, team):
    projects = TrackerTasks.objects.filter(team=team).values('projects').distinct()
    project_names = [project['projects'] for project in projects]
    return JsonResponse({"projects": project_names})


def get_task_datas(request, project):  # ✅ Only project now
    # Fetch all unique task combinations under the project
    tasks = TrackerTasks.objects.filter(projects=project).values(
        'projects', 'scope', 'category', 'title', 'rev', 'd_no'
    ).distinct()

    approved_hours = []
    total_worktime = []
    task_titles = []
    user_worktimes = {}

    for task in tasks:
        task_titles.append(task['title'])

        filters = {
            'projects': project,
            'title': task['title'],
            'rev': task['rev'],
            'd_no': task['d_no'],
        }

        # Approved hours
        approved_sum = TrackerTasks.objects.filter(**filters).aggregate(
            total=Sum('task_benchmark')
        )['total'] or 0
        approved_hours.append(approved_sum)

        # Total worktime
        worktime_sum = TrackerTasks.objects.filter(**filters).aggregate(
            total=Sum('time')
        )['total'] or 0
        total_worktime.append(worktime_sum)

    # Aggregate user worktimes under this project
    user_rows = TrackerTasks.objects.filter(projects=project).values('assigned').annotate(
        total_worktime=Sum('time')
    )

    for entry in user_rows:
        username = entry['assigned'] or 'Unassigned'
        if entry['total_worktime'] is not None:
            user_worktimes[username] = entry['total_worktime']

    return JsonResponse({
        "tasks": task_titles,
        "approvedHours": approved_hours,
        "totalWorktime": total_worktime,
        "userWorktimes": user_worktimes
    })


def get_project_data(request, project):
    # Fetch all tasks for the specified project
    project_data = TrackerTasks.objects.filter(projects=project).values(
        'projects',
        'scope',
        'category',
        'title',
        'rev',
        'd_no',
        'task_benchmark',
        'time'
    )

    # Use dicts to accumulate approved hours and total worktime
    approved_hours = 0
    total_worktime = 0
    unique_combinations = set()

    for entry in project_data:
        key = (
            entry['projects'],
            entry['scope'],
            entry['category'],
            entry['title'],
            entry['rev'],
            entry['d_no']
        )

        # Add approved hours only once for each unique key
        if key not in unique_combinations:
            unique_combinations.add(key)
            approved_hours += float(entry['task_benchmark'] or 0)

        # Always sum total worktime
        total_worktime += float(entry['time'] or 0)

    # Prepare JSON response
    data = {
        "projects": [project],
        "approvedHours": [approved_hours],
        "totalWorktime": [total_worktime]
    }

    return JsonResponse(data)


def get_projects_data(request):
    # Fetch distinct project names from the TrackerTasks model
    projects = TrackerTasks.objects.values('projects').distinct()

    # Convert queryset to list of project names
    projects = [project['projects'] for project in projects]

    # Return the data as JSON
    return JsonResponse({
        'projects': projects
    })


def update_project_status(request):
    if request.method == 'POST':
        form = ProjectStatusUpdateForm(request.POST)
        if form.is_valid():
            # Get the selected data from the form
            project_name = form.cleaned_data['projects']
            project_status = form.cleaned_data['project_status']

            # Update only the selected project's status
            tasks = TrackerTasks.objects.filter(projects=project_name)

            # If tasks exist, update their project_status
            if tasks.exists():
                tasks.update(project_status=project_status)
                return JsonResponse({"success": "Project status updated successfully"}, status=200)
            else:
                return JsonResponse({"error": "Project not found"}, status=404)

    else:
        # Display the form initially (GET request)
        form = ProjectStatusUpdateForm()

    return render(request, 'project_tracker.html', {'form': form})


@csrf_exempt
def save_weekly_report(request):
    if request.method != "POST":
        return JsonResponse({"success": False, "error": "Invalid request"})

    try:
        data = json.loads(request.body)
        updates = data.get("updates", [])
        changes_made = False
        updated_rows = []  # store final saved data for UI

        for item in updates:
            tracker_id = item.get("tracker_id")
            monthly_id = item.get("monthly_id")

            try:
                tracker = TrackerTasks.objects.get(id=tracker_id)
                d_no_value = tracker.d_no

                # Parse start date
                if item.get("start_date"):
                    date_value = datetime.strptime(item["start_date"], "%d/%m/%Y").date()
                else:
                    date_value = getattr(tracker, "date1", datetime.today().date())

                # Parse end date
                end_date_value = None
                if item.get("end_date"):
                    try:
                        end_date_value = datetime.strptime(item["end_date"], "%d/%m/%Y").date()
                    except Exception:
                        end_date_value = None

                is_lifting = (tracker.list or "").strip().upper() == "LIFTING"

                # --- Lookup Monthlycalendar row ---
                if monthly_id:
                    existing = Monthlycalendar.objects.filter(id=monthly_id).first()
                else:
                    existing = None
                    if monthly_id:
                        existing = Monthlycalendar.objects.filter(id=monthly_id).first()

                    if not existing:
                        query = {
                            "d_no": d_no_value,
                            "date": date_value,
                            "project": tracker.projects,
                            "list": tracker.list
                        }
                        if end_date_value:
                            query["enddate"] = end_date_value
                        existing = Monthlycalendar.objects.filter(**query).first()


                if existing:
                    updated_fields = {}

                    if is_lifting:
                        if item.get("title") and item["title"] != existing.title:
                            updated_fields["title"] = item["title"]
                        if item.get("mail_no") and item["mail_no"] != existing.mail_no:
                            updated_fields["mail_no"] = item["mail_no"]
                        if item.get("ref_no") and item["ref_no"] != existing.ref_no:
                            updated_fields["ref_no"] = item["ref_no"]
                        if item.get("comments") is not None and item["comments"] != existing.comments:
                            updated_fields["comments"] = item["comments"]
                        if existing.scope != tracker.scope:
                            updated_fields["scope"] = tracker.scope or ""
                        if existing.category != tracker.category:
                            updated_fields["category"] = tracker.category or ""
                        if existing.assigned != tracker.assigned:
                            updated_fields["assigned"] = tracker.assigned
                    else:
                        if item.get("scope") and item["scope"] != existing.scope:
                            updated_fields["scope"] = item["scope"]
                        if item.get("category") and item["category"] != existing.category:
                            updated_fields["category"] = item["category"]
                        if item.get("designation") and getattr(existing, "designation", None) != item["designation"]:
                            updated_fields["designation"] = item["designation"]
                        if item.get("comments") is not None and item["comments"] != existing.comments:
                            updated_fields["comments"] = item["comments"]
                        if existing.assigned != tracker.assigned:
                            updated_fields["assigned"] = tracker.assigned

                    # Common fields
                    if item.get("rev_no") and item["rev_no"] != existing.rev_no:
                        updated_fields["rev_no"] = item["rev_no"]
                    if item.get("status") and item["status"] != existing.status:
                        updated_fields["status"] = item["status"]
                    if item.get("time") is not None and item["time"] != existing.time:
                        updated_fields["time"] = item["time"]
                    if end_date_value and end_date_value != existing.enddate:
                        updated_fields["enddate"] = end_date_value

                    if updated_fields:
                        for f, v in updated_fields.items():
                            setattr(existing, f, v)
                        existing.updated = datetime.today().date()
                        existing.save()
                        changes_made = True

                    updated_rows.append({
                        "tracker_id": tracker.id,
                        "monthly_id": existing.id,
                        "title": existing.title,
                        "scope": existing.scope,
                        "category": existing.category,
                        "assigned": existing.assigned,
                        "designation": getattr(existing, "designation", ""),  # ✅ add this
                        "mail_no": getattr(existing, "mail_no", ""),
                        "ref_no": getattr(existing, "ref_no", ""),
                        "comments": existing.comments,
                        "status": existing.status,
                        "rev_no": existing.rev_no,
                        "time": item.get("time", existing.time),
                        "start_date": existing.date.strftime("%d/%m/%Y") if existing.date else "",
                        "end_date": existing.enddate.strftime("%d/%m/%Y") if existing.enddate else ""
                    })

                else:
                    # --- Create new ---
                    new_rec = Monthlycalendar.objects.create(
                        d_no=d_no_value,
                        title=item.get("title", tracker.title),
                        mail_no=item.get("mail_no", tracker.mail_no),
                        ref_no=item.get("ref_no", tracker.ref_no),
                        status=item.get("status", getattr(tracker, "status", "")),
                        project=tracker.projects,
                        list=tracker.list,
                        date=date_value,
                        enddate=end_date_value,
                        rev_no=item.get("rev_no", tracker.rev),
                        time=item.get("time", getattr(tracker, "time", 0)),
                        comments=item.get("comments", getattr(tracker, "comments", "")),
                        scope=item.get("scope", tracker.scope),
                        category=item.get("category", tracker.category),
                        designation=item.get("designation", getattr(tracker, "designation", "")),
                        assigned=tracker.assigned,
                        benchmark=tracker.task_benchmark,
                        created=datetime.today().date(),
                        updated=datetime.today().date()
                    )

                    updated_rows.append({
                        "tracker_id": tracker.id,
                        "monthly_id": new_rec.id,
                        "title": new_rec.title,
                        "scope": new_rec.scope,
                        "category": new_rec.category,
                        "assigned": new_rec.assigned,
                        "designation": getattr(new_rec, "designation", ""),  # ✅ add this
                        "mail_no": getattr(new_rec, "mail_no", ""),
                        "ref_no": getattr(new_rec, "ref_no", ""),
                        "comments": new_rec.comments,
                        "status": new_rec.status,
                        "rev_no": new_rec.rev_no,
                        "time": new_rec.time,
                        "start_date": new_rec.date.strftime("%d/%m/%Y") if new_rec.date else "",
                        "end_date": new_rec.enddate.strftime("%d/%m/%Y") if new_rec.enddate else ""
                    })
                    changes_made = True

            except TrackerTasks.DoesNotExist:
                continue

        if not changes_made:
            return JsonResponse({"success": False, "error": "No data to update"})

        return JsonResponse({"success": True, "updated": updated_rows})

    except Exception as e:
        return JsonResponse({"success": False, "error": str(e)})


@csrf_exempt
def get_weekly_report(request):
    if request.method != "GET":
        return JsonResponse({"success": False, "error": "Invalid request"})

    try:
        project_id = request.GET.get("project_id")
        start_date = request.GET.get("start_date")
        end_date = request.GET.get("end_date")

        if not project_id:
            return JsonResponse({"success": False, "error": "Missing project_id"})

        trackers = TrackerTasks.objects.filter(projects=project_id)
        results = []

        for tracker in trackers:
            monthly_qs = Monthlycalendar.objects.filter(
                d_no=tracker.d_no,
                project=tracker.projects,
                list=tracker.list
            )

            if start_date and end_date:
                monthly_qs = monthly_qs.filter(date__range=[start_date, end_date])

            monthly = monthly_qs.order_by("-updated").first()

            if monthly:
                results.append({
                    "tracker_id": tracker.id,
                    "monthly_id": monthly.id,
                    "title": monthly.title,
                    "scope": monthly.scope,
                    "category": monthly.category,
                    "assigned": monthly.assigned,
                    "mail_no": getattr(monthly, "mail_no", ""),
                    "ref_no": getattr(monthly, "ref_no", ""),
                    "comments": monthly.comments,
                    "status": monthly.status,
                    "rev_no": monthly.rev_no,
                    "time": monthly.time,
                    "start_date": monthly.date.strftime("%d/%m/%Y") if monthly.date else "",
                    "end_date": monthly.enddate.strftime("%d/%m/%Y") if monthly.enddate else ""
                })
            else:
                results.append({
                    "tracker_id": tracker.id,
                    "monthly_id": None,
                    "title": tracker.title,
                    "scope": tracker.scope,
                    "category": tracker.category,
                    "assigned": tracker.assigned,
                    "mail_no": getattr(tracker, "mail_no", ""),
                    "ref_no": getattr(tracker, "ref_no", ""),
                    "comments": getattr(tracker, "comments", ""),
                    "status": getattr(tracker, "status", ""),
                    "rev_no": tracker.rev,
                    "time": getattr(tracker, "time", 0),
                    "start_date": tracker.date1.strftime("%d/%m/%Y") if getattr(tracker, "date1", None) else "",
                    "end_date": ""  # TrackerTasks has no enddate field
                })

        return JsonResponse({"success": True, "rows": results})

    except Exception as e:
        return JsonResponse({"success": False, "error": str(e)})

__all__ = [
    "get_project_hours",
    "get_admins",
    "project_tracker",
    "create_project_view",
    "get_project_datas",
    "get_projects",
    "get_project_data_simple",
    "get_task_data",
    "get_project",
    "get_task_datas",
    "get_project_data",
    "get_projects_data",
    "update_project_status",
    "save_weekly_report",
    "get_weekly_report",
]
