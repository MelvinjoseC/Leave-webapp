import json

from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt

from ..models import UserinfoView
from .common import get_session_user_data


def get_user_effectiveness(request):
    """
    Return the effectiveness for the currently logged-in user
    based on user_data.
    """

    user_data = get_session_user_data(request)
    if not user_data:
        return JsonResponse({"error": "User not logged in."}, status=401)

    username = user_data.get("name")  # take username from user_data

    try:
        userinfo = UserinfoView.objects.filter(name=username).first()
        if userinfo and userinfo.effectiveness is not None:
            return JsonResponse({"effectiveness": float(userinfo.effectiveness)})
        else:
            # Default to 100% if user not found or no effectiveness
            return JsonResponse({"effectiveness": 100})
    except Exception as e:
        return JsonResponse({"error": str(e)}, status=500)


def get_users(request):
    """Return list of users for dropdown"""
    users = UserinfoView.objects.all().values("id", "name", "role", "effectiveness")
    return JsonResponse({"users": list(users)})


@csrf_exempt
def update_effectiveness(request):
    """Update effectiveness for selected user"""
    if request.method != "POST":
        return JsonResponse({"status": "error", "message": "Invalid method"}, status=405)

    try:
        data = json.loads(request.body.decode("utf-8"))
        user_id = data.get("id")
        effectiveness = data.get("effectiveness")

        if not user_id or effectiveness is None:
            return JsonResponse({"status": "error", "message": "Missing data"}, status=400)

        # Update
        updated = UserinfoView.objects.filter(id=user_id).update(effectiveness=effectiveness)

        if updated:
            return JsonResponse({"status": "success", "message": "Effectiveness updated successfully"})
        else:
            return JsonResponse({"status": "error", "message": "User not found"}, status=404)

    except Exception as e:
        return JsonResponse({"status": "error", "message": str(e)}, status=500)

__all__ = [
    "get_user_effectiveness",
    "get_users",
    "update_effectiveness",
]
