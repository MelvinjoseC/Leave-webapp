import base64
import json

from django.db import connection
from django.http import JsonResponse
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt

from ..models import EmployeeDetails, TeamRanking, TrackerTasks
from .common import get_session_user_data


def employee_images(request):
    employees = EmployeeDetails.objects.all()
    data = []
    for emp in employees:
        img_base64 = None
        if emp.image:
            img_base64 = base64.b64encode(emp.image).decode('utf-8')
            img_base64 = f"data:image/jpeg;base64,{img_base64}"

        # store the name in lowercase for consistent lookup
        data.append({
            "name": emp.name.strip().lower(),
            "image": img_base64
        })
    return JsonResponse(data, safe=False)


def team_dashboard(request):
    user_data = get_session_user_data(request) or {}

    user_id = user_data.get("employee_id")
    name = user_data.get("name", "Guest")
    designation = user_data.get("designation")
    authentication = user_data.get("authentication")
    image_base64 = None

    if user_id:
        with connection.cursor() as cursor:
            cursor.execute(
                "SELECT designation, authentication, image FROM employee_details WHERE employee_id = %s",
                [user_id],
            )
            result = cursor.fetchone()
            if result:
                # Update only if missing
                designation = designation or (result[0] or "No Designation")
                authentication = authentication or (result[1] or "No Role")
                # Always update image if available
                image_base64 = base64.b64encode(result[2]).decode("utf-8") if result[2] else None

    # Determine role
    is_admin_or_md = authentication in ['admin', 'MD']

    # Fetch tracker tasks
    tracker_data = []
    if user_id:
        tasks = TrackerTasks.objects.filter(assigned=name)
        for task in tasks:
            tracker_data.append({
                "team": task.team,
                "task_benchmark": task.task_benchmark,
                "time": task.time,
                "projects": task.projects,
                "project_status": task.project_status,
                "title": task.title,
                "task_status": task.task_status,
                "priority": task.priority,
                "start": task.start,
                "end": task.end,
            })

    # Render template
    return render(
        request,
        "team_dashboard.html",
        {
            "name": name,
            "designation": designation,
            "authentication": authentication,
            "image_base64": image_base64,
            "employee_id": user_id,
            "tracker_data": tracker_data,
            "is_admin_or_md": is_admin_or_md,
        },
    )


def team_ranking_page(request):
    return render(request, 'project_tracker.html')


@csrf_exempt
def add_project_ranking(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        
        # Check if the project and assigned member already exist
        existing_record = TeamRanking.objects.filter(
            project_name=data['project_name'],
            project_assigned=data['project_assigned']
        ).first()
        
        if existing_record:
            existing_record.speed_of_execution = data['speed_of_execution']
            existing_record.complaints_of_check_list = data['complaints_of_check_list']
            existing_record.task_ownership = data['task_ownership']
            existing_record.understanding_task = data['understanding_task']
            existing_record.quality_of_work = data['quality_of_work']
            existing_record.save()
            return JsonResponse({'status': 'updated'})
        else:
            TeamRanking.objects.create(
                project_name=data['project_name'],
                project_assigned=data['project_assigned'],
                speed_of_execution=data['speed_of_execution'],
                complaints_of_check_list=data['complaints_of_check_list'],
                task_ownership=data['task_ownership'],
                understanding_task=data['understanding_task'],
                quality_of_work=data['quality_of_work'],
            )
            return JsonResponse({'status': 'created'})
    
    return JsonResponse({'status': 'invalid request'}, status=400)


@csrf_exempt
def get_project_member_details(request):
    project_name = request.GET.get('project_name')
    project_assigned = request.GET.get('project_assigned')
    
    data = TeamRanking.objects.filter(
        project_name=project_name,
        project_assigned=project_assigned
    ).values().first()
    
    return JsonResponse(data, safe=False)


def get_project_rankings(request):
    """
    Fetch all project ranking data ordered by date (newest first)
    """
    project_data = list(TeamRanking.objects.order_by('-date').values())
    return JsonResponse(project_data, safe=False)


def get_project_details(request):
    """
    Fetch distinct project names and assigned members from TrackerTasks table
    """
    project_data = (
        TrackerTasks.objects.values('projects', 'assigned')
        .distinct()
        .exclude(projects__isnull=True, assigned__isnull=True)
    )

    formatted_data = [
        {
            'project_name': item['projects'],
            'project_assigned': item['assigned']
        }
        for item in project_data
    ]
    return JsonResponse(formatted_data, safe=False)

__all__ = [
    "employee_images",
    "team_dashboard",
    "team_ranking_page",
    "add_project_ranking",
    "get_project_member_details",
    "get_project_rankings",
    "get_project_details",
]
