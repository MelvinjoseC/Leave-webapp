from functools import wraps

from django.http import JsonResponse

from ..models import EmployeeDetails

SESSION_USER_FIELDS = (
    "employee_id",
    "name",
    "designation",
    "authentication",
)


def _serialize_employee(row):
    authentication = (row.get("authentication") or "").strip()
    return {
        "employee_id": row.get("employee_id"),
        "name": row.get("name"),
        "designation": row.get("designation") or "",
        "authentication": authentication,
        "role": authentication.lower(),
    }


def get_session_user_data(request):
    """
    Retrieve the cached user details from the session. If the cache is missing
    but a user_id is present, refresh the cache from the database.
    """
    user_data = request.session.get("user_data")
    if user_data:
        return user_data

    user_id = request.session.get("user_id")
    if not user_id:
        return None

    employee_row = (
        EmployeeDetails.objects.filter(employee_id=user_id)
        .values(*SESSION_USER_FIELDS)
        .first()
    )
    if not employee_row:
        return None

    user_data = _serialize_employee(employee_row)
    request.session["user_data"] = user_data
    return user_data

def require_session_user_json(view_func):
    """Enforce login for JSON endpoints without adding per-view boilerplate."""
    @wraps(view_func)
    def _wrapped(request, *args, **kwargs):
        user_data = get_session_user_data(request)
        if not user_data:
            return JsonResponse({"error": "User not logged in."}, status=401)
        # Cache for downstream handlers that need it repeatedly
        request.session_user_data = user_data
        return view_func(request, *args, **kwargs)

    return _wrapped

__all__ = [
    "get_session_user_data",
    "require_session_user_json",
]
