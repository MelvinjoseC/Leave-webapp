"""
Compatibility shim that exposes all view callables from the modular
`tracker.viewsets` package under the traditional `tracker.views` module.
"""

from .viewsets import *  # noqa: F401,F403
