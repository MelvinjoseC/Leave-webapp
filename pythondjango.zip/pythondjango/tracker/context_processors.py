import json

from .models import ProjectTacker


def pending_task_count(request):
    """
    Provides the number of pending tasks to all templates and exposes the
    logged-in user's session data (if available) for client-side scripts.
    """
    pending_count = ProjectTacker.objects.filter(status="Pending").count()
    session_user = request.session.get("user_data") or {}
    return {
        "pending_count": pending_count,
        "session_user_data": session_user,
        "session_user_json": json.dumps(session_user) if session_user else "null",
    }
