from django.contrib import admin
from .models import (
    ProjectTacker,
    TrackerTasks,
    EmployeeDetails,
    UserinfoView,
    LeaveApplication,
    Attendance,
    Holiday,
    TeamRanking,
    Monthlycalendar,
)

# Register models (simple style)
admin.site.register(ProjectTacker)
admin.site.register(TrackerTasks)
admin.site.register(EmployeeDetails)
admin.site.register(UserinfoView)
admin.site.register(LeaveApplication)
admin.site.register(Attendance)
admin.site.register(Holiday)
admin.site.register(TeamRanking)
admin.site.register(Monthlycalendar)
